package com.emprende.mujerapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
