import 'package:flutter/material.dart';

abstract class ThemeColors {
  static const primary = Color(0xffA0B029);
  static const secondary = Color(0xff65701D);
  static const letters = Color(0xffF6F5F5);
  static const lettersDisabled = Color(0xffA0A0A0);
  static const disabled = Color(0xffD9D9D9);
  static const tab1 = Color(0xff40BBBD);
  static const tab2 = Color(0xffA0B029);
  static const tab3 = Color(0xff8E448D);
  static const avatar = Color(0xffD9D9D9);
}
