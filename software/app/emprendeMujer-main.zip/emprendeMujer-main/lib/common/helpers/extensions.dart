import 'package:intl/intl.dart';

extension StringExtension on String {
  String get formatMoney {
    try {
      final moneyValue = double.parse(this);
      final formatter = NumberFormat.currency(
        symbol: r'$',
        decimalDigits: 2,
      );
      return formatter.format(moneyValue);
    } catch (e) {
      return this;
    }
  }

  String get formatPercentage {
    try {
      final percentageValue = double.parse(this);
      final formatter = NumberFormat.percentPattern(
        'en',
      );
      return formatter.format(percentageValue);
    } catch (e) {
      return this;
    }
  }
}
