import 'package:flutter/material.dart';

/// Muestra un cuadro de dialogo
Future<T?> showCustomDialog<T>(
  BuildContext context, {
  required Widget child,
  bool barrierDismissible = false,
}) {
  return showGeneralDialog(
    barrierDismissible: barrierDismissible,
    context: context,
    pageBuilder: (context, __, ___) => Container(),
    transitionBuilder: (___, animation, __, _) {
      final curve = Curves.easeInOut.transform(animation.value);
      return Transform.scale(
        scale: curve,
        child: child,
      );
    },
    transitionDuration: const Duration(milliseconds: 400),
  );
}
