import 'package:shared_preferences/shared_preferences.dart';

class PreferencesApp {
  static late SharedPreferences _prefs;
  static Future<SharedPreferences> init() async =>
      _prefs = await SharedPreferences.getInstance();

  static String _token = '';

  static String get token => _prefs.getString('token') ?? _token;

  static set token(String value) {
    _token = value;
    _prefs.setString('token', value);
  }
}
