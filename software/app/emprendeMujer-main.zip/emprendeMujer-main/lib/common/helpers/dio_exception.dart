import 'dart:io';

import 'package:dio/dio.dart';

String dioException(DioException e) {
  var message = '';

  switch (e.type) {
    case DioExceptionType.connectionTimeout:
    case DioExceptionType.badCertificate:
    case DioExceptionType.connectionError:
    case DioExceptionType.badResponse:
    case DioExceptionType.sendTimeout:
    case DioExceptionType.receiveTimeout:
    case DioExceptionType.cancel:
      final codigo = (e.response != null && e.response!.statusCode != null)
          ? e.response!.statusCode
          : 0;
      message =
          'Ups, ha ocurrido un error interno ($codigo). Inténtalo de nuevo más tarde. Disculpa las molestias.';
    case DioExceptionType.unknown:
      if (e.error is SocketException) {
        message = 'Error de conexión';
      } else {
        message = 'Error desconocido';
      }
  }
  return message;
}
