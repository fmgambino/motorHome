import 'package:emprende_mujer/common/constants/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  const CustomAppBar({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    return AppBar(
      title: Row(
        children: [
          SizedBox(
            width: context.dp(4),
          ),
          Text(
            l10n.by,
            style: TextStyle(
              color: Colors.black,
              fontSize: context.dp(1.6),
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(
            width: context.dp(1),
          ),
          SvgPicture.asset(
            logoColorPath,
            height: context.dp(2.5),
          ),
        ],
      ),
      iconTheme: const IconThemeData(color: Colors.black),
      centerTitle: true,
      backgroundColor: Colors.white,
      elevation: 8,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
