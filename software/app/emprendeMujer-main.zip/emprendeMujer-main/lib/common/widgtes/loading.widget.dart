import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:flutter/material.dart';

class LoadingWidget extends StatelessWidget {
  const LoadingWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: ColoredBox(
        color: Colors.black.withOpacity(0.6),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: context.dp(2),
              width: context.dp(2),
              child: CircularProgressIndicator( strokeWidth: context.dp(0.2), color: ThemeColors.primary),
            ),
            SizedBox(height: context.dp(1),),
            Text('Cargando...', style: TextStyle(fontSize: context.dp(1.6), color: ThemeColors.primary, fontWeight: FontWeight.w500),),
          ],
        ),
      ),
    );
  }
}