import 'package:emprende_mujer/common/theme/theme.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:flutter/material.dart';

class PopUpWidget extends StatefulWidget {
  const PopUpWidget({
    required this.emoji,
    required this.title,
    required this.description,
    required this.onPressed,
    required this.titleBtn,
    super.key,
  });

  final String emoji;
  final String title;
  final String description;
  final String titleBtn;
  final Function onPressed;

  @override
  State<PopUpWidget> createState() => _PopUpWidgetState();
}

class _PopUpWidgetState extends State<PopUpWidget> {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      contentPadding: EdgeInsets.symmetric(horizontal: context.dp(4), vertical: context.dp(2)),
      scrollable: true,
      content: Column(
        children: [
          Image.asset(widget.emoji),
          SizedBox(
            height: context.dp(1),
          ),
          Text(
            widget.title,
            style: TextStyle(fontSize: context.dp(2), fontWeight: FontWeight.w500),
          ),
          SizedBox(
            height: context.dp(1),
          ),
          Text(
            widget.description,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: context.dp(1.6),
            ),
          ),
        ],
      ),
      actionsPadding: EdgeInsets.symmetric(horizontal: context.dp(4)).copyWith(bottom: context.dp(2)),
      actionsAlignment: MainAxisAlignment.center,
      actions: [
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () => widget.onPressed(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: ThemeColors.primary,
                  foregroundColor: ThemeColors.secondary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(1.6))),
                ),
                child: Text(
                  widget.titleBtn,
                  style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.6)),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
