import 'package:pocketbase/pocketbase.dart';

class RemoteError {
  RemoteError({
    this.error,
    this.e,
  });

  final ClientException? error;
  final dynamic e;
}
