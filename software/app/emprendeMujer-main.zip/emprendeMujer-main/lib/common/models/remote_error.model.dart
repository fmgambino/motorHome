
import 'package:emprende_mujer/common/entities/remote_error.entitie.dart';
import 'package:pocketbase/pocketbase.dart';

class RemoteErrorModel extends RemoteError {
  RemoteErrorModel({required super.e, required super.error});

  factory RemoteErrorModel.fromMap(Map<String, dynamic> json) => RemoteErrorModel(
        e: json['e'] as String,
        error: ClientException.fromJson(json['error'] as Map<String, dynamic>),
    );

  Map<String, dynamic> toJson() => {
        'e': e,
        'error': error,
    };
}