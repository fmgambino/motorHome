import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/home/index.dart';
import 'package:emprende_mujer/features/onboarding/index.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  

  @override
  void initState() {
    Future.delayed(const Duration(seconds: 2), () {
      Navigator.of(context).pushReplacement(
        navegarMapaFadeIn(
          context,
          PreferencesApp.token.isEmpty ? const OnboardingScreen() :
          const HomeScreen(),
        ),
      );
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    return Scaffold(
      body: ColoredBox(
        color: ThemeColors.primary,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SvgPicture.asset(
              logoPath,
              width: context.width * 0.5,
            ),
            SizedBox(height: context.dp(3)),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: context.dp(15)),
              child: const LinearProgressIndicator(
                backgroundColor: ThemeColors.letters,
                valueColor: AlwaysStoppedAnimation<Color>(ThemeColors.secondary),
              ),
            ),
            SizedBox(height: context.dp(3)),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: context.dp(9)),
              child: Text(
                l10n.splashPageTitle,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: ThemeColors.letters,
                  fontSize: context.dp(1.6),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
