import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:emprende_mujer/common/entities/http_error.entitie.dart';
import 'package:emprende_mujer/common/helpers/preferences.dart';
import 'package:emprende_mujer/common/interfaces/http.interface.dart';
import 'package:emprende_mujer/injection_container.dart';

class DioAdapter extends HttpInterface {
  DioAdapter() : this._init();

  DioAdapter._init() {
    dio = sl<Dio>();
    // dio.options.baseUrl = dotenv.env['W9']!;
    dio.interceptors.add(LogInterceptor());
    dio.interceptors.add(ManageInterceptor());
  }
  late Dio dio;

  @override
  Future<Either<L, R>> delete<L, R>({
    required String url,
  }) async {
    try {
      final response = await dio.delete<dynamic>(url);
      return Right(response.data as R);
    } catch (e, s) {
      // ignore: lines_longer_than_80_chars
      if (e is DioException) {
        return Left(HttpError(error: e, stackTrace: s) as L);
      }
      return Left(HttpError(e: e, stackTrace: s) as L);
    }
  }

  @override
  Future<Either<L, R>> download<L, R>({
    required String url,
    required String directory,
  }) async {
    try {
      final response = await dio.download(url, directory);
      return Right(response as R);
    } catch (e, s) {
      if (e is DioException) {
        return Left(HttpError(error: e, stackTrace: s) as L);
      }
      return Left(HttpError(e: e, stackTrace: s) as L);
    }
  }

  @override
  Future<Either<L, R>> get<L, R>({
    required String url,
    Map<String, dynamic>? queryParameters,
  }) async {
    try {
      final result = await dio.get<dynamic>(
        url,
        queryParameters: queryParameters,
      );
      return Right(result as R);
    } catch (e, s) {
      if (e is DioException) {
        return Left(HttpError(error: e, stackTrace: s) as L);
      }
      return Left(HttpError(e: e, stackTrace: s) as L);
    }
  }

  @override
  Future<Either<L, R>> post<L, R>({
    required String url,
    dynamic data,
  }) async {
    try {
      final response = await dio.post<dynamic>(url, data: data);
      return Right(response as R);
    } catch (e, s) {
      if (e is DioException) {
        return Left(HttpError(error: e, stackTrace: s) as L);
      }
      return Left(HttpError(e: e, stackTrace: s) as L);
    }
  }

  @override
  Future<Either<L, R>> put<L, R>({
    required String url,
  }) async {
    try {
      final response = await dio.put<dynamic>(url);
      return Right(response.data as R);
    } catch (e, s) {
      if (e is DioException) {
        return Left(HttpError(error: e, stackTrace: s) as L);
      }
      return Left(HttpError(e: e, stackTrace: s) as L);
    }
  }
}

class ManageInterceptor extends Interceptor {
  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    options.headers['Content-Type'] = 'application/json';
    options.headers['Accept'] = 'application/json';
    if (!options.path.contains('login')) {
      options.headers.putIfAbsent(
        'Authorization',
        () => PreferencesApp.token,
      );
    }
    super.onRequest(options, handler);
  }
}
