part of 'authentication_cubit.dart';

sealed class AuthenticationState extends Equatable {
  const AuthenticationState({required this.isLoading, this.auth, this.error});

  final RAuth? auth;
  final bool isLoading;
  final RemoteError? error;

  @override
  List<Object?> get props => [auth, isLoading, error];
}

final class AuthenticationInitial extends AuthenticationState {
  const AuthenticationInitial() : super(auth: null, isLoading: false, error: null);
}

final class AuthenticationLoading extends AuthenticationState {
  const AuthenticationLoading() : super(auth: null, isLoading: true, error: null);
}

class AuthenticationError extends AuthenticationState {
  const AuthenticationError({required RemoteError e}) : super(auth: null, isLoading: false, error: e);
}

class AuthenticationSuccess extends AuthenticationState {
  const AuthenticationSuccess({required this.data}) : super(auth: data, isLoading: false, error: null);
  final RAuth data;
}

class AuthenticationRegisterSuccess extends AuthenticationState {
  const AuthenticationRegisterSuccess({required this.data}) : super(auth: data, isLoading: false, error: null);
  final RAuth data;
}

class AuthenticationRegisterError extends AuthenticationState {
  const AuthenticationRegisterError({required RemoteError e}) : super(auth: null, isLoading: false, error: e);
}
