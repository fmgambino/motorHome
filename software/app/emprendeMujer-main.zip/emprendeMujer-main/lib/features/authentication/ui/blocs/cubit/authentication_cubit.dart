import 'dart:developer';

import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/features/authentication/domain/index.dart';
import 'package:emprende_mujer/features/core/index.dart';
import 'package:equatable/equatable.dart';
import 'package:hydrated_bloc/hydrated_bloc.dart';

// import 'package:pocketbase/pocketbase.dart';

part 'authentication_state.dart';

class AuthenticationCubit extends HydratedCubit<AuthenticationState> {
  AuthenticationCubit({
    required this.singInUsecase,
    required this.registerUsecase,
  }) : super(const AuthenticationInitial());

  final SingInUsecase singInUsecase;
  final RegisterUsecase registerUsecase;

  Future<void> logOut() async {
    PreferencesApp.token = '';
  }

  Future<void> updateUser(RUser user) async {
    emit(AuthenticationSuccess(data: state.auth!.copyWith(record: user)));
  }

  Future<void> singIn({required String email, required String password}) async {
    emit(const AuthenticationLoading());
    final res = await singInUsecase<RemoteError, RAuth>(email: email, password: password);

    final result = res.fold(
      (l) {
        //! manejar error
        log('AuthenticationBloc._getTurnos l: e:   ${l.e}');
        log('AuthenticationBloc._getTurnos l: error:   ${l.error}');
        return l;
      },
      (r) {
        log('AuthenticationBloc._getTurnos r:   ${r.token}');

        // onAuthenticationSuccess(data.turnoId.toString());
        return r;
      },
    );

    if (result is RemoteError) {
      emit(AuthenticationError(e: result));
      return;
    }
    emit(AuthenticationSuccess(data: result as RAuth));
    PreferencesApp.token = result.token!;
  }

  Future<void> register({
    required String email,
    required String name,
    required String lastName,
    required String gender,
    required String phone,
    required String documentType,
    required String documentNumber,
    required String nationality,
    required String department,
  }) async {
    emit(const AuthenticationLoading());
    final res = await registerUsecase<RemoteError, AuthEntitie>(
      email: email,
      name: name,
      lastName: lastName,
      gender: gender,
      phone: phone,
      documentType: documentType,
      documentNumber: documentNumber,
      nationality: nationality,
      department: department,
    );
    final result = res.fold(
      (l) => l,
      (r) => r,
    );
    if (result is RemoteError) {
      emit(AuthenticationRegisterError(e: result));
      return;
    }
    emit(AuthenticationRegisterSuccess(data: result as RAuth));
  }

  @override
  AuthenticationState? fromJson(Map<String, dynamic> json) {
    try {
      final authData = json['auth'] as Map<String, dynamic>?;

      if (authData != null) {
        // final auth = AuthModel.fromMap(authData);

        return AuthenticationSuccess(data: RAuth.fromJson(authData));
      }
    } catch (e) {
      // Manejar cualquier excepción que pueda ocurrir durante el proceso de conversión.
      // Puedes registrar el error o tomar medidas adicionales según tus necesidades.
      log('Error al analizar JSON en fromJson: $e');
    }

    // Si no se puede analizar el JSON o falta información, devolver null o un estado predeterminado.
    return null; // O puedes devolver un valor predeterminado, como AuthenticationInitial();
  }

  @override
  Map<String, dynamic>? toJson(AuthenticationState state) => {
        'auth': state.auth != null ? state.auth!.toJson() : null,
      };
}
