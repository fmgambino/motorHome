import 'dart:developer';

import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/authentication/index.dart';
// import 'package:emprende_mujer/features/authentication/ui/screens/create_account.screen.dart';
import 'package:emprende_mujer/features/home/index.dart';
import 'package:emprende_mujer/injection_container.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final formKey = GlobalKey<FormState>();

  late final TextEditingController userController;

  final passwordController = TextEditingController();

  bool isEmailValid = false;
  bool obscureText = true;

  late final AuthenticationCubit authCubit;

  @override
  void initState() {
    super.initState();
    authCubit = sl.get<AuthenticationCubit>();
    userController = TextEditingController(text: authCubit.state.auth?.record?.email);
    if (userController.text.isNotEmpty) {
      isEmailValid = isEmail(userController.text);
    }
    userController.addListener(() {
      setState(() {
        isEmailValid = isEmail(userController.text);
      });
    });
  }

  @override
  void activate() {
    log('activate');
    super.activate();
  }

  @override
  void deactivate() {
    log('deactivate');
    super.deactivate();
  }

  @override
  void didChangeDependencies() {
    log('didChangeDependencies');
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    userController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  bool isEmail(String value) {
    final emailRegExp = RegExp(r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$');
    return emailRegExp.hasMatch(value);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    return BlocConsumer<AuthenticationCubit, AuthenticationState>(
      builder: (context, state) {
        return GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Scaffold(
            body: SingleChildScrollView(
              child: Stack(
                children: [
                  SizedBox(
                    height: context.height,
                    width: context.width,
                    child: Image.asset(
                      imageLogin,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: FooterLogin(l10n: l10n),
                  ),
                  Positioned.fill(
                    child: SizedBox(
                      child: Form(
                        key: formKey,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              margin: EdgeInsets.symmetric(horizontal: context.dp(2)).copyWith(bottom: context.dp(6)),
                              height: context.hp(50),
                              // color: Colors.red,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  _HeaderLogin(l10n: l10n),
                                  Column(
                                    children: [
                                      SizedBox(
                                        height: context.dp(1),
                                      ),
                                      Container(
                                        height: context.hp(6),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(context.dp(0.6)),
                                        ),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: context.dp(6),
                                              height: double.infinity,
                                              decoration: BoxDecoration(
                                                color: ThemeColors.disabled,
                                                borderRadius:
                                                    BorderRadius.only(bottomLeft: Radius.circular(context.dp(0.6)), topLeft: Radius.circular(context.dp(0.6))),
                                              ),
                                              child: Icon(
                                                Icons.mail_outlined,
                                                color: ThemeColors.lettersDisabled,
                                                size: context.dp(2.5),
                                              ),
                                            ),
                                            Expanded(
                                              child: TextFormField(
                                                textAlignVertical: TextAlignVertical.bottom,
                                                style: TextStyle(color: Colors.black, fontSize: context.dp(1.6)),
                                                textInputAction: TextInputAction.next,
                                                controller: userController,
                                                decoration: InputDecoration(
                                                  suffixIcon: Icon(
                                                    Icons.check_circle,
                                                    color: isEmailValid ? ThemeColors.primary : ThemeColors.disabled,
                                                    size: context.dp(2.5),
                                                  ),
                                                  hintText: l10n.user,
                                                  hintStyle:
                                                      TextStyle(color: ThemeColors.lettersDisabled, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                                  border: const OutlineInputBorder(
                                                    borderSide: BorderSide.none,
                                                  ),
                                                  enabledBorder: const OutlineInputBorder(
                                                    borderSide: BorderSide.none,
                                                  ),
                                                  focusedBorder: const OutlineInputBorder(
                                                    borderSide: BorderSide.none,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        height: context.dp(1),
                                      ),
                                      Container(
                                        height: context.hp(6),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(context.dp(0.6)),
                                        ),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: context.dp(6),
                                              height: double.infinity,
                                              decoration: BoxDecoration(
                                                color: ThemeColors.disabled,
                                                borderRadius:
                                                    BorderRadius.only(bottomLeft: Radius.circular(context.dp(0.6)), topLeft: Radius.circular(context.dp(0.6))),
                                              ),
                                              child: Icon(
                                                Icons.lock_outline,
                                                color: ThemeColors.lettersDisabled,
                                                size: context.dp(2.5),
                                              ),
                                            ),
                                            Expanded(
                                              child: TextFormField(
                                                textAlignVertical: TextAlignVertical.bottom,
                                                textInputAction: TextInputAction.done,
                                                style: TextStyle(color: Colors.black, fontSize: context.dp(1.6)),
                                                controller: passwordController,
                                                obscureText: obscureText,
                                                decoration: InputDecoration(
                                                  suffixIcon: GestureDetector(
                                                    onTap: () => setState(
                                                      () => obscureText = !obscureText,
                                                    ),
                                                    child: Icon(
                                                      obscureText ? FontAwesomeIcons.eyeSlash : FontAwesomeIcons.eye,
                                                      color: ThemeColors.primary,
                                                      size: context.dp(2),
                                                    ),
                                                  ),
                                                  hintText: l10n.password,
                                                  hintStyle:
                                                      TextStyle(color: ThemeColors.lettersDisabled, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                                  border: const OutlineInputBorder(
                                                    borderSide: BorderSide.none,
                                                  ),
                                                  enabledBorder: const OutlineInputBorder(
                                                    borderSide: BorderSide.none,
                                                  ),
                                                  focusedBorder: const OutlineInputBorder(
                                                    borderSide: BorderSide.none,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        height: context.dp(1),
                                      ),
                                      Row(
                                        children: [
                                          Expanded(
                                            child: ElevatedButton(
                                              onPressed: () {
                                                if (!isEmailValid || passwordController.text.isEmpty) return;
                                                authCubit.singIn(
                                                  email: userController.text,
                                                  password: passwordController.text,
                                                );
                                              },
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: ThemeColors.primary,
                                                foregroundColor: ThemeColors.secondary,
                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(1.6))),
                                              ),
                                              child: Text(
                                                l10n.continueButton,
                                                style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.6), fontWeight: FontWeight.w500),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: context.dp(1),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      showDialog<void>(
                                        barrierDismissible: false,
                                        context: context,
                                        builder: (context) {
                                          return const _PopUpWidget();
                                        },
                                      );
                                    },
                                    child: Text(
                                      l10n.forgotPassword,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: context.dp(1.6),
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ),
                                  // GestureDetector(
                                  //   onTap: () {
                                  //     showDialog<void>(
                                  //       barrierDismissible: false,
                                  //       context: context,
                                  //       builder: (context) {
                                  //         return const _PopUpWidget();
                                  //       },
                                  //     );
                                  //   },
                                  //   child: Text(
                                  //     l10n.forgotPassword,
                                  //     style: TextStyle(
                                  //       color: Colors.white,
                                  //       fontSize: context.dp(1.6),
                                  //       fontWeight: FontWeight.w400,
                                  //     ),
                                  //   ),
                                  // ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  if (state.isLoading) const LoadingWidget(),
                ],
              ),
            ),
          ),
        );
      },
      listener: (BuildContext context, AuthenticationState state) {
        if (state is AuthenticationSuccess) {
          Navigator.of(context).pushAndRemoveUntil(
            navegarMapaFadeIn(context, const HomeScreen()),
            (route) => false,
          );
        }
        if (state is AuthenticationError) {
          showDialog<void>(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              return const _PopUpWidget();
            },
          );
        }
      },
    );
  }
}

class _PopUpWidget extends StatefulWidget {
  const _PopUpWidget();

  @override
  State<_PopUpWidget> createState() => _PopUpWidgetState();
}

class _PopUpWidgetState extends State<_PopUpWidget> {
  @override
  Widget build(BuildContext context) {
    log('build');
    return AlertDialog(
      contentPadding: EdgeInsets.symmetric(horizontal: context.dp(4), vertical: context.dp(2)),
      scrollable: true,
      content: Column(
        children: [
          Image.asset(emojiConfoundedFace),
          SizedBox(
            height: context.dp(1),
          ),
          Text(
            '¿Olvidaste tu contraseña?',
            style: TextStyle(fontSize: context.dp(2), fontWeight: FontWeight.w500),
          ),
          SizedBox(
            height: context.dp(1),
          ),
          Text(
            'Si ya creaste tu cuenta, recuerda que tu usuario es tu email y tu contraseña es tu apellido seguido de tu número de documento.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: context.dp(1.6),
            ),
          ),
        ],
      ),
      actionsPadding: EdgeInsets.symmetric(horizontal: context.dp(4)).copyWith(bottom: context.dp(2)),
      actionsAlignment: MainAxisAlignment.center,
      actions: [
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: ThemeColors.primary,
                  foregroundColor: ThemeColors.secondary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(1.6))),
                ),
                child: Text(
                  'Iniciar sessión',
                  style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.6)),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _HeaderLogin extends StatelessWidget {
  const _HeaderLogin({
    required this.l10n,
  });

  final AppLocalizations l10n;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: context.hp(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(context.dp(1.6)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              alignment: Alignment.center,
              margin: EdgeInsets.all(context.dp(0.5)),
              height: double.infinity,
              decoration: BoxDecoration(
                color: ThemeColors.primary,
                borderRadius: BorderRadius.circular(context.dp(1.6)),
              ),
              child: Text(
                l10n.login,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: context.dp(1.6), fontWeight: FontWeight.w500),
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.of(context).push(navegarMapaFadeIn(context, const CreateAccountScreen()));
              },
              child: Text(
                l10n.signUp,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w500),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class FooterLogin extends StatelessWidget {
  const FooterLogin({
    required this.l10n,
    super.key,
  });

  final AppLocalizations l10n;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: context.dp(1)),
      margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(topLeft: Radius.circular(context.dp(1.6)), topRight: Radius.circular(context.dp(1.6))),
        color: Colors.white,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            l10n.by,
            style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
          ),
          SizedBox(
            width: context.dp(1),
          ),
          SvgPicture.asset(
            logoColorPath,
            height: context.dp(2.5),
          ),
        ],
      ),
    );
  }
}
