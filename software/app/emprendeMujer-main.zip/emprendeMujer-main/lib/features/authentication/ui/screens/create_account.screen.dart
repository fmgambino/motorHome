import 'dart:developer';

import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/authentication/ui/blocs/index.dart';
import 'package:emprende_mujer/injection_container.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CreateAccountScreen extends StatefulWidget {
  const CreateAccountScreen({super.key});

  @override
  State<CreateAccountScreen> createState() => _CreateAccountScreenState();
}

class _CreateAccountScreenState extends State<CreateAccountScreen> {
  final globalKey = GlobalKey<FormState>();

  final emailController = TextEditingController();
  final nameController = TextEditingController();

  final lastNameController = TextEditingController();

  final phoneController = TextEditingController();

  final numberController = TextEditingController();

  final nationalityController = TextEditingController();

  final departmentController = TextEditingController();

  late final AuthenticationCubit authenticationCubit;

  String? selectedGender;
  String? selectedTypeDocument;

  @override
  void initState() {
    authenticationCubit = sl.get<AuthenticationCubit>();
    super.initState();
  }

  bool validateForm() {
    if (nameController.text.isEmpty ||
        lastNameController.text.isEmpty ||
        phoneController.text.isEmpty ||
        numberController.text.isEmpty ||
        nationalityController.text.isEmpty ||
        departmentController.text.isEmpty ||
        !isEmail(emailController.text) ||
        selectedGender == null ||
        selectedTypeDocument == null) {
      return false;
    }
    return true;
  }

  bool isEmail(String value) {
    final emailRegExp = RegExp(r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$');
    return emailRegExp.hasMatch(value);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    return BlocConsumer<AuthenticationCubit, AuthenticationState>(
      listener: (context, state) {
        if (state is AuthenticationRegisterSuccess) {
          showDialog<void>(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              return PopUpWidget(
                emoji: emojiSmilingFace,
                title: '¡Felicitaciones!',
                description:
                    'Recuerda que tu usuario es tu email y contraseña es tu apellido seguido de tu número de documento (${lastNameController.text.toUpperCase()}${numberController.text}).',
                titleBtn: 'Iniciar sesión',
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                },
              );
            },
          );
        }
        if (state is AuthenticationRegisterError) {
          showDialog<void>(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              return PopUpWidget(
                emoji: emojiConfoundedFace,
                title: '¡Ups! Algo salió mal',
                description: (state.error != null && state.error?.error != null && state.error?.error!.statusCode == 400)
                    ? 'El email ya se encuentra registrado'
                    : 'Intente nuevamente',
                titleBtn: 'Aceptar',
                onPressed: () {
                  Navigator.of(context).pop();
                },
              );
            },
          );
        }
      },
      builder: (context, state) {
        log('CreateAccountScreen.build state: $state');
        return GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
          },
          child: Scaffold(
            body: SafeArea(
              child: Stack(
                children: [
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: Header(l10n: l10n),
                  ),
                  Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: FooterWidget(l10n: l10n),
                  ),
                  Positioned.fill(
                    top: context.dp(16),
                    child: SingleChildScrollView(
                      child: Container(
                        alignment: Alignment.center,
                        margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
                        decoration: const BoxDecoration(
                          color: Colors.white,
                        ),
                        child: Form(
                          key: globalKey,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _ItemInput(controller: emailController, icon: Icons.mail, name: 'Email', isNumberic: false, isEmail: true, done: false),
                              SizedBox(
                                height: context.dp(1),
                              ),
                              _ItemInput(controller: nameController, icon: Icons.person, name: 'Nombre', isNumberic: false, isEmail: false, done: false),
                              SizedBox(
                                height: context.dp(1),
                              ),
                              _ItemInput(controller: lastNameController, icon: Icons.person, name: 'Apellido', isNumberic: false, isEmail: false, done: false),
                              SizedBox(
                                height: context.dp(1),
                              ),
                              Container(
                                height: context.dp(6),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(context.dp(0.6)),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      width: context.dp(6),
                                      height: double.infinity,
                                      decoration: BoxDecoration(
                                        color: ThemeColors.disabled,
                                        borderRadius:
                                            BorderRadius.only(bottomLeft: Radius.circular(context.dp(0.6)), topLeft: Radius.circular(context.dp(0.6))),
                                      ),
                                      child: Icon(
                                        Icons.person,
                                        color: ThemeColors.lettersDisabled,
                                        size: context.dp(2.5),
                                      ),
                                    ),
                                    Expanded(
                                      child: DropdownButtonHideUnderline(
                                        child: DropdownButton(
                                          value: selectedGender,
                                          padding: EdgeInsets.only(left: context.dp(1), right: context.dp(1)),
                                          isExpanded: true,
                                          hint: Text(
                                            'Género',
                                            style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                          ),
                                          items: [
                                            DropdownMenuItem(
                                              value: 'Masculino',
                                              child: Text(
                                                'Masculino',
                                                style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                              ),
                                            ),
                                            DropdownMenuItem(
                                              value: 'Femenino',
                                              child: Text(
                                                'Femenino',
                                                style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                              ),
                                            ),
                                            DropdownMenuItem(
                                              value: 'Otro',
                                              child: Text(
                                                'Otro',
                                                style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                              ),
                                            ),
                                          ],
                                          onChanged: (value) {
                                            setState(() {
                                              selectedGender = value.toString();
                                            });
                                            FocusScope.of(context).nextFocus();
                                          },
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: context.dp(1),
                              ),
                              _ItemInput(controller: phoneController, icon: Icons.smartphone, name: 'Teléfono', isNumberic: true, isEmail: false, done: false),
                              SizedBox(
                                height: context.dp(1),
                              ),
                              // _ItemInput(icon: Icons.insert_drive_file_outlined, name: 'Tipo de documento'),
                              // build select type document
                              Container(
                                height: context.dp(6),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(context.dp(0.6)),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      width: context.dp(6),
                                      height: double.infinity,
                                      decoration: BoxDecoration(
                                        color: ThemeColors.disabled,
                                        borderRadius:
                                            BorderRadius.only(bottomLeft: Radius.circular(context.dp(0.6)), topLeft: Radius.circular(context.dp(0.6))),
                                      ),
                                      child: Icon(
                                        Icons.insert_drive_file_outlined,
                                        color: ThemeColors.lettersDisabled,
                                        size: context.dp(2.5),
                                      ),
                                    ),
                                    Expanded(
                                      child: DropdownButtonHideUnderline(
                                        child: DropdownButton(
                                          value: selectedTypeDocument,
                                          padding: EdgeInsets.only(left: context.dp(1), right: context.dp(1)),
                                          isExpanded: true,
                                          hint: Text(
                                            'Tipo de documento',
                                            style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                          ),
                                          items: [
                                            DropdownMenuItem(
                                              value: 'C.I.',
                                              child: Text(
                                                'C.I.',
                                                style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                              ),
                                            ),
                                            DropdownMenuItem(
                                              value: 'D.N.I.',
                                              child: Text(
                                                'D.N.I.',
                                                style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                              ),
                                            ),
                                            DropdownMenuItem(
                                              value: 'L.C.',
                                              child: Text(
                                                'L.C.',
                                                style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                              ),
                                            ),
                                            DropdownMenuItem(
                                              value: 'L.E.',
                                              child: Text(
                                                'L.E.',
                                                style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                                              ),
                                            ),
                                          ],
                                          onChanged: (value) {
                                            setState(() {
                                              selectedTypeDocument = value.toString();
                                            });
                                            FocusScope.of(context).nextFocus();
                                          },
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: context.dp(1),
                              ),
                              _ItemInput(
                                controller: numberController,
                                icon: Icons.insert_drive_file_outlined,
                                name: 'número de documento',
                                isNumberic: true,
                                isEmail: false,
                                done: false,
                              ),
                              SizedBox(
                                height: context.dp(1),
                              ),
                              _ItemInput(
                                controller: nationalityController,
                                icon: Icons.location_on_outlined,
                                name: 'Nacionalidad',
                                isNumberic: false,
                                isEmail: false,
                                done: false,
                              ),
                              SizedBox(
                                height: context.dp(1),
                              ),
                              _ItemInput(
                                controller: departmentController,
                                icon: Icons.location_on_outlined,
                                name: 'Departamento',
                                isNumberic: false,
                                isEmail: false,
                                done: true,
                              ),
                              SizedBox(
                                height: context.dp(1),
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton(
                                      onPressed: () {
                                        if (validateForm()) {
                                          final genderValue = selectedGender == 'Masculino'
                                              ? 'M'
                                              : selectedGender == 'Femenino'
                                                  ? 'F'
                                                  : 'X';

                                          authenticationCubit.register(
                                            email: emailController.text,
                                            name: nameController.text.trim(),
                                            lastName: lastNameController.text.trim(),
                                            gender: genderValue,
                                            phone: phoneController.text,
                                            documentType: selectedTypeDocument!,
                                            documentNumber: numberController.text.trim(),
                                            nationality: nameController.text,
                                            department: departmentController.text,
                                          );
                                          log('CreateAccountScreen.build onPressed:');
                                        } else {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                              content:
                                                  Text('Complete todos los campos', textAlign: TextAlign.center, style: TextStyle(fontSize: context.dp(1.6))),
                                              backgroundColor: Colors.red,
                                              duration: const Duration(seconds: 2),
                                            ),
                                          );
                                        }
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: ThemeColors.primary,
                                        foregroundColor: ThemeColors.secondary,
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(1.6))),
                                      ),
                                      child: Text(
                                        'Registrarme',
                                        style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.6), fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  if (state.isLoading) const LoadingWidget(),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ItemInput extends StatefulWidget {
  const _ItemInput({
    required this.icon,
    required this.name,
    required this.controller,
    required this.isNumberic,
    required this.isEmail,
    required this.done,
  });

  final IconData icon;
  final String name;
  final TextEditingController controller;
  final bool isNumberic;
  final bool isEmail;
  final bool done;

  @override
  State<_ItemInput> createState() => _ItemInputState();
}

class _ItemInputState extends State<_ItemInput> {
  bool isCorrect = false;

  @override
  void initState() {
    widget.controller.addListener(() {
      setState(() {
        isCorrect = isValid(widget.controller.text);
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    widget.controller.dispose();
    super.dispose();
  }

  bool isValid(String value) {
    final emailRegExp = RegExp(r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$');
    if (widget.isEmail) {
      return emailRegExp.hasMatch(value);
    }
    return value.isNotEmpty;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: context.hp(6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(context.dp(0.6)),
      ),
      child: Row(
        children: [
          Container(
            width: context.dp(6),
            height: double.infinity,
            decoration: BoxDecoration(
              color: ThemeColors.disabled,
              borderRadius: BorderRadius.only(bottomLeft: Radius.circular(context.dp(0.6)), topLeft: Radius.circular(context.dp(0.6))),
            ),
            child: Icon(
              widget.icon,
              color: ThemeColors.lettersDisabled,
              size: context.dp(2.5),
            ),
          ),
          Expanded(
            child: TextFormField(
              controller: widget.controller,
              keyboardType: widget.isNumberic ? TextInputType.number : TextInputType.text,
              textInputAction: widget.done ? TextInputAction.done : TextInputAction.next,
              decoration: InputDecoration(
                suffixIcon: Icon(
                  Icons.check_circle,
                  color: !isCorrect ? ThemeColors.lettersDisabled : ThemeColors.primary,
                  size: context.dp(2.5),
                ),
                hintText: widget.name,
                hintStyle: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                border: const OutlineInputBorder(
                  borderSide: BorderSide.none,
                ),
                enabledBorder: const OutlineInputBorder(
                  borderSide: BorderSide.none,
                ),
                focusedBorder: const OutlineInputBorder(
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class Tarjeta extends StatelessWidget {
  const Tarjeta({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: context.dp(2), vertical: context.dp(1.5)),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(context.dp(1.6)),
        border: Border.all(color: ThemeColors.lettersDisabled, width: context.dp(0.1)),
      ),
      height: context.dp(15.9),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Una guía paso a paso',
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    color: ThemeColors.lettersDisabled,
                    fontSize: context.dp(1.8),
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(height: context.dp(0.5)),
                Text(
                  'Cómo empezar a crear mis cuentas en las redes sociales',
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: context.dp(1.8),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: context.dp(0.5)),
                Row(
                  children: [
                    Text(
                      'Ver más',
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: context.dp(1.8),
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios_rounded, color: Colors.black, size: context.dp(1.8)),
                  ],
                ),
              ],
            ),
          ),
          Container(
            width: context.dp(9.5),
            height: context.dp(10.1),
            decoration: BoxDecoration(
              color: ThemeColors.letters,
              borderRadius: BorderRadius.circular(context.dp(0.5)),
            ),
            child: Center(
              child: Image.asset(
                social,
                fit: BoxFit.cover,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class Header extends StatelessWidget {
  const Header({
    required this.l10n,
    super.key,
  });

  final AppLocalizations l10n;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: context.dp(15),
      padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
      color: ThemeColors.primary,
      child: Column(
        // mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: context.dp(1),
          ),
          Row(
            children: [
              Container(
                height: context.dp(4),
                width: context.dp(4),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(context.dp(1)),
                ),
                child: IconButton(
                  color: ThemeColors.primary,
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  icon: Icon(
                    Icons.arrow_back_ios_rounded,
                    size: context.dp(2),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(
            height: context.dp(1),
          ),
          Text(
            l10n.createAccount,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: context.dp(3),
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class FooterWidget extends StatelessWidget {
  const FooterWidget({
    required this.l10n,
    super.key,
  });

  final AppLocalizations l10n;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: context.dp(1)),
      margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(topLeft: Radius.circular(context.dp(1.6)), topRight: Radius.circular(context.dp(1.6))),
        color: ThemeColors.primary,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            l10n.by,
            style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
          ),
          SizedBox(
            width: context.dp(1),
          ),
          SvgPicture.asset(
            logoPath,
            height: context.dp(2.5),
          ),
        ],
      ),
    );
  }
}
