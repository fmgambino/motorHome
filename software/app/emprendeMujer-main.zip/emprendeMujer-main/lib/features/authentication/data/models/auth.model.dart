import 'package:emprende_mujer/features/authentication/domain/entities/auth.entitie.dart';
import 'package:emprende_mujer/features/core/data/models/index.dart';

class AuthModel extends AuthEntitie {
  const AuthModel({required super.token, required super.user});

  factory AuthModel.fromMap(Map<String, dynamic> json) => AuthModel(
        token: json['token'] as String,
        user: UserMoldel.fromMap(json['record'] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {
        'token': token,
        // 'record': (user! as UserMoldel).toJson(),
        'record': user != null ? UserMoldel(
          id: user!.id,
          created: user!.created,
          updated: user!.updated,
          avatar: user!.avatar,
          badges: user!.badges,
          courses: user!.courses,
          email: user!.email,
          emailVisibility: user!.emailVisibility,
          name: user!.name,
          username: user!.username,
          verified: user!.verified,
          department: user!.department,
          documentNumber: user!.documentNumber,
          documentType: user!.documentType,
          gender: user!.gender,
          nationality: user!.nationality,
          phone: user!.phone,
        ).toJson() : null,
      };
}
