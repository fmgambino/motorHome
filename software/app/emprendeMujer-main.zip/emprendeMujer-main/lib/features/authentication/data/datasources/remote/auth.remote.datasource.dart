// import 'dart:developer';

import 'dart:developer';

import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/features/authentication/domain/index.dart';
import 'package:pocketbase/pocketbase.dart';

abstract class AuthRemoteDatasource {
  Future<Either<L, R>> singin<L, R>({required String email, required String password});
  Future<Either<L, R>> register<L, R>({
    required String email,
    required String name,
    required String lastName,
    required String gender,
    required String phone,
    required String documentType,
    required String documentNumber,
    required String nationality,
    required String department,
  });
}

class AuthRemoteDatasourceImpl implements AuthRemoteDatasource {
  AuthRemoteDatasourceImpl({required this.pb});

  final PocketBase pb;

  @override
  Future<Either<L, R>> singin<L, R>({required String email, required String password}) async {
    try {
      final res = await pb.collection('users').authWithPassword(
            email,
            password,
            expand:
                'courses.videos,courses.questions,courses.questions.options,courses.questions.correct,badges,completed_courses.videos,completed_courses.questions,completed_courses.questions.options,completed_courses.questions.correct',
          );
      final map = res.toJson();
      log('map: $map');
      // final auth = AuthModel.fromMap(map);
      final rAuth = RAuth.fromJson(map);
      return Right(rAuth as R);
    } catch (e) {
      if (e is ClientException) {
        return Left(RemoteError(error: e) as L);
      }
      return Left(RemoteError(e: e) as L);
    }
  }

  @override
  Future<Either<L, R>> register<L, R>({
    required String email,
    required String name,
    required String lastName,
    required String gender,
    required String phone,
    required String documentType,
    required String documentNumber,
    required String nationality,
    required String department,
  }) async {
    final body = {
      'email': email,
      'name': '$name, $lastName',
      'gender': gender,
      'phone': phone,
      'document_type': documentType,
      'document_number': documentNumber,
      'nationality': nationality,
      'department': department,
      'password': '${lastName.toUpperCase()}$documentNumber',
      'passwordConfirm': '${lastName.toUpperCase()}$documentNumber',
    };
    try {
      final res = await pb.collection('users').create(
            body: body,
          );
      log('res: ${res.toJson()}');
      // final auth = AuthModel(
      //   token: '',
      //   user: UserMoldel.fromMap(res.toJson()).copyWith(
      //     email: email,
      //   ),
      // );
      final auth = RAuth.fromJson(res.toJson());
      return Right(auth as R);
    } catch (e) {
      log('error: $e');
      if (e is ClientException) {
        return Left(RemoteError(error: e) as L);
      }
      return Left(RemoteError(e: e) as L);
    }
  }
}
