import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/features/authentication/data/datasources/index.dart';
import 'package:emprende_mujer/features/authentication/domain/index.dart';

class AuthenticationRepositoryImpl extends AuthenticationRepository {
  AuthenticationRepositoryImpl({required this.remote});

  final AuthRemoteDatasource remote;

  @override
  Future<Either<L, R>> singin<L, R>({required String email, required String password}) async => remote.singin(email: email, password: password);

  @override
  Future<Either<L, R>> register<L, R>({
    required String email,
    required String name,
    required String lastName,
    required String gender,
    required String phone,
    required String documentType,
    required String documentNumber,
    required String nationality,
    required String department,
  }) async =>
      remote.register(
        email: email,
        name: name,
        lastName: lastName,
        gender: gender,
        phone: phone,
        documentType: documentType,
        documentNumber: documentNumber,
        nationality: nationality,
        department: department,
      );
}
