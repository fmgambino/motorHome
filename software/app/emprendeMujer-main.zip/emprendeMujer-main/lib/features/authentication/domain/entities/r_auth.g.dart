// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'r_auth.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RAuthImpl _$$RAuthImplFromJson(Map<String, dynamic> json) => _$RAuthImpl(
      token: json['token'] as String?,
      record: json['record'] == null
          ? null
          : RUser.fromJson(json['record'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$$RAuthImplToJson(_$RAuthImpl instance) =>
    <String, dynamic>{
      'token': instance.token,
      'record': instance.record,
    };
