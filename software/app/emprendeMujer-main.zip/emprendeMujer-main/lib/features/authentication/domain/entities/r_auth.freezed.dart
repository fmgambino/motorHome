// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'r_auth.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

RAuth _$RAuthFromJson(Map<String, dynamic> json) {
  return _RAuth.fromJson(json);
}

/// @nodoc
mixin _$RAuth {
  String? get token => throw _privateConstructorUsedError;
  RUser? get record => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RAuthCopyWith<RAuth> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RAuthCopyWith<$Res> {
  factory $RAuthCopyWith(RAuth value, $Res Function(RAuth) then) =
      _$RAuthCopyWithImpl<$Res, RAuth>;
  @useResult
  $Res call({String? token, RUser? record});

  $RUserCopyWith<$Res>? get record;
}

/// @nodoc
class _$RAuthCopyWithImpl<$Res, $Val extends RAuth>
    implements $RAuthCopyWith<$Res> {
  _$RAuthCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? token = freezed,
    Object? record = freezed,
  }) {
    return _then(_value.copyWith(
      token: freezed == token
          ? _value.token
          : token // ignore: cast_nullable_to_non_nullable
              as String?,
      record: freezed == record
          ? _value.record
          : record // ignore: cast_nullable_to_non_nullable
              as RUser?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $RUserCopyWith<$Res>? get record {
    if (_value.record == null) {
      return null;
    }

    return $RUserCopyWith<$Res>(_value.record!, (value) {
      return _then(_value.copyWith(record: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$RAuthImplCopyWith<$Res> implements $RAuthCopyWith<$Res> {
  factory _$$RAuthImplCopyWith(
          _$RAuthImpl value, $Res Function(_$RAuthImpl) then) =
      __$$RAuthImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String? token, RUser? record});

  @override
  $RUserCopyWith<$Res>? get record;
}

/// @nodoc
class __$$RAuthImplCopyWithImpl<$Res>
    extends _$RAuthCopyWithImpl<$Res, _$RAuthImpl>
    implements _$$RAuthImplCopyWith<$Res> {
  __$$RAuthImplCopyWithImpl(
      _$RAuthImpl _value, $Res Function(_$RAuthImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? token = freezed,
    Object? record = freezed,
  }) {
    return _then(_$RAuthImpl(
      token: freezed == token
          ? _value.token
          : token // ignore: cast_nullable_to_non_nullable
              as String?,
      record: freezed == record
          ? _value.record
          : record // ignore: cast_nullable_to_non_nullable
              as RUser?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RAuthImpl implements _RAuth {
  const _$RAuthImpl({required this.token, required this.record});

  factory _$RAuthImpl.fromJson(Map<String, dynamic> json) =>
      _$$RAuthImplFromJson(json);

  @override
  final String? token;
  @override
  final RUser? record;

  @override
  String toString() {
    return 'RAuth(token: $token, record: $record)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RAuthImpl &&
            (identical(other.token, token) || other.token == token) &&
            (identical(other.record, record) || other.record == record));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, token, record);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RAuthImplCopyWith<_$RAuthImpl> get copyWith =>
      __$$RAuthImplCopyWithImpl<_$RAuthImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RAuthImplToJson(
      this,
    );
  }
}

abstract class _RAuth implements RAuth {
  const factory _RAuth(
      {required final String? token,
      required final RUser? record}) = _$RAuthImpl;

  factory _RAuth.fromJson(Map<String, dynamic> json) = _$RAuthImpl.fromJson;

  @override
  String? get token;
  @override
  RUser? get record;
  @override
  @JsonKey(ignore: true)
  _$$RAuthImplCopyWith<_$RAuthImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
