import 'package:dartz/dartz.dart';

abstract class AuthenticationRepository {
  Future<Either<L, R>> singin<L, R>({
    required String email,
    required String password,
  });

  Future<Either<L, R>> register<L, R>({
    required String email,
    required String name,
    required String lastName,
    required String gender,
    required String phone,
    required String documentType,
    required String documentNumber,
    required String nationality,
    required String department,
  });
}
