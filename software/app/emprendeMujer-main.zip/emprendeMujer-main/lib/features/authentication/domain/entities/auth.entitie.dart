import 'package:emprende_mujer/features/core/domain/entities/index.dart';
import 'package:equatable/equatable.dart';

class AuthEntitie extends Equatable {
  const AuthEntitie({required this.token, required this.user});

  final String? token;
  final UserEntitie? user;

  AuthEntitie copyWith({
    String? token,
    UserEntitie? user,
  }) =>
      AuthEntitie(
        token: token ?? this.token,
        user: user ?? this.user,
      );

  @override
  List<Object?> get props => [token, user];
}
