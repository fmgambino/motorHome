import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/features/authentication/domain/repositories/authentication.repository.dart';

class RegisterUsecase {
  const RegisterUsecase(this.repository);

  final AuthenticationRepository repository;

  Future<Either<L, R>> call<L, R>({
    required String email,
    required String name,
    required String lastName,
    required String gender,
    required String phone,
    required String documentType,
    required String documentNumber,
    required String nationality,
    required String department,
  }) async =>
      repository.register(
        email: email,
        name: name,
        lastName: lastName,
        gender: gender,
        phone: phone,
        documentType: documentType,
        documentNumber: documentNumber,
        nationality: nationality,
        department: department,
      );
}
