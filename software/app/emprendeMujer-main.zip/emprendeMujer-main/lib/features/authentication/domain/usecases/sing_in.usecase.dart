import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/features/authentication/domain/repositories/authentication.repository.dart';

class SingInUsecase {
	const SingInUsecase(this.repository);

	final AuthenticationRepository repository;

	Future<Either<L, R>> call<L,R>({ required String email, required String password }) async => repository.singin(email: email, password: password);

}