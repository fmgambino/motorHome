import 'package:emprende_mujer/features/core/domain/entities/user/r_user.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'r_auth.freezed.dart';
part 'r_auth.g.dart';

@freezed
class RAuth with _$RAuth {
  const factory RAuth({
    required String? token,
    required RUser? record,
  }) = _RAuth;

  factory RAuth.fromJson(Map<String, Object?> json) => _$RAuthFromJson(json);
}
