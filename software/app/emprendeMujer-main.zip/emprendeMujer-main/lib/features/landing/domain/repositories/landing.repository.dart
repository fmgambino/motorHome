

abstract class LandingRepository {


}