import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/authentication/ui/screens/login.screen.dart';
import 'package:emprende_mujer/features/core/index.dart';
import 'package:emprende_mujer/injection_container.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

class LeadingScreen extends StatefulWidget {
  const LeadingScreen({super.key});

  @override
  State<LeadingScreen> createState() => _LeadingScreenState();
}

class _LeadingScreenState extends State<LeadingScreen> {
  late final CoreBloc coreBloc;

  @override
  void initState() {
    super.initState();
    coreBloc = sl.get<CoreBloc>()..add(GetAllInfographicsEvent());
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    return BlocBuilder<CoreBloc, CoreState>(
      builder: (context, state) {
        return Scaffold(
          body: Column(
            children: [
              Header(l10n: l10n),
              SizedBox(height: context.dp(1.5)),
              Expanded(
                flex: 7,
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(context.dp(1.6)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        child: ListView.separated(
                          padding: EdgeInsets.zero,
                          itemCount: state.infographics.length,
                          itemBuilder: (BuildContext context, int index) {
                            return Tarjeta(data: state.infographics[index]);
                          },
                          separatorBuilder: (BuildContext context, int index) {
                            return SizedBox(height: context.dp(1.5));
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: context.dp(6)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).pushAndRemoveUntil(
                              navegarMapaFadeIn(context, const LoginScreen()),
                              (Route<dynamic> route) => false,
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: ThemeColors.primary,
                            foregroundColor: ThemeColors.secondary,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(1.6))),
                          ),
                          child: Text(
                            'iniciar sesión',
                            style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.6), fontWeight: FontWeight.w500),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              FooterWidget(l10n: l10n),
            ],
          ),
        );
      },
    );
  }
}

class Tarjeta extends StatelessWidget {
  const Tarjeta({
    required this.data,
    super.key,
  });

  final Map<String, dynamic> data;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: context.dp(2), vertical: context.dp(1.5)),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(context.dp(1.6)),
        border: Border.all(color: ThemeColors.lettersDisabled, width: context.dp(0.1)),
      ),
      // height: context.dp(15.9),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  data['title'] as String,
                  textAlign: TextAlign.start,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: ThemeColors.lettersDisabled,
                    fontSize: context.dp(1.8),
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(height: context.dp(0.5)),
                Text(
                  data['description'] as String,
                  textAlign: TextAlign.start,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: context.dp(1.8),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: context.dp(0.5)),
                InkWell(
                  onTap: () {
                    Navigator.of(context).push(
                      navegarMapaFadeIn(
                        context,
                        _Description(
                          data: data,
                        ),
                      ),
                    );
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Ver más',
                        textAlign: TextAlign.start,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: context.dp(1.8),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      Icon(Icons.arrow_forward_ios_rounded, color: Colors.black, size: context.dp(1.8)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Hero(
              tag: data['image'] as String,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(context.dp(0.5)),
                  border: Border.all(color: ThemeColors.lettersDisabled, width: context.dp(0.1)),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(context.dp(0.5)),
                  child: Image.network(
                    fit: BoxFit.fill,
                    'https://emprende-mujer.pockethost.io/api/files/${data['collectionId']}/${data['id']}/${data['image']}',
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class Header extends StatelessWidget {
  const Header({
    required this.l10n,
    super.key,
  });

  final AppLocalizations l10n;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 3,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
        color: Colors.transparent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              l10n.leadingTitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.black,
                fontSize: context.dp(4),
                fontWeight: FontWeight.w700,
              ),
            ),
            SizedBox(
              height: context.dp(1.4),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ThemeColors.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(context.dp(1)), bottomLeft: Radius.circular(context.dp(1))),
                    ),
                  ),
                  onPressed: () {},
                  child: Text(
                    l10n.leadingButton1,
                    style: TextStyle(
                      color: ThemeColors.letters,
                      fontWeight: FontWeight.w600,
                      fontSize: context.dp(1.6),
                    ),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ThemeColors.disabled,
                    shape: const RoundedRectangleBorder(),
                  ),
                  onPressed: () {},
                  child: Text(
                    l10n.leadingButton2,
                    style: TextStyle(
                      color: ThemeColors.lettersDisabled,
                      fontWeight: FontWeight.w600,
                      fontSize: context.dp(1.6),
                    ),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ThemeColors.disabled,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(topRight: Radius.circular(context.dp(1)), bottomRight: Radius.circular(context.dp(1))),
                    ),
                  ),
                  onPressed: () {},
                  child: Text(
                    l10n.leadingButton3,
                    style: TextStyle(
                      color: ThemeColors.lettersDisabled,
                      fontWeight: FontWeight.w600,
                      fontSize: context.dp(1.6),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class FooterWidget extends StatelessWidget {
  const FooterWidget({
    required this.l10n,
    super.key,
  });

  final AppLocalizations l10n;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(topLeft: Radius.circular(context.dp(1.6)), topRight: Radius.circular(context.dp(1.6))),
          color: ThemeColors.primary,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              l10n.by,
              style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
            ),
            SizedBox(
              width: context.dp(1),
            ),
            SvgPicture.asset(
              logoPath,
              height: context.dp(2.5),
            ),
          ],
        ),
      ),
    );
  }
}

class _Description extends StatelessWidget {
  const _Description({
    required this.data,
  });
  final Map<String, dynamic> data;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: ThemeColors.primary,
        centerTitle: true,
        title: Text(
          'Descripción',
          style: TextStyle(
            color: ThemeColors.letters,
            fontSize: context.dp(1.8),
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(context.dp(1)),
          child: Column(
            children: [
              Hero(
                tag: data['image'] as String,
                child: Image.network(
                  fit: BoxFit.fill,
                  'https://emprende-mujer.pockethost.io/api/files/${data['collectionId']}/${data['id']}/${data['image']}',
                ),
              ),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: data['title'] as String,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: context.dp(2.5),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    TextSpan(
                      text: '\n${data['description'] as String}',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: context.dp(2),
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
