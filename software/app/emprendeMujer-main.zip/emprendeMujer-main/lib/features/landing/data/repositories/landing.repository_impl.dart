import 'package:emprende_mujer/features/landing/domain/index.dart';

class LandingRepositoryImpl extends LandingRepository {

}