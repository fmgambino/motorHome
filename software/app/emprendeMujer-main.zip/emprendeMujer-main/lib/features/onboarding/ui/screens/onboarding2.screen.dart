import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/authentication/index.dart';
import 'package:emprende_mujer/features/landing/index.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';

class Onboarding2Screen extends StatelessWidget {
  const Onboarding2Screen({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage(imageComenzar2),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            const Spacer(
              flex: 6,
            ),
            Expanded(
              flex: 4,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: context.dp(6)),
                child: SizedBox(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).push(navegarMapaFadeIn(context, const LeadingScreen()));

                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: ThemeColors.primary,
                          foregroundColor: ThemeColors.secondary,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(1.6))),
                        ),
                        child: Text(
                          l10n.button2,
                          style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.6), fontWeight: FontWeight.w500),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).push(navegarMapaFadeIn(context, const LoginScreen()));
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: ThemeColors.primary,
                          foregroundColor: ThemeColors.secondary,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(1.6))),
                        ),
                        child: Text(
                          l10n.button3,
                          style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.6), fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const Spacer(
              flex: 2,
            ),
          ],
        ),
      ),
    );
  }
}
