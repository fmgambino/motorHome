// import 'dart:developer';

import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/onboarding/ui/screens/onboarding2.screen.dart';
// import 'package:emprende_mujer/injection_container.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
// import 'package:pocketbase/pocketbase.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  // void getUser() async {
  //   final pb = sl.get<PocketBase>();
  //   await pb.collection('users').authWithPassword('test@mail.com', '12345678')
  //   .then((value) {
    
  //     log('value.record: ${value.record}');
  //     log('value.record.data: ${value.record!.data}');
  //     log('value.record.data.runtimeType: ${value.record!.data.runtimeType}');
  //     log('value.token: ${value.token}');
  //     log('value.meta: ${value.meta}');
  //     log('value.runtimeType: ${value.runtimeType}');
  //    })
  //   .catchError((dynamic e) {
  //     if (e is ClientException) {
  //       log('e.statusCode ${e.statusCode}');
  //       log('e.isAbort ${e.isAbort}');
  //       log('e.originalError ${e.originalError}');
  //       log('e.response ${e.response}');
  //       log('e.url ${e.url}');
  //     }
  //     log('error: $e');
  //     log('error: ${e.runtimeType}');
  //   });

   
  // }

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage(imageComenzar),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            const Spacer(
              flex: 6,
            ),
            Expanded(
              flex: 4,
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(context.dp(1.6)),
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: context.dp(4)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        l10n.onBoardingtitle,
                        textAlign: TextAlign.center,
                        style: TextStyle(color: ThemeColors.primary, fontSize: context.dp(4), fontWeight: FontWeight.w700),
                      ),
                      SizedBox(
                        height: context.dp(1.4),
                      ),
                      RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: l10n.onBoardingDescription,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: context.dp(2),
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                            TextSpan(
                              text: '\n${l10n.onBoardingDescription2}',
                              style: TextStyle(
                                color: ThemeColors.primary,
                                fontSize: context.dp(2),
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: context.dp(1.6),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          // getUser();
                          Navigator.of(context).push(navegarMapaFadeIn(context, const Onboarding2Screen()));
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: ThemeColors.primary,
                          foregroundColor: ThemeColors.secondary,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(1.6))),
                        ),
                        child: Text(
                          l10n.button1,
                          style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.6), fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const Spacer(),
            Expanded(
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(context.dp(1.6)), topRight: Radius.circular(context.dp(1.6))),
                  color: Colors.white,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      l10n.by,
                      style: TextStyle(color: Colors.black, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                    ),
                    SizedBox(
                      width: context.dp(1),
                    ),
                    SvgPicture.asset(
                      logoColorPath,
                      height: context.dp(2.5),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
