import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/features/courses/domain/repositories/courses.repository.dart';

class StartCourseUsecase {
  const StartCourseUsecase(this.repository);

  final CoursesRepository repository;

  Future<Either<L, R>> call<L, R>({
    required String idCourse,
    required List<String> students,
  }) async =>
      repository.startCourse(idCourse, students);
}
