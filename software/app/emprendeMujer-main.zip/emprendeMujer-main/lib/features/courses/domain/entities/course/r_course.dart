import 'package:emprende_mujer/features/courses/domain/entities/e_course/e_course.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'r_course.freezed.dart';
part 'r_course.g.dart';

@freezed
class RCourse with _$RCourse {
  const factory RCourse({
    required String? id,
    required DateTime? created,
    required DateTime? updated,
    required String? collectionId,
    required String? collectionName,
    required ECourse? expand,
    required String? description,
    required String? conclusion,
    required String? duration,
    required String? image,
    required String? level,
    required List<String>? questions,
    required int? score,
    required String? title,
    required List<String>? videos,
    required List<String>? students,
    @Default(false) bool? finalized,
    @Default(0) int? progress,
    @Default(false) bool? certificate,
  }) = _RCourse;

  factory RCourse.fromJson(Map<String, Object?> json) => _$RCourseFromJson(json);
}
