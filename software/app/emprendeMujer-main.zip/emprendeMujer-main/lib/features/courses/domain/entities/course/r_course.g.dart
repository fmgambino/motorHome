// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'r_course.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RCourseImpl _$$RCourseImplFromJson(Map<String, dynamic> json) =>
    _$RCourseImpl(
      id: json['id'] as String?,
      created: json['created'] == null
          ? null
          : DateTime.parse(json['created'] as String),
      updated: json['updated'] == null
          ? null
          : DateTime.parse(json['updated'] as String),
      collectionId: json['collectionId'] as String?,
      collectionName: json['collectionName'] as String?,
      expand: json['expand'] == null
          ? null
          : ECourse.fromJson(json['expand'] as Map<String, dynamic>),
      description: json['description'] as String?,
      conclusion: json['conclusion'] as String?,
      duration: json['duration'] as String?,
      image: json['image'] as String?,
      level: json['level'] as String?,
      questions: (json['questions'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
      score: json['score'] as int?,
      title: json['title'] as String?,
      videos:
          (json['videos'] as List<dynamic>?)?.map((e) => e as String).toList(),
      students: (json['students'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
      finalized: json['finalized'] as bool? ?? false,
      progress: json['progress'] as int? ?? 0,
      certificate: json['certificate'] as bool? ?? false,
    );

Map<String, dynamic> _$$RCourseImplToJson(_$RCourseImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'created': instance.created?.toIso8601String(),
      'updated': instance.updated?.toIso8601String(),
      'collectionId': instance.collectionId,
      'collectionName': instance.collectionName,
      'expand': instance.expand,
      'description': instance.description,
      'conclusion': instance.conclusion,
      'duration': instance.duration,
      'image': instance.image,
      'level': instance.level,
      'questions': instance.questions,
      'score': instance.score,
      'title': instance.title,
      'videos': instance.videos,
      'students': instance.students,
      'finalized': instance.finalized,
      'progress': instance.progress,
      'certificate': instance.certificate,
    };
