// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'e_course.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ECourseImpl _$$ECourseImplFromJson(Map<String, dynamic> json) =>
    _$ECourseImpl(
      questions: (json['questions'] as List<dynamic>?)
          ?.map((e) => RQuestion.fromJson(e as Map<String, dynamic>))
          .toList(),
      videos: (json['videos'] as List<dynamic>?)
          ?.map((e) => RVideo.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$ECourseImplToJson(_$ECourseImpl instance) =>
    <String, dynamic>{
      'questions': instance.questions,
      'videos': instance.videos,
    };
