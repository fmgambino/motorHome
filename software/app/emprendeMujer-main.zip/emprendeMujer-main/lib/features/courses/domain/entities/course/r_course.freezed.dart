// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'r_course.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

RCourse _$RCourseFromJson(Map<String, dynamic> json) {
  return _RCourse.fromJson(json);
}

/// @nodoc
mixin _$RCourse {
  String? get id => throw _privateConstructorUsedError;
  DateTime? get created => throw _privateConstructorUsedError;
  DateTime? get updated => throw _privateConstructorUsedError;
  String? get collectionId => throw _privateConstructorUsedError;
  String? get collectionName => throw _privateConstructorUsedError;
  ECourse? get expand => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  String? get conclusion => throw _privateConstructorUsedError;
  String? get duration => throw _privateConstructorUsedError;
  String? get image => throw _privateConstructorUsedError;
  String? get level => throw _privateConstructorUsedError;
  List<String>? get questions => throw _privateConstructorUsedError;
  int? get score => throw _privateConstructorUsedError;
  String? get title => throw _privateConstructorUsedError;
  List<String>? get videos => throw _privateConstructorUsedError;
  List<String>? get students => throw _privateConstructorUsedError;
  bool? get finalized => throw _privateConstructorUsedError;
  int? get progress => throw _privateConstructorUsedError;
  bool? get certificate => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RCourseCopyWith<RCourse> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RCourseCopyWith<$Res> {
  factory $RCourseCopyWith(RCourse value, $Res Function(RCourse) then) =
      _$RCourseCopyWithImpl<$Res, RCourse>;
  @useResult
  $Res call(
      {String? id,
      DateTime? created,
      DateTime? updated,
      String? collectionId,
      String? collectionName,
      ECourse? expand,
      String? description,
      String? conclusion,
      String? duration,
      String? image,
      String? level,
      List<String>? questions,
      int? score,
      String? title,
      List<String>? videos,
      List<String>? students,
      bool? finalized,
      int? progress,
      bool? certificate});

  $ECourseCopyWith<$Res>? get expand;
}

/// @nodoc
class _$RCourseCopyWithImpl<$Res, $Val extends RCourse>
    implements $RCourseCopyWith<$Res> {
  _$RCourseCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? created = freezed,
    Object? updated = freezed,
    Object? collectionId = freezed,
    Object? collectionName = freezed,
    Object? expand = freezed,
    Object? description = freezed,
    Object? conclusion = freezed,
    Object? duration = freezed,
    Object? image = freezed,
    Object? level = freezed,
    Object? questions = freezed,
    Object? score = freezed,
    Object? title = freezed,
    Object? videos = freezed,
    Object? students = freezed,
    Object? finalized = freezed,
    Object? progress = freezed,
    Object? certificate = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      created: freezed == created
          ? _value.created
          : created // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updated: freezed == updated
          ? _value.updated
          : updated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      collectionId: freezed == collectionId
          ? _value.collectionId
          : collectionId // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionName: freezed == collectionName
          ? _value.collectionName
          : collectionName // ignore: cast_nullable_to_non_nullable
              as String?,
      expand: freezed == expand
          ? _value.expand
          : expand // ignore: cast_nullable_to_non_nullable
              as ECourse?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      conclusion: freezed == conclusion
          ? _value.conclusion
          : conclusion // ignore: cast_nullable_to_non_nullable
              as String?,
      duration: freezed == duration
          ? _value.duration
          : duration // ignore: cast_nullable_to_non_nullable
              as String?,
      image: freezed == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String?,
      level: freezed == level
          ? _value.level
          : level // ignore: cast_nullable_to_non_nullable
              as String?,
      questions: freezed == questions
          ? _value.questions
          : questions // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      score: freezed == score
          ? _value.score
          : score // ignore: cast_nullable_to_non_nullable
              as int?,
      title: freezed == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String?,
      videos: freezed == videos
          ? _value.videos
          : videos // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      students: freezed == students
          ? _value.students
          : students // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      finalized: freezed == finalized
          ? _value.finalized
          : finalized // ignore: cast_nullable_to_non_nullable
              as bool?,
      progress: freezed == progress
          ? _value.progress
          : progress // ignore: cast_nullable_to_non_nullable
              as int?,
      certificate: freezed == certificate
          ? _value.certificate
          : certificate // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $ECourseCopyWith<$Res>? get expand {
    if (_value.expand == null) {
      return null;
    }

    return $ECourseCopyWith<$Res>(_value.expand!, (value) {
      return _then(_value.copyWith(expand: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$RCourseImplCopyWith<$Res> implements $RCourseCopyWith<$Res> {
  factory _$$RCourseImplCopyWith(
          _$RCourseImpl value, $Res Function(_$RCourseImpl) then) =
      __$$RCourseImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      DateTime? created,
      DateTime? updated,
      String? collectionId,
      String? collectionName,
      ECourse? expand,
      String? description,
      String? conclusion,
      String? duration,
      String? image,
      String? level,
      List<String>? questions,
      int? score,
      String? title,
      List<String>? videos,
      List<String>? students,
      bool? finalized,
      int? progress,
      bool? certificate});

  @override
  $ECourseCopyWith<$Res>? get expand;
}

/// @nodoc
class __$$RCourseImplCopyWithImpl<$Res>
    extends _$RCourseCopyWithImpl<$Res, _$RCourseImpl>
    implements _$$RCourseImplCopyWith<$Res> {
  __$$RCourseImplCopyWithImpl(
      _$RCourseImpl _value, $Res Function(_$RCourseImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? created = freezed,
    Object? updated = freezed,
    Object? collectionId = freezed,
    Object? collectionName = freezed,
    Object? expand = freezed,
    Object? description = freezed,
    Object? conclusion = freezed,
    Object? duration = freezed,
    Object? image = freezed,
    Object? level = freezed,
    Object? questions = freezed,
    Object? score = freezed,
    Object? title = freezed,
    Object? videos = freezed,
    Object? students = freezed,
    Object? finalized = freezed,
    Object? progress = freezed,
    Object? certificate = freezed,
  }) {
    return _then(_$RCourseImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      created: freezed == created
          ? _value.created
          : created // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updated: freezed == updated
          ? _value.updated
          : updated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      collectionId: freezed == collectionId
          ? _value.collectionId
          : collectionId // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionName: freezed == collectionName
          ? _value.collectionName
          : collectionName // ignore: cast_nullable_to_non_nullable
              as String?,
      expand: freezed == expand
          ? _value.expand
          : expand // ignore: cast_nullable_to_non_nullable
              as ECourse?,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      conclusion: freezed == conclusion
          ? _value.conclusion
          : conclusion // ignore: cast_nullable_to_non_nullable
              as String?,
      duration: freezed == duration
          ? _value.duration
          : duration // ignore: cast_nullable_to_non_nullable
              as String?,
      image: freezed == image
          ? _value.image
          : image // ignore: cast_nullable_to_non_nullable
              as String?,
      level: freezed == level
          ? _value.level
          : level // ignore: cast_nullable_to_non_nullable
              as String?,
      questions: freezed == questions
          ? _value._questions
          : questions // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      score: freezed == score
          ? _value.score
          : score // ignore: cast_nullable_to_non_nullable
              as int?,
      title: freezed == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String?,
      videos: freezed == videos
          ? _value._videos
          : videos // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      students: freezed == students
          ? _value._students
          : students // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      finalized: freezed == finalized
          ? _value.finalized
          : finalized // ignore: cast_nullable_to_non_nullable
              as bool?,
      progress: freezed == progress
          ? _value.progress
          : progress // ignore: cast_nullable_to_non_nullable
              as int?,
      certificate: freezed == certificate
          ? _value.certificate
          : certificate // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RCourseImpl implements _RCourse {
  const _$RCourseImpl(
      {required this.id,
      required this.created,
      required this.updated,
      required this.collectionId,
      required this.collectionName,
      required this.expand,
      required this.description,
      required this.conclusion,
      required this.duration,
      required this.image,
      required this.level,
      required final List<String>? questions,
      required this.score,
      required this.title,
      required final List<String>? videos,
      required final List<String>? students,
      this.finalized = false,
      this.progress = 0,
      this.certificate = false})
      : _questions = questions,
        _videos = videos,
        _students = students;

  factory _$RCourseImpl.fromJson(Map<String, dynamic> json) =>
      _$$RCourseImplFromJson(json);

  @override
  final String? id;
  @override
  final DateTime? created;
  @override
  final DateTime? updated;
  @override
  final String? collectionId;
  @override
  final String? collectionName;
  @override
  final ECourse? expand;
  @override
  final String? description;
  @override
  final String? conclusion;
  @override
  final String? duration;
  @override
  final String? image;
  @override
  final String? level;
  final List<String>? _questions;
  @override
  List<String>? get questions {
    final value = _questions;
    if (value == null) return null;
    if (_questions is EqualUnmodifiableListView) return _questions;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  final int? score;
  @override
  final String? title;
  final List<String>? _videos;
  @override
  List<String>? get videos {
    final value = _videos;
    if (value == null) return null;
    if (_videos is EqualUnmodifiableListView) return _videos;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<String>? _students;
  @override
  List<String>? get students {
    final value = _students;
    if (value == null) return null;
    if (_students is EqualUnmodifiableListView) return _students;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  @JsonKey()
  final bool? finalized;
  @override
  @JsonKey()
  final int? progress;
  @override
  @JsonKey()
  final bool? certificate;

  @override
  String toString() {
    return 'RCourse(id: $id, created: $created, updated: $updated, collectionId: $collectionId, collectionName: $collectionName, expand: $expand, description: $description, conclusion: $conclusion, duration: $duration, image: $image, level: $level, questions: $questions, score: $score, title: $title, videos: $videos, students: $students, finalized: $finalized, progress: $progress, certificate: $certificate)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RCourseImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.created, created) || other.created == created) &&
            (identical(other.updated, updated) || other.updated == updated) &&
            (identical(other.collectionId, collectionId) ||
                other.collectionId == collectionId) &&
            (identical(other.collectionName, collectionName) ||
                other.collectionName == collectionName) &&
            (identical(other.expand, expand) || other.expand == expand) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.conclusion, conclusion) ||
                other.conclusion == conclusion) &&
            (identical(other.duration, duration) ||
                other.duration == duration) &&
            (identical(other.image, image) || other.image == image) &&
            (identical(other.level, level) || other.level == level) &&
            const DeepCollectionEquality()
                .equals(other._questions, _questions) &&
            (identical(other.score, score) || other.score == score) &&
            (identical(other.title, title) || other.title == title) &&
            const DeepCollectionEquality().equals(other._videos, _videos) &&
            const DeepCollectionEquality().equals(other._students, _students) &&
            (identical(other.finalized, finalized) ||
                other.finalized == finalized) &&
            (identical(other.progress, progress) ||
                other.progress == progress) &&
            (identical(other.certificate, certificate) ||
                other.certificate == certificate));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        created,
        updated,
        collectionId,
        collectionName,
        expand,
        description,
        conclusion,
        duration,
        image,
        level,
        const DeepCollectionEquality().hash(_questions),
        score,
        title,
        const DeepCollectionEquality().hash(_videos),
        const DeepCollectionEquality().hash(_students),
        finalized,
        progress,
        certificate
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RCourseImplCopyWith<_$RCourseImpl> get copyWith =>
      __$$RCourseImplCopyWithImpl<_$RCourseImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RCourseImplToJson(
      this,
    );
  }
}

abstract class _RCourse implements RCourse {
  const factory _RCourse(
      {required final String? id,
      required final DateTime? created,
      required final DateTime? updated,
      required final String? collectionId,
      required final String? collectionName,
      required final ECourse? expand,
      required final String? description,
      required final String? conclusion,
      required final String? duration,
      required final String? image,
      required final String? level,
      required final List<String>? questions,
      required final int? score,
      required final String? title,
      required final List<String>? videos,
      required final List<String>? students,
      final bool? finalized,
      final int? progress,
      final bool? certificate}) = _$RCourseImpl;

  factory _RCourse.fromJson(Map<String, dynamic> json) = _$RCourseImpl.fromJson;

  @override
  String? get id;
  @override
  DateTime? get created;
  @override
  DateTime? get updated;
  @override
  String? get collectionId;
  @override
  String? get collectionName;
  @override
  ECourse? get expand;
  @override
  String? get description;
  @override
  String? get conclusion;
  @override
  String? get duration;
  @override
  String? get image;
  @override
  String? get level;
  @override
  List<String>? get questions;
  @override
  int? get score;
  @override
  String? get title;
  @override
  List<String>? get videos;
  @override
  List<String>? get students;
  @override
  bool? get finalized;
  @override
  int? get progress;
  @override
  bool? get certificate;
  @override
  @JsonKey(ignore: true)
  _$$RCourseImplCopyWith<_$RCourseImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
