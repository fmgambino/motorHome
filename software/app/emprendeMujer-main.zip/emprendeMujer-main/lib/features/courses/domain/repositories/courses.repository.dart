import 'package:dartz/dartz.dart';

abstract class CoursesRepository {
  Future<Either<L, R>> getAllCourses<L, R>();
  Future<Either<L, R>> startCourse<L, R>(String idCourse, List<String> students);
  Future<Either<L, R>> addCourseToStudent<L, R>(List<String> courses, String student);
  Future<Either<L, R>> addCompletedCourseToStudent<L, R>(List<String> courses, String student);
  Future<Either<L, R>> requestCertificate<L, R>(String course, String student);
}
