import 'package:emprende_mujer/features/core/domain/entities/index.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'e_course.freezed.dart';
part 'e_course.g.dart';

@freezed
class ECourse with _$ECourse {
  const factory ECourse({
    required List<RQuestion>? questions,
    required List<RVideo>? videos,
  }) = _ECourse;

  factory ECourse.fromJson(Map<String, Object?> json) => _$ECourseFromJson(json);
}
