import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/features/courses/domain/repositories/courses.repository.dart';

class AddCourseToStudentUsecase {
  const AddCourseToStudentUsecase(this.repository);

  final CoursesRepository repository;

  Future<Either<L, R>> call<L, R>({
    required List<String> courses,
    required String student,
  }) async =>
      repository.addCourseToStudent(courses, student);
}
