import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/features/courses/domain/repositories/courses.repository.dart';

class RequestCertificateUsecase {
  const RequestCertificateUsecase(this.repository);

  final CoursesRepository repository;

  Future<Either<L, R>> call<L, R>({
    required String course,
    required String student,
  }) async =>
      repository.requestCertificate(course, student);
}
