// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'e_course.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

ECourse _$ECourseFromJson(Map<String, dynamic> json) {
  return _ECourse.fromJson(json);
}

/// @nodoc
mixin _$ECourse {
  List<RQuestion>? get questions => throw _privateConstructorUsedError;
  List<RVideo>? get videos => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ECourseCopyWith<ECourse> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ECourseCopyWith<$Res> {
  factory $ECourseCopyWith(ECourse value, $Res Function(ECourse) then) =
      _$ECourseCopyWithImpl<$Res, ECourse>;
  @useResult
  $Res call({List<RQuestion>? questions, List<RVideo>? videos});
}

/// @nodoc
class _$ECourseCopyWithImpl<$Res, $Val extends ECourse>
    implements $ECourseCopyWith<$Res> {
  _$ECourseCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? questions = freezed,
    Object? videos = freezed,
  }) {
    return _then(_value.copyWith(
      questions: freezed == questions
          ? _value.questions
          : questions // ignore: cast_nullable_to_non_nullable
              as List<RQuestion>?,
      videos: freezed == videos
          ? _value.videos
          : videos // ignore: cast_nullable_to_non_nullable
              as List<RVideo>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ECourseImplCopyWith<$Res> implements $ECourseCopyWith<$Res> {
  factory _$$ECourseImplCopyWith(
          _$ECourseImpl value, $Res Function(_$ECourseImpl) then) =
      __$$ECourseImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<RQuestion>? questions, List<RVideo>? videos});
}

/// @nodoc
class __$$ECourseImplCopyWithImpl<$Res>
    extends _$ECourseCopyWithImpl<$Res, _$ECourseImpl>
    implements _$$ECourseImplCopyWith<$Res> {
  __$$ECourseImplCopyWithImpl(
      _$ECourseImpl _value, $Res Function(_$ECourseImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? questions = freezed,
    Object? videos = freezed,
  }) {
    return _then(_$ECourseImpl(
      questions: freezed == questions
          ? _value._questions
          : questions // ignore: cast_nullable_to_non_nullable
              as List<RQuestion>?,
      videos: freezed == videos
          ? _value._videos
          : videos // ignore: cast_nullable_to_non_nullable
              as List<RVideo>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ECourseImpl implements _ECourse {
  const _$ECourseImpl(
      {required final List<RQuestion>? questions,
      required final List<RVideo>? videos})
      : _questions = questions,
        _videos = videos;

  factory _$ECourseImpl.fromJson(Map<String, dynamic> json) =>
      _$$ECourseImplFromJson(json);

  final List<RQuestion>? _questions;
  @override
  List<RQuestion>? get questions {
    final value = _questions;
    if (value == null) return null;
    if (_questions is EqualUnmodifiableListView) return _questions;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<RVideo>? _videos;
  @override
  List<RVideo>? get videos {
    final value = _videos;
    if (value == null) return null;
    if (_videos is EqualUnmodifiableListView) return _videos;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'ECourse(questions: $questions, videos: $videos)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ECourseImpl &&
            const DeepCollectionEquality()
                .equals(other._questions, _questions) &&
            const DeepCollectionEquality().equals(other._videos, _videos));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_questions),
      const DeepCollectionEquality().hash(_videos));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ECourseImplCopyWith<_$ECourseImpl> get copyWith =>
      __$$ECourseImplCopyWithImpl<_$ECourseImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ECourseImplToJson(
      this,
    );
  }
}

abstract class _ECourse implements ECourse {
  const factory _ECourse(
      {required final List<RQuestion>? questions,
      required final List<RVideo>? videos}) = _$ECourseImpl;

  factory _ECourse.fromJson(Map<String, dynamic> json) = _$ECourseImpl.fromJson;

  @override
  List<RQuestion>? get questions;
  @override
  List<RVideo>? get videos;
  @override
  @JsonKey(ignore: true)
  _$$ECourseImplCopyWith<_$ECourseImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
