import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/features/courses/data/datasources/remote/courses_remote_datasource.dart';
import 'package:emprende_mujer/features/courses/domain/index.dart';

class CoursesRepositoryImpl extends CoursesRepository {
  CoursesRepositoryImpl({
    required this.dataSource,
  });

  final CoursesRemoteDatasource dataSource;

  @override
  Future<Either<L, R>> getAllCourses<L, R>() async {
    return dataSource.getAllCourses();
  }

  @override
  Future<Either<L, R>> startCourse<L, R>(String idCourse, List<String> students) {
    return dataSource.startCourse(idCourse, students);
  }

  @override
  Future<Either<L, R>> addCourseToStudent<L, R>(List<String> courses, String student) {
    return dataSource.addCourseToStudent(courses, student);
  }

  @override
  Future<Either<L, R>> addCompletedCourseToStudent<L, R>(List<String> courses, String student) {
    return dataSource.addCompletedCourseToStudent(courses, student);
  }

  @override
  Future<Either<L, R>> requestCertificate<L, R>(String course, String student) {
    return dataSource.requestCertificate(course, student);
  }
}
