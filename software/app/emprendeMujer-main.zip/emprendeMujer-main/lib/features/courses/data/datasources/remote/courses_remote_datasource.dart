import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/common/index.dart';
import 'package:pocketbase/pocketbase.dart';

abstract class CoursesRemoteDatasource {
  Future<Either<L, R>> getAllCourses<L, R>();
  Future<Either<L, R>> startCourse<L, R>(String idCourse, List<String> students);
  Future<Either<L, R>> addCourseToStudent<L, R>(List<String> courses, String student);
  Future<Either<L, R>> addCompletedCourseToStudent<L, R>(List<String> courses, String student);
  Future<Either<L, R>> requestCertificate<L, R>(String course, String student);
}

class CoursesRemoteDatasourceImpl implements CoursesRemoteDatasource {
  CoursesRemoteDatasourceImpl({required this.pb});

  final PocketBase pb;

  @override
  Future<Either<L, R>> getAllCourses<L, R>() async {
    try {
      final res = await pb.collection('courses').getFullList(
            expand: 'questions.options,questions.correct,videos',
          );
      return Right(res as R);
    } catch (e) {
      if (e is ClientException) {
        return Left(RemoteError(error: e) as L);
      }
      return Left(RemoteError(e: e) as L);
    }
  }

  @override
  Future<Either<L, R>> startCourse<L, R>(String idCourse, List<String> students) async {
    try {
      final res = await pb.collection('courses').update(
            idCourse,
            body: {'students': students},
            expand: 'questions.options,questions.correct,videos',
          );

      return Right(res as R);
    } catch (e) {
      if (e is ClientException) {
        return Left(RemoteError(error: e) as L);
      }
      return Left(RemoteError(e: e) as L);
    }
  }

  @override
  Future<Either<L, R>> addCourseToStudent<L, R>(List<String> courses, String student) async {
    try {
      final res = await pb.collection('users').update(
        student,
        body: {'courses': courses},
      );

      return Right(res as R);
    } catch (e) {
      if (e is ClientException) {
        return Left(RemoteError(error: e) as L);
      }
      return Left(RemoteError(e: e) as L);
    }
  }

  @override
  Future<Either<L, R>> addCompletedCourseToStudent<L, R>(List<String> courses, String student) async {
    try {
      final res = await pb.collection('users').update(
        student,
        body: {'completed_courses': courses},
      );

      return Right(res as R);
    } catch (e) {
      if (e is ClientException) {
        return Left(RemoteError(error: e) as L);
      }
      return Left(RemoteError(e: e) as L);
    }
  }

  @override
  Future<Either<L, R>> requestCertificate<L, R>(String course, String student) async {
    try {
      final res = await pb.collection('certificates').create(body: {'student': student, 'course': course});

      return Right(res as R);
    } catch (e) {
      if (e is ClientException) {
        return Left(RemoteError(error: e) as L);
      }
      return Left(RemoteError(e: e) as L);
    }
  }
}
