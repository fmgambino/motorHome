import 'dart:developer';

import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/courses/ui/blocs/selected_course_bloc/selected_course_bloc.dart';
import 'package:emprende_mujer/features/home/index.dart';
import 'package:emprende_mujer/injection_container.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class StartCourseScreen extends StatefulWidget {
  const StartCourseScreen({super.key});

  @override
  State<StartCourseScreen> createState() => _StartCourseScreenState();
}

class _StartCourseScreenState extends State<StartCourseScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  final videoId = YoutubePlayer.convertUrlToId('https://www.youtube.com/watch?v=lKjJg9s07ls')!;

  late YoutubePlayerController controller;
  bool _isPlayerReady = false;

  late final SelectedCourseBloc selectedCourseBloc;

  @override
  void initState() {
    super.initState();
    selectedCourseBloc = sl<SelectedCourseBloc>();
    log('url: ${selectedCourseBloc.state.course!.expand!.videos![selectedCourseBloc.state.course!.progress!].url!}');
    controller = YoutubePlayerController(
      initialVideoId: YoutubePlayer.convertUrlToId(selectedCourseBloc.state.course!.expand!.videos![selectedCourseBloc.state.course!.progress!].url!)!,
      flags: const YoutubePlayerFlags(
        mute: false,
        autoPlay: false,
        disableDragSeek: false,
        loop: false,
        isLive: false,
        forceHD: false,
        enableCaption: true,
      ),
    );
  }

  void listener() {
    // log('listener playbackQuality ${controller.value.playbackQuality}');
    // log('listener buffered ${controller.value.buffered}');
    // log('listener hasPlayed ${controller.value.hasPlayed}');
    // log('listener isPlaying ${controller.value.isPlaying}');
    // log('listener isReady ${controller.value.isReady}');
    // log('listener position.inSeconds ${controller.value.position.inSeconds}');
    // log('listener isFullScreen ${controller.value.isFullScreen}');
    // if (_isPlayerReady && mounted && !controller.value.isFullScreen) {
    //   setState(() {});
    // }
  }

  @override
  void deactivate() {
    // Pauses video while navigating to next page.
    controller.pause();
    super.deactivate();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SelectedCourseBloc, SelectedCourseState>(
      builder: (context, state) {
        return Scaffold(
          appBar: const CustomAppBar(),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.all(context.dp(2)),
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: 'Clase ${state.course!.progress! + 1}: ',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: context.dp(1.6),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      TextSpan(
                        text: state.course!.expand!.videos![selectedCourseBloc.state.course!.progress!].title,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: context.dp(1.6),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Stack(
                children: [
                  Container(
                    height: 200,
                    color: Colors.blue,
                    child: YoutubePlayerBuilder(
                      onExitFullScreen: () {
                        // The player forces portraitUp after exiting fullscreen. This overrides the behaviour.
                        SystemChrome.setPreferredOrientations(DeviceOrientation.values);
                      },
                      player: YoutubePlayer(
                        controller: controller,
                        showVideoProgressIndicator: true,
                        progressIndicatorColor: Colors.blueAccent,
                        topActions: <Widget>[
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              controller.metadata.title,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                              ),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                        ],
                        onReady: () {
                          controller.addListener(listener);
                        },
                        onEnded: (data) {},
                      ),
                      builder: (context, player) => Scaffold(
                        key: _scaffoldKey,
                        body: ListView(
                          children: [
                            player,
                          ],
                        ),
                      ),
                    ),
                  ),
                  if (state.course!.expand!.videos![selectedCourseBloc.state.course!.progress!].seen!)
                    Padding(
                      padding: EdgeInsets.all(context.dp(1)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          CircleAvatar(
                            backgroundColor: Colors.black.withOpacity(0.5),
                            radius: context.dp(1.5),
                            child: Icon(
                              FontAwesomeIcons.check,
                              color: Colors.yellow,
                              size: context.dp(2),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: context.dp(2), vertical: context.dp(1)),
                      child: Text('Conclusión', style: TextStyle(fontSize: context.dp(2))),
                    ),
                    Flexible(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
                              child: Text(
                                state.course!.expand!.videos![selectedCourseBloc.state.course!.progress!].description!,
                                style: TextStyle(fontSize: context.dp(1.6)),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: context.dp(1)),
                    Flexible(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
                            child: OutlinedButton(
                              onPressed: () {},
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: ThemeColors.primary),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(5))),
                                minimumSize: Size(double.infinity, context.dp(5)),
                              ),
                              child: Text('Descargar archivos adjuntos', style: TextStyle(color: Colors.black, fontSize: context.dp(1.6))),
                            ),
                          ),
                          SizedBox(height: context.dp(1)),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
                            child: Row(
                              children: [
                                InkWell(
                                  onTap: () {
                                    if (selectedCourseBloc.state.course!.progress == 0) return;
                                    selectedCourseBloc.add(PreviousVideoEvent());
                                    controller.load(
                                      YoutubePlayer.convertUrlToId(
                                        selectedCourseBloc.state.course!.expand!.videos![selectedCourseBloc.state.course!.progress!].url!,
                                      )!,
                                    );
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    height: context.dp(5),
                                    width: context.dp(5),
                                    decoration: BoxDecoration(
                                      border: Border.all(color: ThemeColors.primary),
                                    ),
                                    child: Icon(Icons.arrow_back_ios, color: ThemeColors.primary, size: context.dp(3)),
                                  ),
                                ),
                                SizedBox(width: context.dp(1)),
                                Expanded(
                                  child: OutlinedButton(
                                    onPressed: () {
                                      selectedCourseBloc.add(MarkVideoAsSeenEvent());
                                      // controller.pause();
                                    },
                                    style: OutlinedButton.styleFrom(
                                      side: const BorderSide(color: ThemeColors.primary),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(5))),
                                      minimumSize: Size(double.infinity, context.dp(5)),
                                    ),
                                    child: Text('Marcar como completo', style: TextStyle(color: Colors.black, fontSize: context.dp(1.6))),
                                  ),
                                ),
                                SizedBox(width: context.dp(1)),
                                InkWell(
                                  onTap: () {
                                    if (selectedCourseBloc.state.course!.progress == selectedCourseBloc.state.course!.videos!.length - 1) return;
                                    selectedCourseBloc.add(NextVideoEvent());
                                    controller.load(
                                      YoutubePlayer.convertUrlToId(
                                        selectedCourseBloc.state.course!.expand!.videos![selectedCourseBloc.state.course!.progress!].url!,
                                      )!,
                                    );
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    height: context.dp(5),
                                    width: context.dp(5),
                                    decoration: BoxDecoration(
                                      border: Border.all(color: ThemeColors.primary),
                                    ),
                                    child: Icon(Icons.arrow_forward_ios, color: ThemeColors.primary, size: context.dp(3)),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: context.dp(1)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
      listener: (BuildContext context, SelectedCourseState state) async {
        if (state.course!.videos!.length == state.course!.progress! + 1) {
          await showDialog<void>(
            context: context,
            builder: (context) => PopUpWidget(
              emoji: start,
              title: '¡Felicidades!',
              description: 'Completaste el curso “${state.course!.title}”',
              onPressed: () {
                selectedCourseBloc
                  ..add(AddCompletedCourseToStudentEvent())
                  ..add(RequestCertificateEvent());
                Future.delayed(const Duration(milliseconds: 800), () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute<void>(builder: (context) => const HomeScreen()),
                    (route) => false,
                  );
                });
              },
              titleBtn: 'Ver certificado',
            ),
          );
        }
      },
    );
  }
}
