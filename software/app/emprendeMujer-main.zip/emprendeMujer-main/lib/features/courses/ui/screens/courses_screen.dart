import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/courses/ui/blocs/index.dart';
import 'package:emprende_mujer/features/courses/ui/widgets/index.dart';
import 'package:emprende_mujer/injection_container.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CoursesScreen extends StatefulWidget {
  const CoursesScreen({
    super.key,
  });

  @override
  State<CoursesScreen> createState() => _CoursesScreenState();
}

class _CoursesScreenState extends State<CoursesScreen> {
  late final CoursesBloc coursesBloc;

  @override
  void initState() {
    coursesBloc = sl.get<CoursesBloc>()..add(const GetAllCoursesEvent());
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CoursesBloc, CoursesState>(
      builder: (context, state) {
        return Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                color: ThemeColors.primary,
                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(context.dp(1.6)), bottomRight: Radius.circular(context.dp(1.6))),
              ),
              height: context.hp(25),
              child: Center(
                child: Text(
                  '¡Aprende con nuestros cursos!',
                  style: TextStyle(color: Colors.white, fontSize: context.dp(2.5), fontWeight: FontWeight.w500),
                ),
              ),
            ),
            Positioned.fill(
              top: context.hp(20),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
                child: Column(
                  children: [
                    Expanded(
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        child: state.courses.isNotEmpty
                            ? RefreshIndicator(
                                onRefresh: () {
                                  coursesBloc.add(const GetAllCoursesEvent(more: true));
                                  return Future.delayed(const Duration(seconds: 2));
                                },
                                child: ListView.separated(
                                  physics: const BouncingScrollPhysics(),
                                  padding: EdgeInsets.zero,
                                  itemCount: state.courses.length,
                                  itemBuilder: (BuildContext context, int index) {
                                    return TarjetaWidget(
                                      course: state.courses[index],
                                    );
                                  },
                                  separatorBuilder: (BuildContext context, int index) {
                                    return SizedBox(height: context.dp(1.5));
                                  },
                                ),
                              )
                            : state.error != null
                                ? Center(
                                    child: Text(
                                      state.error!,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: context.dp(1.6),
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  )
                                : Center(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          height: context.dp(2),
                                          width: context.dp(2),
                                          child: CircularProgressIndicator(
                                            strokeWidth: context.dp(0.2),
                                            color: ThemeColors.primary,
                                          ),
                                        ),
                                        SizedBox(width: context.dp(1)),
                                        Text(
                                          'Cargando cursos...',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: context.dp(1.6),
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _Logo extends StatelessWidget {
  const _Logo();

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Container(
      padding: EdgeInsets.symmetric(vertical: context.dp(1)),
      margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(context.dp(1.6)),
          bottomRight: Radius.circular(context.dp(1.6)),
        ),
        color: Colors.red,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            l10n.by,
            style: TextStyle(
              color: Colors.black,
              fontSize: context.dp(1.6),
              fontWeight: FontWeight.w400,
            ),
          ),
          SizedBox(
            width: context.dp(1),
          ),
          SvgPicture.asset(
            logoColorPath,
            height: context.dp(2.5),
          ),
        ],
      ),
    );
  }

  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
