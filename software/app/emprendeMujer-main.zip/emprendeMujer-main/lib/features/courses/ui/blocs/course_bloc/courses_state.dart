part of 'courses_bloc.dart';

class CoursesState extends Equatable {
  const CoursesState({
    required this.courses,
    required this.ecourses,
    this.error,
  });

  factory CoursesState.initial() {
    return const CoursesState(
      courses: [],
      ecourses: [],
    );
  }

  factory CoursesState.fromJson(Map<String, dynamic> map) {
    return CoursesState(
      courses: (map['courses'] as List).isNotEmpty ? List<RCourse>.from((map['courses'] as List<Map<String, dynamic>>).map(RCourse.fromJson)) : [],
      ecourses: (map['ecourses'] as List).isNotEmpty ? List<ECourse>.from((map['ecourses'] as List<Map<String, dynamic>>).map(ECourse.fromJson)) : [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'courses': courses.map((e) => e.toJson()).toList(),
      'ecourses': ecourses.map((e) => e.toJson()).toList(),
    };
  }

  CoursesState copyWith({
    List<RCourse>? courses,
    List<ECourse>? ecourses,
    String? error,
  }) {
    return CoursesState(
      courses: courses ?? this.courses,
      ecourses: ecourses ?? this.ecourses,
      error: error ?? this.error,
    );
  }

  final List<RCourse> courses;
  final List<ECourse> ecourses;
  final String? error;

  @override
  List<Object?> get props => [
        courses,
        ecourses,
        error,
      ];
}
