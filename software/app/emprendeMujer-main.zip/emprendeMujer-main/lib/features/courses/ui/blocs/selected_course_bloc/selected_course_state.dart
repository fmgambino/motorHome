part of 'selected_course_bloc.dart';

class SelectedCourseState extends Equatable {
  const SelectedCourseState({
    required this.course,
    this.isEnrolled = false,
  });

  factory SelectedCourseState.initial() {
    return const SelectedCourseState(
      course: null,
    );
  }

  factory SelectedCourseState.fromJson(Map<String, dynamic> json) {
    return SelectedCourseState(
      course: json['course'] == null ? null : RCourse.fromJson(json['course'] as Map<String, dynamic>),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'course': course?.toJson(),
    };
  }

  SelectedCourseState copyWith({
    RCourse? course,
    bool? isEnrolled,
  }) {
    return SelectedCourseState(
      course: course ?? this.course,
      isEnrolled: isEnrolled ?? this.isEnrolled,
    );
  }

  final RCourse? course;
  final bool isEnrolled;

  @override
  List<Object?> get props => [
        course,
      ];
}
