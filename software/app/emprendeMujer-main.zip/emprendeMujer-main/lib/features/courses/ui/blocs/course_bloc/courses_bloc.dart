import 'dart:async';

import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/features/courses/domain/index.dart';
import 'package:equatable/equatable.dart';
import 'package:hydrated_bloc/hydrated_bloc.dart';
import 'package:pocketbase/pocketbase.dart';

part 'courses_event.dart';
part 'courses_state.dart';

class CoursesBloc extends HydratedBloc<CoursesEvent, CoursesState> {
  CoursesBloc({
    required this.getAllCourses,
  }) : super(CoursesState.initial()) {
    on<GetAllCoursesEvent>(_getAllCoursesEvent);
  }

  final GetAllCoursesUsecase getAllCourses;

  @override
  CoursesState? fromJson(Map<String, dynamic> json) {
    return CoursesState.fromJson(json);
  }

  @override
  Map<String, dynamic>? toJson(CoursesState state) {
    return state.toJson();
  }

  FutureOr<void> _getAllCoursesEvent(GetAllCoursesEvent event, Emitter<CoursesState> emit) async {
    if (state.courses.isNotEmpty && !event.more) return;
    final result = await getAllCourses<RemoteError, List<RecordModel>>();

    if (result.isRight()) {
      final data = result.getOrElse(() => []);
      final hashData = data.map((element) => element.toJson()).toList();

      final courses = hashData.map(RCourse.fromJson).toList();

      emit(
        state.copyWith(
          courses: courses,
        ),
      );
    } else {
      emit(
        state.copyWith(error: 'No se pudo obtener los cursos, intenta más tarde.'),
      );
    }
  }

  Map<int, List<Map<String, dynamic>>> modules(List<Map<String, dynamic>> videos) {
    final groupedData = <int, List<Map<String, dynamic>>>{};

    for (final item in videos) {
      final module = item['module'] as int;
      if (groupedData.containsKey(module)) {
        groupedData[module]!.add(item);
      } else {
        groupedData[module] = [item];
      }
    }

    return groupedData;
  }
}
