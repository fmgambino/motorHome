part of 'test_bloc.dart';

class TestState extends Equatable {
  const TestState({
    required this.questions,
    this.error,
    this.successPercentage,
  });

  factory TestState.initial() {
    return const TestState(
      questions: null,
    );
  }

  factory TestState.fromJson(Map<String, dynamic> json) {
    return TestState(
      questions: json['questions'] == null ? null : List<RQuestion>.from((json['questions'] as List<Map<String, dynamic>>).map(RQuestion.fromJson)),
      successPercentage: json['successPercentage'] != null ? json['successPercentage'] as int : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'questions': questions?.map((e) => e.toJson()).toList(),
      'successPercentage': successPercentage ?? 0,
    };
  }

  TestState copyWith({
    List<RQuestion>? questions,
    String? error,
    int? successPercentage,
  }) {
    return TestState(
      questions: questions ?? this.questions,
      error: error ?? this.error,
      successPercentage: successPercentage ?? this.successPercentage,
    );
  }

  final List<RQuestion>? questions;
  final String? error;
  final int? successPercentage;

  @override
  List<Object?> get props => [
        questions,
        error,
        successPercentage,
      ];
}
