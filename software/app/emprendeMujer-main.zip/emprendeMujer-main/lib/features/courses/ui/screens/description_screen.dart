import 'package:emprende_mujer/common/helpers/extensions.dart';
import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/authentication/index.dart';
import 'package:emprende_mujer/features/courses/index.dart';
import 'package:emprende_mujer/injection_container.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';

class DescriptionScreen extends StatefulWidget {
  const DescriptionScreen({
    required this.course,
    super.key,
  });
  final RCourse course;

  @override
  State<DescriptionScreen> createState() => _DescriptionScreenState();
}

class _DescriptionScreenState extends State<DescriptionScreen> with SingleTickerProviderStateMixin {
  late TabController tabController;
  final m = DateFormat.M();
  final d = DateFormat.d();
  final y = DateFormat.y();

  late final CoursesBloc coursesBloc;
  late final SelectedCourseBloc selectedCourseBloc;
  late final AuthenticationCubit authenticationCubit;

  @override
  void initState() {
    coursesBloc = sl.get<CoursesBloc>();
    selectedCourseBloc = sl.get<SelectedCourseBloc>()..add(SelectCourseEvent(widget.course));
    authenticationCubit = sl.get<AuthenticationCubit>();
    tabController = TabController(
      length: 2,
      vsync: this,
    );
    super.initState();
  }

  @override
  void dispose() {
    selectedCourseBloc.add(const UnselectCourseEvent());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);

    return BlocBuilder<SelectedCourseBloc, SelectedCourseState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            title: Row(
              children: [
                SizedBox(
                  width: context.dp(4),
                ),
                Text(
                  l10n.by,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: context.dp(1.6),
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(
                  width: context.dp(1),
                ),
                SvgPicture.asset(
                  logoColorPath,
                  height: context.dp(2.5),
                ),
              ],
            ),
            iconTheme: const IconThemeData(color: Colors.black),
            centerTitle: true,
            backgroundColor: Colors.white,
            elevation: 8,
          ),
          persistentFooterButtons: [
            ElevatedButton(
              onPressed: () {
                context.read<SelectedCourseBloc>()
                  ..add(StartCourseEvent(authenticationCubit.state.auth!.record!.id!))
                  ..add(AddCourseToStudentEvent(authenticationCubit.state.auth!.record!.id!));
                Navigator.push(
                  context,
                  navegarMapaFadeIn(
                    context,
                    const StartCourseScreen(),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: ThemeColors.tab1,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(context.dp(0.4)),
                ),
                minimumSize: Size(double.infinity, context.dp(4)),
              ),
              child: Text(
                !state.isEnrolled ? 'Empezar ahora' : 'Continuar aprendiendo',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: context.dp(2),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
          body: state.course != null
              ? SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        color: Colors.grey[200],
                        width: double.infinity,
                        height: context.hp(30),
                        child: Hero(
                          tag: state.course!.image!,
                          child: Stack(
                            children: [
                              Positioned.fill(
                                child: FadeInImage(
                                  fit: BoxFit.cover,
                                  image: Image.network(
                                    widget.image(
                                      state.course!.collectionId!,
                                      state.course!.id!,
                                      state.course!.image!,
                                    ),
                                  ).image,
                                  imageErrorBuilder: (_, __, ___) => Icon(
                                    Icons.error_outline,
                                    color: Colors.red,
                                    size: context.dp(3),
                                  ),
                                  placeholder: Image.asset(
                                    imageLoading,
                                    fit: BoxFit.contain,
                                  ).image,
                                  placeholderErrorBuilder: (_, __, ___) => const CircularProgressIndicator(),
                                ),
                              ),
                              Positioned.fill(
                                child: Container(
                                  alignment: Alignment.bottomLeft,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Colors.transparent,
                                        Colors.black.withOpacity(0.8),
                                      ],
                                    ),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.all(context.dp(1)),
                                    child: Material(
                                      color: Colors.transparent,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              state.course!.title!,
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: context.dp(2),
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                          Row(
                                            children: [
                                              if (state.isEnrolled)
                                                Icon(
                                                  FontAwesomeIcons.userPen,
                                                  color: Colors.white,
                                                  size: context.dp(2),
                                                ),
                                              if (state.course!.finalized!)
                                                SizedBox(
                                                  width: context.dp(2),
                                                ),
                                              if (state.course!.finalized!)
                                                Icon(
                                                  FontAwesomeIcons.userGraduate,
                                                  color: Colors.white,
                                                  size: context.dp(2),
                                                ),
                                              if (!state.course!.finalized!)
                                                SizedBox(
                                                  width: context.dp(2),
                                                ),
                                              if (!state.course!.finalized!)
                                                Text(
                                                  '${state.course!.expand!.videos!.map((e) => e.seen!).where((element) => element).length / state.course!.expand!.videos!.length}'
                                                      .formatPercentage,
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: context.dp(1.6),
                                                    fontWeight: FontWeight.w400,
                                                  ),
                                                )
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: context.dp(2),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          TabBar(
                            padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
                            controller: tabController,
                            indicatorColor: ThemeColors.tab3,
                            labelColor: Colors.black,
                            unselectedLabelColor: Colors.grey,
                            tabs: [
                              Tab(
                                child: Text(
                                  'Sobre el curso',
                                  style: TextStyle(
                                    fontSize: context.dp(2),
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              Tab(
                                child: Text(
                                  'Temario',
                                  style: TextStyle(
                                    fontSize: context.dp(2),
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: context.dp(2),
                          ),
                          SizedBox(
                            height: context.hp(45),
                            child: TabBarView(
                              controller: tabController,
                              children: [
                                // tab - Sobre el curso
                                SingleChildScrollView(
                                  child: Padding(
                                    padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          padding: EdgeInsets.all(context.dp(1)),
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(context.dp(0.4)),
                                            border: Border.all(
                                              color: Colors.grey,
                                              width: context.dp(0.1),
                                            ),
                                          ),
                                          child: Text(
                                            state.course!.description!,
                                            style: TextStyle(
                                              color: Colors.black,
                                              fontSize: context.dp(1.6),
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          height: context.dp(1),
                                        ),
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Container(
                                                padding: EdgeInsets.all(context.dp(1)),
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(context.dp(0.4)),
                                                  color: Colors.blue[900],
                                                ),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: [
                                                    Icon(
                                                      FontAwesomeIcons.clock,
                                                      color: Colors.white,
                                                      size: context.dp(1.6),
                                                    ),
                                                    SizedBox(
                                                      width: context.dp(0.6),
                                                    ),
                                                    RichText(
                                                      textAlign: TextAlign.center,
                                                      text: TextSpan(
                                                        children: [
                                                          TextSpan(
                                                            text: '${state.course!.duration!} horas \n',
                                                            style: TextStyle(
                                                              color: Colors.white,
                                                              fontSize: context.dp(1.4),
                                                              fontWeight: FontWeight.w600,
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Duración',
                                                            style: TextStyle(
                                                              color: Colors.white,
                                                              fontSize: context.dp(1.2),
                                                              fontWeight: FontWeight.w400,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: context.dp(0.6),
                                            ),
                                            Expanded(
                                              child: Container(
                                                padding: EdgeInsets.symmetric(vertical: context.dp(1), horizontal: context.dp(0.5)),
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(context.dp(0.4)),
                                                  color: Colors.orange,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: [
                                                    Icon(
                                                      FontAwesomeIcons.user,
                                                      color: Colors.white,
                                                      size: context.dp(1.6),
                                                    ),
                                                    SizedBox(
                                                      width: context.dp(0.6),
                                                    ),
                                                    RichText(
                                                      textAlign: TextAlign.center,
                                                      text: TextSpan(
                                                        children: [
                                                          TextSpan(
                                                            text: ' ${state.course!.students?.length ?? 0} \n',
                                                            style: TextStyle(
                                                              color: Colors.white,
                                                              fontSize: context.dp(1.4),
                                                              fontWeight: FontWeight.w600,
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Estudiantes',
                                                            style: TextStyle(
                                                              color: Colors.white,
                                                              fontSize: context.dp(1.2),
                                                              fontWeight: FontWeight.w400,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: context.dp(0.6),
                                            ),
                                            Expanded(
                                              child: Container(
                                                padding: EdgeInsets.symmetric(vertical: context.dp(1), horizontal: context.dp(0.5)),
                                                decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(context.dp(0.4)),
                                                  color: ThemeColors.tab1,
                                                ),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: [
                                                    Icon(
                                                      FontAwesomeIcons.trophy,
                                                      color: Colors.white,
                                                      size: context.dp(1.6),
                                                    ),
                                                    SizedBox(
                                                      width: context.dp(0.6),
                                                    ),
                                                    RichText(
                                                      textAlign: TextAlign.center,
                                                      text: TextSpan(
                                                        children: [
                                                          TextSpan(
                                                            text: '${state.course!.level!}\n',
                                                            style: TextStyle(
                                                              color: Colors.white,
                                                              fontSize: context.dp(1.2),
                                                              fontWeight: FontWeight.w600,
                                                            ),
                                                          ),
                                                          TextSpan(
                                                            text: 'Nivel',
                                                            style: TextStyle(
                                                              color: Colors.white,
                                                              fontSize: context.dp(1.2),
                                                              fontWeight: FontWeight.w400,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: context.dp(1),
                                        ),
                                        Text(
                                          '¿Qué aprenderás de este curso?',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: context.dp(2),
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        SizedBox(
                                          height: context.dp(1),
                                        ),
                                        Text(
                                          state.course!.conclusion!,
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: context.dp(1.6),
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                        SizedBox(
                                          height: context.dp(1),
                                        ),
                                        // ultima actualizacion
                                        Text(
                                          'Última actualización:  ${d.format(state.course!.updated!)}/${m.format(state.course!.updated!)}/${y.format(state.course!.updated!)}',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: context.dp(1.6),
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                        SizedBox(
                                          height: context.dp(1),
                                        ),
                                        // valoracion
                                        Row(
                                          children: [
                                            Text(
                                              'Valoración: 4.5',
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: context.dp(1.6),
                                                fontWeight: FontWeight.w400,
                                              ),
                                            ),
                                            SizedBox(
                                              width: context.dp(0.6),
                                            ),
                                            Icon(
                                              FontAwesomeIcons.star,
                                              color: Colors.yellow[700],
                                              size: context.dp(1.6),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                // tab - Temario
                                SingleChildScrollView(
                                  child: Padding(
                                    padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
                                    child: Column(
                                      children: [
                                        OutlinedButton(
                                          style: OutlinedButton.styleFrom(
                                            side: BorderSide(color: ThemeColors.lettersDisabled, width: context.dp(0.1)),
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(context.dp(0.4)),
                                            ),
                                            minimumSize: Size(double.infinity, context.dp(3)),
                                          ),
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute<void>(
                                                builder: (context) => TestScreen(
                                                  questions: state.course!.expand!.questions!,
                                                ),
                                              ),
                                            );
                                          },
                                          child: Row(
                                            children: [
                                              Text(
                                                'Test de inicio',
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: context.dp(1.6),
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        ...selectedCourseBloc.agrupadosPorModulo(state.course!.expand!.videos!).entries.map(
                                          (e) {
                                            return Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  height: context.dp(1),
                                                ),
                                                Text(
                                                  'Módulo ${e.key}',
                                                  style: TextStyle(
                                                    color: Colors.black,
                                                    fontSize: context.dp(2),
                                                    fontWeight: FontWeight.w600,
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: context.dp(1),
                                                ),
                                                ...e.value.map(
                                                  (video) {
                                                    return ListTile(
                                                      onTap: () {},
                                                      leading: Icon(
                                                        FontAwesomeIcons.circlePlay,
                                                        color: ThemeColors.tab1,
                                                        size: context.dp(2.5),
                                                      ),
                                                      title: Text(
                                                        video.title!,
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: context.dp(1.6),
                                                          fontWeight: FontWeight.w500,
                                                        ),
                                                      ),
                                                      subtitle: Text(
                                                        video.description!,
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: context.dp(1.4),
                                                          fontWeight: FontWeight.w400,
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                ),
                                              ],
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // ElevatedButton(
                          //   onPressed: () {
                          //     context.read<SelectedCourseBloc>()
                          //       ..add(StartCourseEvent(authenticationCubit.state.auth!.record!.id!))
                          //       ..add(AddCourseToStudentEvent(authenticationCubit.state.auth!.record!.id!));
                          //     Navigator.push(
                          //       context,
                          //       navegarMapaFadeIn(
                          //         context,
                          //         const StartCourseScreen(),
                          //       ),
                          //     );
                          //   },
                          //   style: ElevatedButton.styleFrom(
                          //     backgroundColor: ThemeColors.tab1,
                          //     shape: RoundedRectangleBorder(
                          //       borderRadius: BorderRadius.circular(context.dp(0.4)),
                          //     ),
                          //   ),
                          //   child: Text(
                          //     'Empezar ahora',
                          //     style: TextStyle(
                          //       color: Colors.white,
                          //       fontSize: context.dp(2),
                          //       fontWeight: FontWeight.w600,
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                    ],
                  ),
                )
              : Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: context.dp(2),
                        width: context.dp(2),
                        child: CircularProgressIndicator(
                          strokeWidth: context.dp(0.2),
                          color: ThemeColors.primary,
                        ),
                      ),
                      SizedBox(width: context.dp(1)),
                      Text(
                        'Cargando curso...',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: context.dp(1.6),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
        );
      },
    );
  }
}

extension on DescriptionScreen {
  String image(String collectionId, String id, String path) => 'https://emprende-mujer.pockethost.io/api/files/$collectionId/$id/$path';
}
