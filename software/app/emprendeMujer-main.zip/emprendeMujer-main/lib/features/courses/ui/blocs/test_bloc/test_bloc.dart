import 'package:emprende_mujer/features/core/domain/entities/index.dart';
import 'package:equatable/equatable.dart';
import 'package:hydrated_bloc/hydrated_bloc.dart';

part 'test_event.dart';
part 'test_state.dart';

class TestBloc extends HydratedBloc<TestEvent, TestState> {
  TestBloc() : super(TestState.initial()) {
    on<TestEvent>((event, emit) {
      if (event is LoadTestEvent) _loadTestEvent(event, emit);
      if (event is AnswerQuestionEvent) _answerQuestionEvent(event, emit);
    });
  }

  @override
  TestState? fromJson(Map<String, dynamic> json) {
    return TestState.fromJson(json);
  }

  @override
  Map<String, dynamic>? toJson(TestState state) {
    return state.toJson();
  }

  void _loadTestEvent(
    LoadTestEvent event,
    Emitter<TestState> emit,
  ) {
    emit(
      state.copyWith(
        questions: event.questions,
      ),
    );
  }

  void _answerQuestionEvent(
    AnswerQuestionEvent event,
    Emitter<TestState> emit,
  ) {
    final elected = event.elected;
    final question = event.question;

    final success = elected == question.correct;

    final questions = state.questions!.map((e) {
      if (e.id == question.id) {
        return e.copyWith(
          elected: elected,
          success: success,
        );
      } else {
        return e;
      }
    }).toList();

    final successPercentage = (questions.where((e) => e.success != null && e.success!).length / questions.length * 100).round();

    emit(
      state.copyWith(
        questions: questions,
        successPercentage: successPercentage,
      ),
    );
  }
}
