import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/core/domain/entities/index.dart';
import 'package:emprende_mujer/features/courses/ui/blocs/test_bloc/test_bloc.dart';
import 'package:emprende_mujer/injection_container.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

class TestScreen extends StatefulWidget {
  const TestScreen({
    required this.questions,
    super.key,
  });

  final List<RQuestion> questions;

  @override
  State<TestScreen> createState() => _TestScreenState();
}

class _TestScreenState extends State<TestScreen> {
  late final TestBloc testBloc;

  @override
  void initState() {
    super.initState();
    testBloc = sl.get<TestBloc>()..add(LoadTestEvent(widget.questions));
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return BlocBuilder<TestBloc, TestState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            title: Row(
              children: [
                SizedBox(
                  width: context.dp(4),
                ),
                Text(
                  l10n.by,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: context.dp(1.6),
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(
                  width: context.dp(1),
                ),
                SvgPicture.asset(
                  logoColorPath,
                  height: context.dp(2.5),
                ),
              ],
            ),
            iconTheme: const IconThemeData(color: Colors.black),
            centerTitle: true,
            backgroundColor: Colors.white,
            elevation: 8,
          ),
          persistentFooterButtons: [
            ElevatedButton(
              onPressed: () {
                showDialog<void>(
                  context: context,
                  builder: (context) {
                    return PopUpWidget(
                      emoji: state.successPercentage! >= 20 ? checkMark : crossMark,
                      title: state.successPercentage! >= 20 ? '¡Felicidades!' : '¡No te preocupes!',
                      description:
                          'Acertaste el ${state.successPercentage}% de las preguntas, al finalizar el curso podrás volver a realizar el test y medir tu avance.',
                      titleBtn: 'Continuar',
                      onPressed: () {
                        Navigator.of(context).pop();
                        // Navigator.of(context).pop();
                      },
                    );
                  },
                );
              },
              style: ElevatedButton.styleFrom(
                minimumSize: Size.infinite,
                backgroundColor: ThemeColors.tab1,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(context.dp(0.4)),
                ),
              ),
              child: Text(
                'Enviar',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: context.dp(2),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
          body: Padding(
            padding: EdgeInsets.all(context.dp(2)),
            child: (state.questions != null && state.questions!.isNotEmpty)
                ? Column(
                    children: [
                      DecoratedBox(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(context.dp(0.4)),
                          border: Border.all(
                            color: Colors.grey,
                            width: context.dp(0.1),
                          ),
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(context.dp(1)),
                          child: RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: 'Test de inicio: ',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: context.dp(2),
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                TextSpan(
                                  text: 'Responde las siguientes preguntas para conocer tu nivel de conocimiento sobre el tema.',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: context.dp(1.6),
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: context.dp(2),
                      ),
                      Icon(
                        Icons.star,
                        color: Colors.yellow[700],
                        size: context.dp(4),
                      ),
                      Divider(
                        color: Colors.orange,
                        thickness: context.dp(0.1),
                        height: context.dp(2),
                      ),
                      Expanded(
                        child: ListView.separated(
                          physics: const BouncingScrollPhysics(),
                          padding: EdgeInsets.zero,
                          itemCount: state.questions!.length,
                          itemBuilder: (BuildContext context, int index) {
                            return ListTile(
                              title: Padding(
                                padding: EdgeInsets.only(bottom: context.dp(1)),
                                child: Row(
                                  children: [
                                    CircleAvatar(
                                      radius: context.dp(1.2),
                                      backgroundColor: Colors.orange,
                                      child: Text(
                                        '${index + 1}',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: context.dp(1.6),
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: context.dp(1),
                                    ),
                                    Text(
                                      state.questions![index].ask!,
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: context.dp(1.6),
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  ...state.questions![index].expand!.options!.map((a) {
                                    return RadioListTile(
                                      activeColor: Colors.orange,
                                      dense: true,
                                      title: Text(
                                        a.answer!,
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: context.dp(1.6),
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ),
                                      value: a.id,
                                      groupValue: state.questions![index].elected,
                                      onChanged: (value) {
                                        testBloc.add(
                                          AnswerQuestionEvent(
                                            value!,
                                            state.questions![index],
                                          ),
                                        );
                                      },
                                    );
                                  }),
                                ],
                              ),
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) {
                            return SizedBox(height: context.dp(1.5));
                          },
                        ),
                      ),
                    ],
                  )
                : state.error != null
                    ? Center(
                        child: Text(
                          state.error!,
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: context.dp(1.6),
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      )
                    : Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: context.dp(2),
                              width: context.dp(2),
                              child: CircularProgressIndicator(
                                strokeWidth: context.dp(0.2),
                                color: ThemeColors.primary,
                              ),
                            ),
                            SizedBox(width: context.dp(1)),
                            Text(
                              'Cargando preguntas...',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: context.dp(1.6),
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ),
          ),
        );
      },
    );
  }
}
