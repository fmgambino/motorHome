import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/features/authentication/index.dart';
import 'package:emprende_mujer/features/core/domain/entities/index.dart';
import 'package:emprende_mujer/features/courses/domain/index.dart';
import 'package:emprende_mujer/injection_container.dart';
import 'package:equatable/equatable.dart';
import 'package:hydrated_bloc/hydrated_bloc.dart';
import 'package:pocketbase/pocketbase.dart';

part 'selected_course_event.dart';
part 'selected_course_state.dart';

class SelectedCourseBloc extends HydratedBloc<SelectedCourseEvent, SelectedCourseState> {
  SelectedCourseBloc({
    required this.startCourse,
    required this.addCourseToStudent,
    required this.addCompletedCourseToStudent,
    required this.requestCertificate,
  }) : super(SelectedCourseState.initial()) {
    on<SelectedCourseEvent>((event, emit) async {
      if (event is SelectCourseEvent) _selectCourse(event, emit);
      if (event is UnselectCourseEvent) emit(SelectedCourseState.initial());
      if (event is StartCourseEvent) await _startCourse(event, emit);
      if (event is AddCourseToStudentEvent) await _addCourseToStudent(event, emit);
      if (event is AddCompletedCourseToStudentEvent) await _addCompletedCourseToStudent(event, emit);
      if (event is NextVideoEvent) await _nextVideo(event, emit);
      if (event is PreviousVideoEvent) await _previousVideo(event, emit);
      if (event is MarkVideoAsSeenEvent) await _markVideoAsSeen(event, emit);
      if (event is RequestCertificateEvent) await _requestCertificate(event, emit);
    });
  }

  final StartCourseUsecase startCourse;
  final AddCourseToStudentUsecase addCourseToStudent;
  final AddCompletedCourseToStudentUsecase addCompletedCourseToStudent;
  final RequestCertificateUsecase requestCertificate;

  @override
  SelectedCourseState? fromJson(Map<String, dynamic> json) {
    return SelectedCourseState.fromJson(json);
  }

  @override
  Map<String, dynamic>? toJson(SelectedCourseState state) {
    return state.toJson();
  }

  void _selectCourse(
    SelectCourseEvent event,
    Emitter<SelectedCourseState> emit,
  ) {
    final courses = sl<AuthenticationCubit>().state.auth!.record!.courses ?? [];
    final selectedCourse = event.course.id!;
    final isEnrolled = courses.contains(selectedCourse);

    if (isEnrolled) {
      final course = sl<AuthenticationCubit>().state.auth!.record!.expand!.courses?.firstWhere((element) => element.id == selectedCourse);
      emit(state.copyWith(course: course, isEnrolled: true));
    } else {
      emit(state.copyWith(course: event.course));
    }

    // emit(state.copyWith(course: event.course));
  }

  Map<int, List<RVideo>> agrupadosPorModulo(List<RVideo> videos) {
    final groupedData = <int, List<RVideo>>{};

    for (final video in videos) {
      final module = video.module ?? 0;

      if (groupedData.containsKey(module)) {
        groupedData[module]!.add(video);
      } else {
        groupedData[module] = [video];
      }
    }

    return groupedData;
  }

  Future<void> _startCourse(
    StartCourseEvent event,
    Emitter<SelectedCourseState> emit,
  ) async {
    final enrolledStudents = state.course!.students ?? [];
    final students = event.student;

    if (!state.isEnrolled) {
      final newStudents = [...enrolledStudents, students];
      final result = await startCourse<RemoteError, RecordModel>(
        idCourse: state.course!.id!,
        students: newStudents,
      );

      result.fold(
        (l) => null,
        (r) => emit(state.copyWith(course: state.course!.copyWith(students: newStudents))),
      );
    }
  }

  Future<void> _addCourseToStudent(
    AddCourseToStudentEvent event,
    Emitter<SelectedCourseState> emit,
  ) async {
    final courses = sl<AuthenticationCubit>().state.auth!.record!.courses ?? [];
    final student = event.student;
    final selectedCourse = state.course!.id!;

    if (!state.isEnrolled) {
      final newCourses = [...courses, selectedCourse];
      final record = sl<AuthenticationCubit>().state.auth!.record!;
      final userUpdated = record.copyWith(courses: newCourses, expand: record.expand!.copyWith(courses: [...record.expand?.courses ?? [], state.course!]));
      await sl<AuthenticationCubit>().updateUser(userUpdated);

      final result = await addCourseToStudent<RemoteError, RecordModel>(
        courses: newCourses,
        student: student,
      );

      result.fold(
        (l) => null,
        (r) => emit(state.copyWith(course: state.course!.copyWith(students: newCourses), isEnrolled: true)),
      );
    }
  }

  Future<void> _addCompletedCourseToStudent(
    AddCompletedCourseToStudentEvent event,
    Emitter<SelectedCourseState> emit,
  ) async {
    final completedCourses = sl<AuthenticationCubit>().state.auth!.record!.completedCourses ?? [];
    final courses = sl<AuthenticationCubit>().state.auth!.record!.expand!.courses ?? [];

    final student = sl<AuthenticationCubit>().state.auth!.record!.id!;
    final selectedCourse = state.course!.id!;

    if (!completedCourses.contains(selectedCourse) && !state.course!.finalized!) {
      final newCoursesId = [...completedCourses, selectedCourse];
      final record = sl<AuthenticationCubit>().state.auth!.record!;

      final newCourses = courses.map((c) {
        if (c.id == selectedCourse) {
          return c.copyWith(finalized: true);
        } else {
          return c;
        }
      }).toList();

      final userUpdated = record.copyWith(
        completedCourses: newCoursesId,
        expand:
            record.expand!.copyWith(completedCourses: [...record.expand?.completedCourses ?? [], state.course!.copyWith(finalized: true)], courses: newCourses),
      );
      await sl<AuthenticationCubit>().updateUser(userUpdated);

      final result = await addCompletedCourseToStudent<RemoteError, RecordModel>(
        courses: newCoursesId,
        student: student,
      );

      result.fold(
        (l) => null,
        (r) => emit(state.copyWith(course: state.course!.copyWith(finalized: true))),
      );
    }
  }

  Future<void> _nextVideo(NextVideoEvent event, Emitter<SelectedCourseState> emit) async {
    final course = state.course!;
    if (course.progress == course.videos!.length - 1) return;
    final nextVideo = course.copyWith(progress: course.progress! + 1);
    emit(state.copyWith(course: nextVideo));

    final user = sl<AuthenticationCubit>().state.auth!.record!;
    final newCourses = user.expand!.courses!.map((c) {
      if (c.id == course.id) {
        return c.copyWith(progress: c.progress! + 1);
      } else {
        return c;
      }
    }).toList();
    await sl<AuthenticationCubit>().updateUser(user.copyWith(expand: user.expand!.copyWith(courses: newCourses)));
  }

  Future<void> _previousVideo(PreviousVideoEvent event, Emitter<SelectedCourseState> emit) async {
    final course = state.course!;
    if (course.progress == 0) return;
    final previousVideo = course.copyWith(progress: course.progress! - 1);
    emit(state.copyWith(course: previousVideo));

    final user = sl<AuthenticationCubit>().state.auth!.record!;
    final newCourses = user.expand!.courses!.map((c) {
      if (c.id == course.id) {
        return c.copyWith(progress: c.progress! - 1);
      } else {
        return c;
      }
    }).toList();
    await sl<AuthenticationCubit>().updateUser(user.copyWith(expand: user.expand!.copyWith(courses: newCourses)));
  }

  Future<void> _markVideoAsSeen(MarkVideoAsSeenEvent event, Emitter<SelectedCourseState> emit) async {
    final course = state.course!;
    final progress = course.progress!;

    if (course.expand!.videos![progress].seen!) return;

    final videos = course.expand!.videos!.map((video) {
      if (video.id == course.expand!.videos![progress].id) {
        return video.copyWith(seen: true);
      } else {
        return video;
      }
    }).toList();

    final newCourse = course.copyWith(expand: course.expand!.copyWith(videos: videos));
    emit(state.copyWith(course: newCourse));

    final user = sl<AuthenticationCubit>().state.auth!.record!;
    final newCourses = user.expand!.courses!.map((c) {
      if (c.id == course.id) {
        return c.copyWith(expand: c.expand!.copyWith(videos: videos));
      } else {
        return c;
      }
    }).toList();
    await sl<AuthenticationCubit>().updateUser(user.copyWith(expand: user.expand!.copyWith(courses: newCourses)));
  }

  Future<void> _requestCertificate(RequestCertificateEvent event, Emitter<SelectedCourseState> emit) async {
    final course = state.course!;
    final student = sl<AuthenticationCubit>().state.auth!.record!.id!;

    final result = await requestCertificate<RemoteError, RecordModel>(
      course: course.id!,
      student: student,
    );

    result.fold(
      (l) => null,
      (r) => emit(state.copyWith(course: state.course!.copyWith(certificate: true))),
    );
  }
}
