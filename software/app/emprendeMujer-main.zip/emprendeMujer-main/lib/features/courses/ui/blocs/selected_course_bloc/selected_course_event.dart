part of 'selected_course_bloc.dart';

sealed class SelectedCourseEvent extends Equatable {
  const SelectedCourseEvent();

  @override
  List<Object> get props => [];
}

class SelectCourseEvent extends SelectedCourseEvent {
  const SelectCourseEvent(this.course);

  final RCourse course;

  @override
  List<Object> get props => [course];
}

class UnselectCourseEvent extends SelectedCourseEvent {
  const UnselectCourseEvent();
}

class StartCourseEvent extends SelectedCourseEvent {
  const StartCourseEvent(this.student);

  final String student;

  @override
  List<Object> get props => [student];
}

class AddCourseToStudentEvent extends SelectedCourseEvent {
  const AddCourseToStudentEvent(this.student);

  final String student;

  @override
  List<Object> get props => [student];
}

class AddCompletedCourseToStudentEvent extends SelectedCourseEvent {}

class NextVideoEvent extends SelectedCourseEvent {}

class PreviousVideoEvent extends SelectedCourseEvent {}

class MarkVideoAsSeenEvent extends SelectedCourseEvent {}

class RequestCertificateEvent extends SelectedCourseEvent {}
