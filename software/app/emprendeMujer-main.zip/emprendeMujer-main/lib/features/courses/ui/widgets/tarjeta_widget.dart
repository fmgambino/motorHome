import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/courses/domain/entities/index.dart';
import 'package:emprende_mujer/features/courses/ui/screens/description_screen.dart';
import 'package:flutter/material.dart';

class TarjetaWidget extends StatelessWidget {
  const TarjetaWidget({
    required this.course,
    super.key,
  });

  final RCourse course;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          navegarMapaFadeIn(
            context,
            DescriptionScreen(course: course),
          ),
        );
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: context.dp(2), vertical: context.dp(1.5)),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(bottom: BorderSide(color: ThemeColors.lettersDisabled, width: context.dp(0.08))),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: context.dp(9.5),
              height: context.dp(10.1),
              decoration: BoxDecoration(
                color: ThemeColors.letters,
                borderRadius: BorderRadius.circular(context.dp(0.5)),
              ),
              child: Center(
                child: Hero(
                  tag: course.image!,
                  child: FadeInImage(
                    image: Image.network(
                      image,
                    ).image,
                    imageErrorBuilder: (_, __, ___) => Icon(
                      Icons.error_outline,
                      color: Colors.red,
                      size: context.dp(3),
                    ),
                    placeholder: Image.asset(
                      imageLoading,
                      fit: BoxFit.contain,
                    ).image,
                    placeholderErrorBuilder: (_, __, ___) => const CircularProgressIndicator(),
                  ),
                ),
              ),
            ),
            SizedBox(width: context.dp(1.5)),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    course.title!,
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: context.dp(1.6),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: context.dp(1)),
                  Row(
                    children: [
                      Text(
                        course.level!,
                        textAlign: TextAlign.start,
                        style: TextStyle(
                          color: ThemeColors.lettersDisabled,
                          fontSize: context.dp(1.6),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      SizedBox(width: context.dp(1)),
                      Text(
                        course.score!.toString(),
                        style: TextStyle(color: ThemeColors.lettersDisabled, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
                      ),
                      SizedBox(width: context.dp(0.6)),
                      for (int i = 0; i < int.tryParse(course.score!.toString())!; i++)
                        Icon(Icons.star_outlined, color: ThemeColors.primary, size: context.dp(1.6)),
                    ],
                  ),
                  SizedBox(height: context.dp(1)),
                  Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: ThemeColors.primary,
                        radius: context.dp(1.2),
                        child: SizedBox(
                          height: context.dp(1.2),
                          child: Image.asset(
                            download,
                            fit: BoxFit.fitHeight,
                            color: Colors.black,
                          ),
                        ),
                      ),
                      SizedBox(width: context.dp(1)),
                      Text(
                        course.videos!.length.toString(),
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: context.dp(1.6),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      SizedBox(width: context.dp(1)),
                      Text(
                        'LECCIONES',
                        textAlign: TextAlign.start,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: context.dp(1.6),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      SizedBox(width: context.dp(1)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

extension on TarjetaWidget {
  String get image => 'https://emprende-mujer.pockethost.io/api/files/${course.collectionId}/${course.id}/${course.image}';
}
