part of 'courses_bloc.dart';

sealed class CoursesEvent extends Equatable {
  const CoursesEvent();

  @override
  List<Object> get props => [];
}

final class GetAllCoursesEvent extends CoursesEvent {
  const GetAllCoursesEvent({this.more = false});
  final bool more;
}
