part of 'test_bloc.dart';

sealed class TestEvent extends Equatable {
  const TestEvent();

  @override
  List<Object> get props => [];
}

class LoadTestEvent extends TestEvent {
  const LoadTestEvent(this.questions);

  final List<RQuestion> questions;

  @override
  List<Object> get props => [questions];
}

class AnswerQuestionEvent extends TestEvent {
  const AnswerQuestionEvent(this.elected, this.question);

  final String elected;
  final RQuestion question;

  @override
  List<Object> get props => [elected, question];
}
