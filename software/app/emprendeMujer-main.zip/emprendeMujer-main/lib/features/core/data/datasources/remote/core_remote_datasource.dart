
import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/common/index.dart';
import 'package:pocketbase/pocketbase.dart';

abstract class CoreRemoteDatasource {
  Future<Either<L, R>> getAllInfographics<L, R>();
}

class CoreRemoteDatasourceImpl implements CoreRemoteDatasource {
  CoreRemoteDatasourceImpl({required this.pb});

  final PocketBase pb;

  @override
  Future<Either<L, R>> getAllInfographics<L, R>() async {
    try {
      final res = await pb.collection('infographics').getFullList();
      final list = res.map((e) =>e.toJson()).toList();
      return Right(list as R);
    } catch (e) {
      if (e is ClientException) {
        return Left(RemoteError(error: e) as L);
      }
      return Left(RemoteError(e: e) as L);
    }
  }
}
/*
{
      "id": "2l2qbgh0szawo2d",
      "created": "2023-10-25 15:12:38.931Z",
      "updated": "2023-10-25 15:13:01.798Z",
      "collectionId": "dqbce96mhfgye7c",
      "collectionName": "infographics",
      "expand": {},
      "description": "description",
      "image": "info_01_cShpVAsnUg.jpg",
      "title": "title"
}
*/
