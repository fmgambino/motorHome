import 'package:emprende_mujer/features/core/domain/entities/user.entitie.dart';

class UserMoldel extends UserEntitie {
  const UserMoldel({
    required super.id,
    required super.created,
    required super.updated,
    required super.avatar,
    required super.badges,
    required super.courses,
    required super.email,
    required super.emailVisibility,
    required super.name,
    required super.username,
    required super.verified,
    required super.department,
    required super.documentNumber,
    required super.documentType,
    required super.gender,
    required super.nationality,
    required super.phone,
  });

  factory UserMoldel.fromMap(Map<String, dynamic> json) => UserMoldel(
        id: json['id'] as String,
        created: DateTime.parse(json['created'] as String),
        updated: DateTime.parse(json['updated'] as String),
        avatar: json['avatar'] != null ? json['avatar'] as String : '',
        badges: json['badges'] != null && (json['badges'] as List).isNotEmpty ? List<String>.from((json['badges'] as List<dynamic>).map((x) => x)) : [],
        courses: json['courses'] != null && (json['courses'] as List).isNotEmpty ? List<String>.from((json['courses'] as List<dynamic>).map((x) => x)) : [],
        email:json['email'] != null ? json['email'] as String : '',
        emailVisibility: json['emailVisibility'] as bool,
        name: json['name'] as String,
        username: json['username'] as String,
        verified: json['verified'] as bool,
        department: json['department'] as String,
        documentNumber: json['document_number'] as String,
        documentType: json['document_type'] as String,
        gender: json['gender'] as String,
        nationality: json['nationality'] as String,
        phone: json['phone'] as String,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'created': created.toIso8601String(),
        'updated': updated.toIso8601String(),
        'avatar': avatar,
        'badges': List<dynamic>.from(badges.map((x) => x)),
        'courses': List<dynamic>.from(courses.map((x) => x)),
        'email': email,
        'emailVisibility': emailVisibility,
        'name': name,
        'username': username,
        'verified': verified,
        'department': department,
        'document_number': documentNumber,
        'document_type': documentType,
        'gender': gender,
        'nationality': nationality,
        'phone': phone,
      };
}
