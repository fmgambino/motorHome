import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/features/core/data/index.dart';
import 'package:emprende_mujer/features/core/domain/index.dart';

class CoreRepositoryImpl extends CoreRepository {
  CoreRepositoryImpl({required this.dataSource});

  final CoreRemoteDatasource dataSource;

  @override
  Future<Either<L, R>> getAllInfographics<L,R>() async {
    return dataSource.getAllInfographics();
  }
}
