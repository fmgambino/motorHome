part of 'core_bloc.dart';

class CoreState extends Equatable {
  const CoreState({
    required this.infographics,
  });

  factory CoreState.fromJson(Map<String, dynamic> map) {
    return CoreState(
      infographics: List<Map<String, dynamic>>.from(map['infographics'] as List),
    );
  }

  factory CoreState.initial() => const CoreState(
        infographics: [],
      );

  CoreState copyWith({
    List<Map<String, dynamic>>? infographics,
  }) {
    return CoreState(
      infographics: infographics ?? this.infographics,
    );
  }

  Map<String, dynamic> toJson() => {
        'infographics': infographics,
      };

  final List<Map<String, dynamic>> infographics;

  @override
  List<Object> get props => [
        infographics,
      ];
}
