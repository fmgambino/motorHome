import 'dart:async';

import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/features/core/domain/index.dart';
import 'package:equatable/equatable.dart';
import 'package:hydrated_bloc/hydrated_bloc.dart';

part 'core_event.dart';
part 'core_state.dart';

class CoreBloc extends HydratedBloc<CoreEvent, CoreState> {
  CoreBloc({required this.getAllInfographics}) : super(CoreState.initial()) {
    on<GetAllInfographicsEvent>(_getAllInfographics);
  }

  final GetAllInfographicsUsecase getAllInfographics;

  @override
  CoreState? fromJson(Map<String, dynamic> json) {
    return CoreState.fromJson(json);
  }

  @override
  Map<String, dynamic>? toJson(CoreState state) {
    return state.toJson();
  }

  FutureOr<void> _getAllInfographics(
    GetAllInfographicsEvent event,
    Emitter<CoreState> emit,
  ) async {
    final result = await getAllInfographics<RemoteError, List<Map<String, dynamic>>>();

    if (result.isRight()) {
      emit(
        state.copyWith(
          infographics: result.getOrElse(
            () => [],
          ),
        ),
      );
    } else {
      emit(
        state.copyWith(
          infographics: [],
        ),
      );
    }
  }
}
