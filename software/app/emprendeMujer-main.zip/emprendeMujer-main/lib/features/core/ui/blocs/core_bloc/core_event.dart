part of 'core_bloc.dart';

sealed class CoreEvent extends Equatable {
  const CoreEvent();

  @override
  List<Object> get props => [];
}

final class GetAllInfographicsEvent extends CoreEvent {}
