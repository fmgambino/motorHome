

import 'package:dartz/dartz.dart';

abstract class CoreRepository {

	Future<Either<L, R>> getAllInfographics<L, R>();

}