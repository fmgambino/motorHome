import 'package:dartz/dartz.dart';
import 'package:emprende_mujer/features/core/domain/repositories/core.repository.dart';

class GetAllInfographicsUsecase {
	const GetAllInfographicsUsecase(this.repository);

	final CoreRepository repository;

	Future<Either<L, R>> call<L, R>() async => repository.getAllInfographics();

}