import 'package:freezed_annotation/freezed_annotation.dart';

part 'r_video.freezed.dart';
part 'r_video.g.dart';

@freezed
class RVideo with _$RVideo {
  const factory RVideo({
    required String? id,
    required DateTime? created,
    required DateTime? updated,
    required String? collectionId,
    required String? collectionName,
    required String? description,
    required int? module,
    required String? title,
    required String? url,
    @Default(false) bool? seen,
  }) = _RVideo;

  factory RVideo.fromJson(Map<String, Object?> json) => _$RVideoFromJson(json);
}
