import 'package:freezed_annotation/freezed_annotation.dart';

part 'r_badges.freezed.dart';
part 'r_badges.g.dart';

@freezed
class RBadges with _$RBadges {
  const factory RBadges({
    required String? id,
    required DateTime? created,
    required DateTime? updated,
    required String? collectionId,
    required String? collectionName,
    required String? name,
  }) = _RBadges;

  factory RBadges.fromJson(Map<String, Object?> json) => _$RBadgesFromJson(json);
}
