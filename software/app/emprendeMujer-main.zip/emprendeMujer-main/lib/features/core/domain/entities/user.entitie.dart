import 'package:equatable/equatable.dart';

class UserEntitie extends Equatable {
  const UserEntitie({
    required this.id,
    required this.created,
    required this.updated,
    required this.avatar,
    required this.badges,
    required this.courses,
    required this.email,
    required this.emailVisibility,
    required this.name,
    required this.username,
    required this.verified,
    required this.department,
    required this.documentNumber,
    required this.documentType,
    required this.gender,
    required this.nationality,
    required this.phone,
  });

  final String id;
  final DateTime created;
  final DateTime updated;
  final String avatar;
  final List<String> badges;
  final List<String> courses;
  final String email;
  final bool emailVisibility;
  final String name;
  final String username;
  final bool verified;
  final String department;
  final String documentNumber;
  final String documentType;
  final String gender;
  final String nationality;
  final String phone;

  UserEntitie copyWith({
    String? id,
    DateTime? created,
    DateTime? updated,
    String? avatar,
    List<String>? badges,
    List<String>? courses,
    String? email,
    bool? emailVisibility,
    String? name,
    String? username,
    bool? verified,
    String? department,
    String? documentNumber,
    String? documentType,
    String? gender,
    String? nationality,
    String? phone,
  }) =>
      UserEntitie(
        id: id ?? this.id,
        created: created ?? this.created,
        updated: updated ?? this.updated,
        avatar: avatar ?? this.avatar,
        badges: badges ?? this.badges,
        courses: courses ?? this.courses,
        email: email ?? this.email,
        emailVisibility: emailVisibility ?? this.emailVisibility,
        name: name ?? this.name,
        username: username ?? this.username,
        verified: verified ?? this.verified,
        department: department ?? this.department,
        documentNumber: documentNumber ?? this.documentNumber,
        documentType: documentType ?? this.documentType,
        gender: gender ?? this.gender,
        nationality: nationality ?? this.nationality,
        phone: phone ?? this.phone,
      );

  @override
  List<Object?> get props => [
        id,
        created,
        updated,
        avatar,
        badges,
        courses,
        email,
        emailVisibility,
        name,
        username,
        verified,
        department,
        documentNumber,
        documentType,
        gender,
        nationality,
        phone,
      ];
}
