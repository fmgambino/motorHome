import 'package:freezed_annotation/freezed_annotation.dart';

part 'r_answer.freezed.dart';
part 'r_answer.g.dart';

@freezed
class RAnswers with _$RAnswers {
  const factory RAnswers({
    required String? id,
    required DateTime? created,
    required DateTime? updated,
    required String? collectionId,
    required String? collectionName,
    required String? answer,
  }) = _RAnswers;

  factory RAnswers.fromJson(Map<String, Object?> json) => _$RAnswersFromJson(json);
}
