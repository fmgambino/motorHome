import 'package:emprende_mujer/features/core/domain/entities/e_question/e_question.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'r_question.freezed.dart';
part 'r_question.g.dart';

@freezed
class RQuestion with _$RQuestion {
  const factory RQuestion({
    required String? id,
    required DateTime? created,
    required DateTime? updated,
    required String? collectionId,
    required String? collectionName,
    required EQuestion? expand,
    required String? ask,
    required String? correct,
    required String? elected,
    required bool? success,
    required List<String>? options,
  }) = _RQuestion;

  factory RQuestion.fromJson(Map<String, Object?> json) => _$RQuestionFromJson(json);
}
