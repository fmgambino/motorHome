// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'e_question.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

EQuestion _$EQuestionFromJson(Map<String, dynamic> json) {
  return _EQuestion.fromJson(json);
}

/// @nodoc
mixin _$EQuestion {
  RAnswers? get correct => throw _privateConstructorUsedError;
  List<RAnswers>? get options => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $EQuestionCopyWith<EQuestion> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EQuestionCopyWith<$Res> {
  factory $EQuestionCopyWith(EQuestion value, $Res Function(EQuestion) then) =
      _$EQuestionCopyWithImpl<$Res, EQuestion>;
  @useResult
  $Res call({RAnswers? correct, List<RAnswers>? options});

  $RAnswersCopyWith<$Res>? get correct;
}

/// @nodoc
class _$EQuestionCopyWithImpl<$Res, $Val extends EQuestion>
    implements $EQuestionCopyWith<$Res> {
  _$EQuestionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? correct = freezed,
    Object? options = freezed,
  }) {
    return _then(_value.copyWith(
      correct: freezed == correct
          ? _value.correct
          : correct // ignore: cast_nullable_to_non_nullable
              as RAnswers?,
      options: freezed == options
          ? _value.options
          : options // ignore: cast_nullable_to_non_nullable
              as List<RAnswers>?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $RAnswersCopyWith<$Res>? get correct {
    if (_value.correct == null) {
      return null;
    }

    return $RAnswersCopyWith<$Res>(_value.correct!, (value) {
      return _then(_value.copyWith(correct: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$EQuestionImplCopyWith<$Res>
    implements $EQuestionCopyWith<$Res> {
  factory _$$EQuestionImplCopyWith(
          _$EQuestionImpl value, $Res Function(_$EQuestionImpl) then) =
      __$$EQuestionImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({RAnswers? correct, List<RAnswers>? options});

  @override
  $RAnswersCopyWith<$Res>? get correct;
}

/// @nodoc
class __$$EQuestionImplCopyWithImpl<$Res>
    extends _$EQuestionCopyWithImpl<$Res, _$EQuestionImpl>
    implements _$$EQuestionImplCopyWith<$Res> {
  __$$EQuestionImplCopyWithImpl(
      _$EQuestionImpl _value, $Res Function(_$EQuestionImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? correct = freezed,
    Object? options = freezed,
  }) {
    return _then(_$EQuestionImpl(
      correct: freezed == correct
          ? _value.correct
          : correct // ignore: cast_nullable_to_non_nullable
              as RAnswers?,
      options: freezed == options
          ? _value._options
          : options // ignore: cast_nullable_to_non_nullable
              as List<RAnswers>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$EQuestionImpl implements _EQuestion {
  const _$EQuestionImpl(
      {required this.correct, required final List<RAnswers>? options})
      : _options = options;

  factory _$EQuestionImpl.fromJson(Map<String, dynamic> json) =>
      _$$EQuestionImplFromJson(json);

  @override
  final RAnswers? correct;
  final List<RAnswers>? _options;
  @override
  List<RAnswers>? get options {
    final value = _options;
    if (value == null) return null;
    if (_options is EqualUnmodifiableListView) return _options;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'EQuestion(correct: $correct, options: $options)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$EQuestionImpl &&
            (identical(other.correct, correct) || other.correct == correct) &&
            const DeepCollectionEquality().equals(other._options, _options));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, correct, const DeepCollectionEquality().hash(_options));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$EQuestionImplCopyWith<_$EQuestionImpl> get copyWith =>
      __$$EQuestionImplCopyWithImpl<_$EQuestionImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$EQuestionImplToJson(
      this,
    );
  }
}

abstract class _EQuestion implements EQuestion {
  const factory _EQuestion(
      {required final RAnswers? correct,
      required final List<RAnswers>? options}) = _$EQuestionImpl;

  factory _EQuestion.fromJson(Map<String, dynamic> json) =
      _$EQuestionImpl.fromJson;

  @override
  RAnswers? get correct;
  @override
  List<RAnswers>? get options;
  @override
  @JsonKey(ignore: true)
  _$$EQuestionImplCopyWith<_$EQuestionImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
