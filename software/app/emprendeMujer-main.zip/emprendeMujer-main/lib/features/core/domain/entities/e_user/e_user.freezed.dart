// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'e_user.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

EUser _$EUserFromJson(Map<String, dynamic> json) {
  return _EUser.fromJson(json);
}

/// @nodoc
mixin _$EUser {
  List<RBadges>? get badges => throw _privateConstructorUsedError;
  List<RCourse>? get courses => throw _privateConstructorUsedError;
  List<RCourse>? get completedCourses => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $EUserCopyWith<EUser> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EUserCopyWith<$Res> {
  factory $EUserCopyWith(EUser value, $Res Function(EUser) then) =
      _$EUserCopyWithImpl<$Res, EUser>;
  @useResult
  $Res call(
      {List<RBadges>? badges,
      List<RCourse>? courses,
      List<RCourse>? completedCourses});
}

/// @nodoc
class _$EUserCopyWithImpl<$Res, $Val extends EUser>
    implements $EUserCopyWith<$Res> {
  _$EUserCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? badges = freezed,
    Object? courses = freezed,
    Object? completedCourses = freezed,
  }) {
    return _then(_value.copyWith(
      badges: freezed == badges
          ? _value.badges
          : badges // ignore: cast_nullable_to_non_nullable
              as List<RBadges>?,
      courses: freezed == courses
          ? _value.courses
          : courses // ignore: cast_nullable_to_non_nullable
              as List<RCourse>?,
      completedCourses: freezed == completedCourses
          ? _value.completedCourses
          : completedCourses // ignore: cast_nullable_to_non_nullable
              as List<RCourse>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$EUserImplCopyWith<$Res> implements $EUserCopyWith<$Res> {
  factory _$$EUserImplCopyWith(
          _$EUserImpl value, $Res Function(_$EUserImpl) then) =
      __$$EUserImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {List<RBadges>? badges,
      List<RCourse>? courses,
      List<RCourse>? completedCourses});
}

/// @nodoc
class __$$EUserImplCopyWithImpl<$Res>
    extends _$EUserCopyWithImpl<$Res, _$EUserImpl>
    implements _$$EUserImplCopyWith<$Res> {
  __$$EUserImplCopyWithImpl(
      _$EUserImpl _value, $Res Function(_$EUserImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? badges = freezed,
    Object? courses = freezed,
    Object? completedCourses = freezed,
  }) {
    return _then(_$EUserImpl(
      badges: freezed == badges
          ? _value._badges
          : badges // ignore: cast_nullable_to_non_nullable
              as List<RBadges>?,
      courses: freezed == courses
          ? _value._courses
          : courses // ignore: cast_nullable_to_non_nullable
              as List<RCourse>?,
      completedCourses: freezed == completedCourses
          ? _value._completedCourses
          : completedCourses // ignore: cast_nullable_to_non_nullable
              as List<RCourse>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$EUserImpl implements _EUser {
  const _$EUserImpl(
      {required final List<RBadges>? badges,
      required final List<RCourse>? courses,
      required final List<RCourse>? completedCourses})
      : _badges = badges,
        _courses = courses,
        _completedCourses = completedCourses;

  factory _$EUserImpl.fromJson(Map<String, dynamic> json) =>
      _$$EUserImplFromJson(json);

  final List<RBadges>? _badges;
  @override
  List<RBadges>? get badges {
    final value = _badges;
    if (value == null) return null;
    if (_badges is EqualUnmodifiableListView) return _badges;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<RCourse>? _courses;
  @override
  List<RCourse>? get courses {
    final value = _courses;
    if (value == null) return null;
    if (_courses is EqualUnmodifiableListView) return _courses;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<RCourse>? _completedCourses;
  @override
  List<RCourse>? get completedCourses {
    final value = _completedCourses;
    if (value == null) return null;
    if (_completedCourses is EqualUnmodifiableListView)
      return _completedCourses;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'EUser(badges: $badges, courses: $courses, completedCourses: $completedCourses)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$EUserImpl &&
            const DeepCollectionEquality().equals(other._badges, _badges) &&
            const DeepCollectionEquality().equals(other._courses, _courses) &&
            const DeepCollectionEquality()
                .equals(other._completedCourses, _completedCourses));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(_badges),
      const DeepCollectionEquality().hash(_courses),
      const DeepCollectionEquality().hash(_completedCourses));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$EUserImplCopyWith<_$EUserImpl> get copyWith =>
      __$$EUserImplCopyWithImpl<_$EUserImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$EUserImplToJson(
      this,
    );
  }
}

abstract class _EUser implements EUser {
  const factory _EUser(
      {required final List<RBadges>? badges,
      required final List<RCourse>? courses,
      required final List<RCourse>? completedCourses}) = _$EUserImpl;

  factory _EUser.fromJson(Map<String, dynamic> json) = _$EUserImpl.fromJson;

  @override
  List<RBadges>? get badges;
  @override
  List<RCourse>? get courses;
  @override
  List<RCourse>? get completedCourses;
  @override
  @JsonKey(ignore: true)
  _$$EUserImplCopyWith<_$EUserImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
