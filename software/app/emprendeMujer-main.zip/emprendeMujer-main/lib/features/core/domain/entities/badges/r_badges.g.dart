// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'r_badges.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RBadgesImpl _$$RBadgesImplFromJson(Map<String, dynamic> json) =>
    _$RBadgesImpl(
      id: json['id'] as String?,
      created: json['created'] == null
          ? null
          : DateTime.parse(json['created'] as String),
      updated: json['updated'] == null
          ? null
          : DateTime.parse(json['updated'] as String),
      collectionId: json['collectionId'] as String?,
      collectionName: json['collectionName'] as String?,
      name: json['name'] as String?,
    );

Map<String, dynamic> _$$RBadgesImplToJson(_$RBadgesImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'created': instance.created?.toIso8601String(),
      'updated': instance.updated?.toIso8601String(),
      'collectionId': instance.collectionId,
      'collectionName': instance.collectionName,
      'name': instance.name,
    };
