// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'e_question.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$EQuestionImpl _$$EQuestionImplFromJson(Map<String, dynamic> json) => _$EQuestionImpl(
      correct: json['correct'] == null ? null : RAnswers.fromJson(json['correct'] as Map<String, dynamic>),
      options: (json['options'] as List<dynamic>?)?.map((e) => RAnswers.fromJson(e as Map<String, dynamic>)).toList(),
    );

Map<String, dynamic> _$$EQuestionImplToJson(_$EQuestionImpl instance) => <String, dynamic>{
      'correct': instance.correct?.toJson(),
      'options': instance.options?.map((e) => e.toJson()).toList(),
    };
