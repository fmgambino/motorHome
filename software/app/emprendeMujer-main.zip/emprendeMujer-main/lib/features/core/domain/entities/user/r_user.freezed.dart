// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'r_user.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

RUser _$RUserFromJson(Map<String, dynamic> json) {
  return _RUser.fromJson(json);
}

/// @nodoc
mixin _$RUser {
  String? get id => throw _privateConstructorUsedError;
  String? get collectionId => throw _privateConstructorUsedError;
  String? get collectionName => throw _privateConstructorUsedError;
  DateTime? get created => throw _privateConstructorUsedError;
  DateTime? get updated => throw _privateConstructorUsedError;
  String? get avatar => throw _privateConstructorUsedError;
  List<String>? get badges => throw _privateConstructorUsedError;
  List<String>? get courses => throw _privateConstructorUsedError;
  List<String>? get completedCourses => throw _privateConstructorUsedError;
  String? get email => throw _privateConstructorUsedError;
  bool? get emailVisibility => throw _privateConstructorUsedError;
  String? get name => throw _privateConstructorUsedError;
  String? get username => throw _privateConstructorUsedError;
  bool? get verified => throw _privateConstructorUsedError;
  EUser? get expand => throw _privateConstructorUsedError;
  String? get department => throw _privateConstructorUsedError;
  String? get documentNumber => throw _privateConstructorUsedError;
  String? get documentType => throw _privateConstructorUsedError;
  String? get gender => throw _privateConstructorUsedError;
  String? get nationality => throw _privateConstructorUsedError;
  String? get phone => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RUserCopyWith<RUser> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RUserCopyWith<$Res> {
  factory $RUserCopyWith(RUser value, $Res Function(RUser) then) =
      _$RUserCopyWithImpl<$Res, RUser>;
  @useResult
  $Res call(
      {String? id,
      String? collectionId,
      String? collectionName,
      DateTime? created,
      DateTime? updated,
      String? avatar,
      List<String>? badges,
      List<String>? courses,
      List<String>? completedCourses,
      String? email,
      bool? emailVisibility,
      String? name,
      String? username,
      bool? verified,
      EUser? expand,
      String? department,
      String? documentNumber,
      String? documentType,
      String? gender,
      String? nationality,
      String? phone});

  $EUserCopyWith<$Res>? get expand;
}

/// @nodoc
class _$RUserCopyWithImpl<$Res, $Val extends RUser>
    implements $RUserCopyWith<$Res> {
  _$RUserCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? collectionId = freezed,
    Object? collectionName = freezed,
    Object? created = freezed,
    Object? updated = freezed,
    Object? avatar = freezed,
    Object? badges = freezed,
    Object? courses = freezed,
    Object? completedCourses = freezed,
    Object? email = freezed,
    Object? emailVisibility = freezed,
    Object? name = freezed,
    Object? username = freezed,
    Object? verified = freezed,
    Object? expand = freezed,
    Object? department = freezed,
    Object? documentNumber = freezed,
    Object? documentType = freezed,
    Object? gender = freezed,
    Object? nationality = freezed,
    Object? phone = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionId: freezed == collectionId
          ? _value.collectionId
          : collectionId // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionName: freezed == collectionName
          ? _value.collectionName
          : collectionName // ignore: cast_nullable_to_non_nullable
              as String?,
      created: freezed == created
          ? _value.created
          : created // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updated: freezed == updated
          ? _value.updated
          : updated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      avatar: freezed == avatar
          ? _value.avatar
          : avatar // ignore: cast_nullable_to_non_nullable
              as String?,
      badges: freezed == badges
          ? _value.badges
          : badges // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      courses: freezed == courses
          ? _value.courses
          : courses // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      completedCourses: freezed == completedCourses
          ? _value.completedCourses
          : completedCourses // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      emailVisibility: freezed == emailVisibility
          ? _value.emailVisibility
          : emailVisibility // ignore: cast_nullable_to_non_nullable
              as bool?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      username: freezed == username
          ? _value.username
          : username // ignore: cast_nullable_to_non_nullable
              as String?,
      verified: freezed == verified
          ? _value.verified
          : verified // ignore: cast_nullable_to_non_nullable
              as bool?,
      expand: freezed == expand
          ? _value.expand
          : expand // ignore: cast_nullable_to_non_nullable
              as EUser?,
      department: freezed == department
          ? _value.department
          : department // ignore: cast_nullable_to_non_nullable
              as String?,
      documentNumber: freezed == documentNumber
          ? _value.documentNumber
          : documentNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      documentType: freezed == documentType
          ? _value.documentType
          : documentType // ignore: cast_nullable_to_non_nullable
              as String?,
      gender: freezed == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String?,
      nationality: freezed == nationality
          ? _value.nationality
          : nationality // ignore: cast_nullable_to_non_nullable
              as String?,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $EUserCopyWith<$Res>? get expand {
    if (_value.expand == null) {
      return null;
    }

    return $EUserCopyWith<$Res>(_value.expand!, (value) {
      return _then(_value.copyWith(expand: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$RUserImplCopyWith<$Res> implements $RUserCopyWith<$Res> {
  factory _$$RUserImplCopyWith(
          _$RUserImpl value, $Res Function(_$RUserImpl) then) =
      __$$RUserImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      String? collectionId,
      String? collectionName,
      DateTime? created,
      DateTime? updated,
      String? avatar,
      List<String>? badges,
      List<String>? courses,
      List<String>? completedCourses,
      String? email,
      bool? emailVisibility,
      String? name,
      String? username,
      bool? verified,
      EUser? expand,
      String? department,
      String? documentNumber,
      String? documentType,
      String? gender,
      String? nationality,
      String? phone});

  @override
  $EUserCopyWith<$Res>? get expand;
}

/// @nodoc
class __$$RUserImplCopyWithImpl<$Res>
    extends _$RUserCopyWithImpl<$Res, _$RUserImpl>
    implements _$$RUserImplCopyWith<$Res> {
  __$$RUserImplCopyWithImpl(
      _$RUserImpl _value, $Res Function(_$RUserImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? collectionId = freezed,
    Object? collectionName = freezed,
    Object? created = freezed,
    Object? updated = freezed,
    Object? avatar = freezed,
    Object? badges = freezed,
    Object? courses = freezed,
    Object? completedCourses = freezed,
    Object? email = freezed,
    Object? emailVisibility = freezed,
    Object? name = freezed,
    Object? username = freezed,
    Object? verified = freezed,
    Object? expand = freezed,
    Object? department = freezed,
    Object? documentNumber = freezed,
    Object? documentType = freezed,
    Object? gender = freezed,
    Object? nationality = freezed,
    Object? phone = freezed,
  }) {
    return _then(_$RUserImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionId: freezed == collectionId
          ? _value.collectionId
          : collectionId // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionName: freezed == collectionName
          ? _value.collectionName
          : collectionName // ignore: cast_nullable_to_non_nullable
              as String?,
      created: freezed == created
          ? _value.created
          : created // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updated: freezed == updated
          ? _value.updated
          : updated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      avatar: freezed == avatar
          ? _value.avatar
          : avatar // ignore: cast_nullable_to_non_nullable
              as String?,
      badges: freezed == badges
          ? _value._badges
          : badges // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      courses: freezed == courses
          ? _value._courses
          : courses // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      completedCourses: freezed == completedCourses
          ? _value._completedCourses
          : completedCourses // ignore: cast_nullable_to_non_nullable
              as List<String>?,
      email: freezed == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String?,
      emailVisibility: freezed == emailVisibility
          ? _value.emailVisibility
          : emailVisibility // ignore: cast_nullable_to_non_nullable
              as bool?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      username: freezed == username
          ? _value.username
          : username // ignore: cast_nullable_to_non_nullable
              as String?,
      verified: freezed == verified
          ? _value.verified
          : verified // ignore: cast_nullable_to_non_nullable
              as bool?,
      expand: freezed == expand
          ? _value.expand
          : expand // ignore: cast_nullable_to_non_nullable
              as EUser?,
      department: freezed == department
          ? _value.department
          : department // ignore: cast_nullable_to_non_nullable
              as String?,
      documentNumber: freezed == documentNumber
          ? _value.documentNumber
          : documentNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      documentType: freezed == documentType
          ? _value.documentType
          : documentType // ignore: cast_nullable_to_non_nullable
              as String?,
      gender: freezed == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String?,
      nationality: freezed == nationality
          ? _value.nationality
          : nationality // ignore: cast_nullable_to_non_nullable
              as String?,
      phone: freezed == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RUserImpl implements _RUser {
  const _$RUserImpl(
      {required this.id,
      required this.collectionId,
      required this.collectionName,
      required this.created,
      required this.updated,
      required this.avatar,
      required final List<String>? badges,
      required final List<String>? courses,
      required final List<String>? completedCourses,
      required this.email,
      required this.emailVisibility,
      required this.name,
      required this.username,
      required this.verified,
      required this.expand,
      required this.department,
      required this.documentNumber,
      required this.documentType,
      required this.gender,
      required this.nationality,
      required this.phone})
      : _badges = badges,
        _courses = courses,
        _completedCourses = completedCourses;

  factory _$RUserImpl.fromJson(Map<String, dynamic> json) =>
      _$$RUserImplFromJson(json);

  @override
  final String? id;
  @override
  final String? collectionId;
  @override
  final String? collectionName;
  @override
  final DateTime? created;
  @override
  final DateTime? updated;
  @override
  final String? avatar;
  final List<String>? _badges;
  @override
  List<String>? get badges {
    final value = _badges;
    if (value == null) return null;
    if (_badges is EqualUnmodifiableListView) return _badges;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<String>? _courses;
  @override
  List<String>? get courses {
    final value = _courses;
    if (value == null) return null;
    if (_courses is EqualUnmodifiableListView) return _courses;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<String>? _completedCourses;
  @override
  List<String>? get completedCourses {
    final value = _completedCourses;
    if (value == null) return null;
    if (_completedCourses is EqualUnmodifiableListView)
      return _completedCourses;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  final String? email;
  @override
  final bool? emailVisibility;
  @override
  final String? name;
  @override
  final String? username;
  @override
  final bool? verified;
  @override
  final EUser? expand;
  @override
  final String? department;
  @override
  final String? documentNumber;
  @override
  final String? documentType;
  @override
  final String? gender;
  @override
  final String? nationality;
  @override
  final String? phone;

  @override
  String toString() {
    return 'RUser(id: $id, collectionId: $collectionId, collectionName: $collectionName, created: $created, updated: $updated, avatar: $avatar, badges: $badges, courses: $courses, completedCourses: $completedCourses, email: $email, emailVisibility: $emailVisibility, name: $name, username: $username, verified: $verified, expand: $expand, department: $department, documentNumber: $documentNumber, documentType: $documentType, gender: $gender, nationality: $nationality, phone: $phone)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RUserImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.collectionId, collectionId) ||
                other.collectionId == collectionId) &&
            (identical(other.collectionName, collectionName) ||
                other.collectionName == collectionName) &&
            (identical(other.created, created) || other.created == created) &&
            (identical(other.updated, updated) || other.updated == updated) &&
            (identical(other.avatar, avatar) || other.avatar == avatar) &&
            const DeepCollectionEquality().equals(other._badges, _badges) &&
            const DeepCollectionEquality().equals(other._courses, _courses) &&
            const DeepCollectionEquality()
                .equals(other._completedCourses, _completedCourses) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.emailVisibility, emailVisibility) ||
                other.emailVisibility == emailVisibility) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.username, username) ||
                other.username == username) &&
            (identical(other.verified, verified) ||
                other.verified == verified) &&
            (identical(other.expand, expand) || other.expand == expand) &&
            (identical(other.department, department) ||
                other.department == department) &&
            (identical(other.documentNumber, documentNumber) ||
                other.documentNumber == documentNumber) &&
            (identical(other.documentType, documentType) ||
                other.documentType == documentType) &&
            (identical(other.gender, gender) || other.gender == gender) &&
            (identical(other.nationality, nationality) ||
                other.nationality == nationality) &&
            (identical(other.phone, phone) || other.phone == phone));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        collectionId,
        collectionName,
        created,
        updated,
        avatar,
        const DeepCollectionEquality().hash(_badges),
        const DeepCollectionEquality().hash(_courses),
        const DeepCollectionEquality().hash(_completedCourses),
        email,
        emailVisibility,
        name,
        username,
        verified,
        expand,
        department,
        documentNumber,
        documentType,
        gender,
        nationality,
        phone
      ]);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RUserImplCopyWith<_$RUserImpl> get copyWith =>
      __$$RUserImplCopyWithImpl<_$RUserImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RUserImplToJson(
      this,
    );
  }
}

abstract class _RUser implements RUser {
  const factory _RUser(
      {required final String? id,
      required final String? collectionId,
      required final String? collectionName,
      required final DateTime? created,
      required final DateTime? updated,
      required final String? avatar,
      required final List<String>? badges,
      required final List<String>? courses,
      required final List<String>? completedCourses,
      required final String? email,
      required final bool? emailVisibility,
      required final String? name,
      required final String? username,
      required final bool? verified,
      required final EUser? expand,
      required final String? department,
      required final String? documentNumber,
      required final String? documentType,
      required final String? gender,
      required final String? nationality,
      required final String? phone}) = _$RUserImpl;

  factory _RUser.fromJson(Map<String, dynamic> json) = _$RUserImpl.fromJson;

  @override
  String? get id;
  @override
  String? get collectionId;
  @override
  String? get collectionName;
  @override
  DateTime? get created;
  @override
  DateTime? get updated;
  @override
  String? get avatar;
  @override
  List<String>? get badges;
  @override
  List<String>? get courses;
  @override
  List<String>? get completedCourses;
  @override
  String? get email;
  @override
  bool? get emailVisibility;
  @override
  String? get name;
  @override
  String? get username;
  @override
  bool? get verified;
  @override
  EUser? get expand;
  @override
  String? get department;
  @override
  String? get documentNumber;
  @override
  String? get documentType;
  @override
  String? get gender;
  @override
  String? get nationality;
  @override
  String? get phone;
  @override
  @JsonKey(ignore: true)
  _$$RUserImplCopyWith<_$RUserImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
