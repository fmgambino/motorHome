// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'r_answer.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RAnswersImpl _$$RAnswersImplFromJson(Map<String, dynamic> json) =>
    _$RAnswersImpl(
      id: json['id'] as String?,
      created: json['created'] == null
          ? null
          : DateTime.parse(json['created'] as String),
      updated: json['updated'] == null
          ? null
          : DateTime.parse(json['updated'] as String),
      collectionId: json['collectionId'] as String?,
      collectionName: json['collectionName'] as String?,
      answer: json['answer'] as String?,
    );

Map<String, dynamic> _$$RAnswersImplToJson(_$RAnswersImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'created': instance.created?.toIso8601String(),
      'updated': instance.updated?.toIso8601String(),
      'collectionId': instance.collectionId,
      'collectionName': instance.collectionName,
      'answer': instance.answer,
    };
