// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'r_user.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RUserImpl _$$RUserImplFromJson(Map<String, dynamic> json) => _$RUserImpl(
      id: json['id'] as String?,
      collectionId: json['collectionId'] as String?,
      collectionName: json['collectionName'] as String?,
      created: json['created'] == null ? null : DateTime.parse(json['created'] as String),
      updated: json['updated'] == null ? null : DateTime.parse(json['updated'] as String),
      avatar: json['avatar'] as String?,
      badges: (json['badges'] as List<dynamic>?)?.map((e) => e as String).toList(),
      courses: (json['courses'] as List<dynamic>?)?.map((e) => e as String).toList(),
      completedCourses: (json['completedCourses'] as List<dynamic>?)?.map((e) => e as String).toList(),
      email: json['email'] as String?,
      emailVisibility: json['emailVisibility'] as bool?,
      name: json['name'] as String?,
      username: json['username'] as String?,
      verified: json['verified'] as bool?,
      expand: json['expand'] == null ? null : EUser.fromJson(json['expand'] as Map<String, dynamic>),
      department: json['department'] as String?,
      documentNumber: json['documentNumber'] as String?,
      documentType: json['documentType'] as String?,
      gender: json['gender'] as String?,
      nationality: json['nationality'] as String?,
      phone: json['phone'] as String?,
    );

Map<String, dynamic> _$$RUserImplToJson(_$RUserImpl instance) => <String, dynamic>{
      'id': instance.id,
      'collectionId': instance.collectionId,
      'collectionName': instance.collectionName,
      'created': instance.created?.toIso8601String(),
      'updated': instance.updated?.toIso8601String(),
      'avatar': instance.avatar,
      'badges': instance.badges,
      'courses': instance.courses,
      'completedCourses': instance.completedCourses,
      'email': instance.email,
      'emailVisibility': instance.emailVisibility,
      'name': instance.name,
      'username': instance.username,
      'verified': instance.verified,
      'expand': instance.expand?.toJson(),
      'department': instance.department,
      'documentNumber': instance.documentNumber,
      'documentType': instance.documentType,
      'gender': instance.gender,
      'nationality': instance.nationality,
      'phone': instance.phone,
    };
