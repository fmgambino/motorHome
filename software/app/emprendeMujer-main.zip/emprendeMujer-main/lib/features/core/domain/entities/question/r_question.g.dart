// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'r_question.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RQuestionImpl _$$RQuestionImplFromJson(Map<String, dynamic> json) => _$RQuestionImpl(
      id: json['id'] as String?,
      created: json['created'] == null ? null : DateTime.parse(json['created'] as String),
      updated: json['updated'] == null ? null : DateTime.parse(json['updated'] as String),
      collectionId: json['collectionId'] as String?,
      collectionName: json['collectionName'] as String?,
      expand: json['expand'] == null ? null : EQuestion.fromJson(json['expand'] as Map<String, dynamic>),
      ask: json['ask'] as String?,
      correct: json['correct'] as String?,
      elected: json['elected'] as String?,
      success: json['success'] as bool?,
      options: (json['options'] as List<dynamic>?)?.map((e) => e as String).toList(),
    );

Map<String, dynamic> _$$RQuestionImplToJson(_$RQuestionImpl instance) => <String, dynamic>{
      'id': instance.id,
      'created': instance.created?.toIso8601String(),
      'updated': instance.updated?.toIso8601String(),
      'collectionId': instance.collectionId,
      'collectionName': instance.collectionName,
      'expand': instance.expand?.toJson(),
      'ask': instance.ask,
      'correct': instance.correct,
      'elected': instance.elected,
      'success': instance.success,
      'options': instance.options,
    };
