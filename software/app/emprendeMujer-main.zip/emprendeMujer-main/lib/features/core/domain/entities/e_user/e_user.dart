import 'package:emprende_mujer/features/core/domain/entities/badges/r_badges.dart';
import 'package:emprende_mujer/features/courses/domain/entities/index.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'e_user.freezed.dart';
part 'e_user.g.dart';

@freezed
class EUser with _$EUser {
  const factory EUser({
    required List<RBadges>? badges,
    required List<RCourse>? courses,
    required List<RCourse>? completedCourses,
  }) = _EUser;

  factory EUser.fromJson(Map<String, Object?> json) => _$EUserFromJson(json);
}
