import 'package:emprende_mujer/features/core/domain/entities/answer/r_answer.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'e_question.freezed.dart';
part 'e_question.g.dart';

@freezed
class EQuestion with _$EQuestion {
  const factory EQuestion({
    required RAnswers? correct,
    required List<RAnswers>? options,
  }) = _EQuestion;

  factory EQuestion.fromJson(Map<String, Object?> json) => _$EQuestionFromJson(json);
}
