// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'r_question.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

RQuestion _$RQuestionFromJson(Map<String, dynamic> json) {
  return _RQuestion.fromJson(json);
}

/// @nodoc
mixin _$RQuestion {
  String? get id => throw _privateConstructorUsedError;
  DateTime? get created => throw _privateConstructorUsedError;
  DateTime? get updated => throw _privateConstructorUsedError;
  String? get collectionId => throw _privateConstructorUsedError;
  String? get collectionName => throw _privateConstructorUsedError;
  EQuestion? get expand => throw _privateConstructorUsedError;
  String? get ask => throw _privateConstructorUsedError;
  String? get correct => throw _privateConstructorUsedError;
  String? get elected => throw _privateConstructorUsedError;
  bool? get success => throw _privateConstructorUsedError;
  List<String>? get options => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RQuestionCopyWith<RQuestion> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RQuestionCopyWith<$Res> {
  factory $RQuestionCopyWith(RQuestion value, $Res Function(RQuestion) then) =
      _$RQuestionCopyWithImpl<$Res, RQuestion>;
  @useResult
  $Res call(
      {String? id,
      DateTime? created,
      DateTime? updated,
      String? collectionId,
      String? collectionName,
      EQuestion? expand,
      String? ask,
      String? correct,
      String? elected,
      bool? success,
      List<String>? options});

  $EQuestionCopyWith<$Res>? get expand;
}

/// @nodoc
class _$RQuestionCopyWithImpl<$Res, $Val extends RQuestion>
    implements $RQuestionCopyWith<$Res> {
  _$RQuestionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? created = freezed,
    Object? updated = freezed,
    Object? collectionId = freezed,
    Object? collectionName = freezed,
    Object? expand = freezed,
    Object? ask = freezed,
    Object? correct = freezed,
    Object? elected = freezed,
    Object? success = freezed,
    Object? options = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      created: freezed == created
          ? _value.created
          : created // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updated: freezed == updated
          ? _value.updated
          : updated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      collectionId: freezed == collectionId
          ? _value.collectionId
          : collectionId // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionName: freezed == collectionName
          ? _value.collectionName
          : collectionName // ignore: cast_nullable_to_non_nullable
              as String?,
      expand: freezed == expand
          ? _value.expand
          : expand // ignore: cast_nullable_to_non_nullable
              as EQuestion?,
      ask: freezed == ask
          ? _value.ask
          : ask // ignore: cast_nullable_to_non_nullable
              as String?,
      correct: freezed == correct
          ? _value.correct
          : correct // ignore: cast_nullable_to_non_nullable
              as String?,
      elected: freezed == elected
          ? _value.elected
          : elected // ignore: cast_nullable_to_non_nullable
              as String?,
      success: freezed == success
          ? _value.success
          : success // ignore: cast_nullable_to_non_nullable
              as bool?,
      options: freezed == options
          ? _value.options
          : options // ignore: cast_nullable_to_non_nullable
              as List<String>?,
    ) as $Val);
  }

  @override
  @pragma('vm:prefer-inline')
  $EQuestionCopyWith<$Res>? get expand {
    if (_value.expand == null) {
      return null;
    }

    return $EQuestionCopyWith<$Res>(_value.expand!, (value) {
      return _then(_value.copyWith(expand: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$RQuestionImplCopyWith<$Res>
    implements $RQuestionCopyWith<$Res> {
  factory _$$RQuestionImplCopyWith(
          _$RQuestionImpl value, $Res Function(_$RQuestionImpl) then) =
      __$$RQuestionImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      DateTime? created,
      DateTime? updated,
      String? collectionId,
      String? collectionName,
      EQuestion? expand,
      String? ask,
      String? correct,
      String? elected,
      bool? success,
      List<String>? options});

  @override
  $EQuestionCopyWith<$Res>? get expand;
}

/// @nodoc
class __$$RQuestionImplCopyWithImpl<$Res>
    extends _$RQuestionCopyWithImpl<$Res, _$RQuestionImpl>
    implements _$$RQuestionImplCopyWith<$Res> {
  __$$RQuestionImplCopyWithImpl(
      _$RQuestionImpl _value, $Res Function(_$RQuestionImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? created = freezed,
    Object? updated = freezed,
    Object? collectionId = freezed,
    Object? collectionName = freezed,
    Object? expand = freezed,
    Object? ask = freezed,
    Object? correct = freezed,
    Object? elected = freezed,
    Object? success = freezed,
    Object? options = freezed,
  }) {
    return _then(_$RQuestionImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      created: freezed == created
          ? _value.created
          : created // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updated: freezed == updated
          ? _value.updated
          : updated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      collectionId: freezed == collectionId
          ? _value.collectionId
          : collectionId // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionName: freezed == collectionName
          ? _value.collectionName
          : collectionName // ignore: cast_nullable_to_non_nullable
              as String?,
      expand: freezed == expand
          ? _value.expand
          : expand // ignore: cast_nullable_to_non_nullable
              as EQuestion?,
      ask: freezed == ask
          ? _value.ask
          : ask // ignore: cast_nullable_to_non_nullable
              as String?,
      correct: freezed == correct
          ? _value.correct
          : correct // ignore: cast_nullable_to_non_nullable
              as String?,
      elected: freezed == elected
          ? _value.elected
          : elected // ignore: cast_nullable_to_non_nullable
              as String?,
      success: freezed == success
          ? _value.success
          : success // ignore: cast_nullable_to_non_nullable
              as bool?,
      options: freezed == options
          ? _value._options
          : options // ignore: cast_nullable_to_non_nullable
              as List<String>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RQuestionImpl implements _RQuestion {
  const _$RQuestionImpl(
      {required this.id,
      required this.created,
      required this.updated,
      required this.collectionId,
      required this.collectionName,
      required this.expand,
      required this.ask,
      required this.correct,
      required this.elected,
      required this.success,
      required final List<String>? options})
      : _options = options;

  factory _$RQuestionImpl.fromJson(Map<String, dynamic> json) =>
      _$$RQuestionImplFromJson(json);

  @override
  final String? id;
  @override
  final DateTime? created;
  @override
  final DateTime? updated;
  @override
  final String? collectionId;
  @override
  final String? collectionName;
  @override
  final EQuestion? expand;
  @override
  final String? ask;
  @override
  final String? correct;
  @override
  final String? elected;
  @override
  final bool? success;
  final List<String>? _options;
  @override
  List<String>? get options {
    final value = _options;
    if (value == null) return null;
    if (_options is EqualUnmodifiableListView) return _options;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  String toString() {
    return 'RQuestion(id: $id, created: $created, updated: $updated, collectionId: $collectionId, collectionName: $collectionName, expand: $expand, ask: $ask, correct: $correct, elected: $elected, success: $success, options: $options)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RQuestionImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.created, created) || other.created == created) &&
            (identical(other.updated, updated) || other.updated == updated) &&
            (identical(other.collectionId, collectionId) ||
                other.collectionId == collectionId) &&
            (identical(other.collectionName, collectionName) ||
                other.collectionName == collectionName) &&
            (identical(other.expand, expand) || other.expand == expand) &&
            (identical(other.ask, ask) || other.ask == ask) &&
            (identical(other.correct, correct) || other.correct == correct) &&
            (identical(other.elected, elected) || other.elected == elected) &&
            (identical(other.success, success) || other.success == success) &&
            const DeepCollectionEquality().equals(other._options, _options));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      created,
      updated,
      collectionId,
      collectionName,
      expand,
      ask,
      correct,
      elected,
      success,
      const DeepCollectionEquality().hash(_options));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RQuestionImplCopyWith<_$RQuestionImpl> get copyWith =>
      __$$RQuestionImplCopyWithImpl<_$RQuestionImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RQuestionImplToJson(
      this,
    );
  }
}

abstract class _RQuestion implements RQuestion {
  const factory _RQuestion(
      {required final String? id,
      required final DateTime? created,
      required final DateTime? updated,
      required final String? collectionId,
      required final String? collectionName,
      required final EQuestion? expand,
      required final String? ask,
      required final String? correct,
      required final String? elected,
      required final bool? success,
      required final List<String>? options}) = _$RQuestionImpl;

  factory _RQuestion.fromJson(Map<String, dynamic> json) =
      _$RQuestionImpl.fromJson;

  @override
  String? get id;
  @override
  DateTime? get created;
  @override
  DateTime? get updated;
  @override
  String? get collectionId;
  @override
  String? get collectionName;
  @override
  EQuestion? get expand;
  @override
  String? get ask;
  @override
  String? get correct;
  @override
  String? get elected;
  @override
  bool? get success;
  @override
  List<String>? get options;
  @override
  @JsonKey(ignore: true)
  _$$RQuestionImplCopyWith<_$RQuestionImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
