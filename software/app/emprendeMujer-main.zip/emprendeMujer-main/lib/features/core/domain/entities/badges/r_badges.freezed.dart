// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'r_badges.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

RBadges _$RBadgesFromJson(Map<String, dynamic> json) {
  return _RBadges.fromJson(json);
}

/// @nodoc
mixin _$RBadges {
  String? get id => throw _privateConstructorUsedError;
  DateTime? get created => throw _privateConstructorUsedError;
  DateTime? get updated => throw _privateConstructorUsedError;
  String? get collectionId => throw _privateConstructorUsedError;
  String? get collectionName => throw _privateConstructorUsedError;
  String? get name => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RBadgesCopyWith<RBadges> get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RBadgesCopyWith<$Res> {
  factory $RBadgesCopyWith(RBadges value, $Res Function(RBadges) then) =
      _$RBadgesCopyWithImpl<$Res, RBadges>;
  @useResult
  $Res call(
      {String? id,
      DateTime? created,
      DateTime? updated,
      String? collectionId,
      String? collectionName,
      String? name});
}

/// @nodoc
class _$RBadgesCopyWithImpl<$Res, $Val extends RBadges>
    implements $RBadgesCopyWith<$Res> {
  _$RBadgesCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? created = freezed,
    Object? updated = freezed,
    Object? collectionId = freezed,
    Object? collectionName = freezed,
    Object? name = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      created: freezed == created
          ? _value.created
          : created // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updated: freezed == updated
          ? _value.updated
          : updated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      collectionId: freezed == collectionId
          ? _value.collectionId
          : collectionId // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionName: freezed == collectionName
          ? _value.collectionName
          : collectionName // ignore: cast_nullable_to_non_nullable
              as String?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RBadgesImplCopyWith<$Res> implements $RBadgesCopyWith<$Res> {
  factory _$$RBadgesImplCopyWith(
          _$RBadgesImpl value, $Res Function(_$RBadgesImpl) then) =
      __$$RBadgesImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      DateTime? created,
      DateTime? updated,
      String? collectionId,
      String? collectionName,
      String? name});
}

/// @nodoc
class __$$RBadgesImplCopyWithImpl<$Res>
    extends _$RBadgesCopyWithImpl<$Res, _$RBadgesImpl>
    implements _$$RBadgesImplCopyWith<$Res> {
  __$$RBadgesImplCopyWithImpl(
      _$RBadgesImpl _value, $Res Function(_$RBadgesImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? created = freezed,
    Object? updated = freezed,
    Object? collectionId = freezed,
    Object? collectionName = freezed,
    Object? name = freezed,
  }) {
    return _then(_$RBadgesImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      created: freezed == created
          ? _value.created
          : created // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updated: freezed == updated
          ? _value.updated
          : updated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      collectionId: freezed == collectionId
          ? _value.collectionId
          : collectionId // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionName: freezed == collectionName
          ? _value.collectionName
          : collectionName // ignore: cast_nullable_to_non_nullable
              as String?,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RBadgesImpl implements _RBadges {
  const _$RBadgesImpl(
      {required this.id,
      required this.created,
      required this.updated,
      required this.collectionId,
      required this.collectionName,
      required this.name});

  factory _$RBadgesImpl.fromJson(Map<String, dynamic> json) =>
      _$$RBadgesImplFromJson(json);

  @override
  final String? id;
  @override
  final DateTime? created;
  @override
  final DateTime? updated;
  @override
  final String? collectionId;
  @override
  final String? collectionName;
  @override
  final String? name;

  @override
  String toString() {
    return 'RBadges(id: $id, created: $created, updated: $updated, collectionId: $collectionId, collectionName: $collectionName, name: $name)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RBadgesImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.created, created) || other.created == created) &&
            (identical(other.updated, updated) || other.updated == updated) &&
            (identical(other.collectionId, collectionId) ||
                other.collectionId == collectionId) &&
            (identical(other.collectionName, collectionName) ||
                other.collectionName == collectionName) &&
            (identical(other.name, name) || other.name == name));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, created, updated, collectionId, collectionName, name);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RBadgesImplCopyWith<_$RBadgesImpl> get copyWith =>
      __$$RBadgesImplCopyWithImpl<_$RBadgesImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RBadgesImplToJson(
      this,
    );
  }
}

abstract class _RBadges implements RBadges {
  const factory _RBadges(
      {required final String? id,
      required final DateTime? created,
      required final DateTime? updated,
      required final String? collectionId,
      required final String? collectionName,
      required final String? name}) = _$RBadgesImpl;

  factory _RBadges.fromJson(Map<String, dynamic> json) = _$RBadgesImpl.fromJson;

  @override
  String? get id;
  @override
  DateTime? get created;
  @override
  DateTime? get updated;
  @override
  String? get collectionId;
  @override
  String? get collectionName;
  @override
  String? get name;
  @override
  @JsonKey(ignore: true)
  _$$RBadgesImplCopyWith<_$RBadgesImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
