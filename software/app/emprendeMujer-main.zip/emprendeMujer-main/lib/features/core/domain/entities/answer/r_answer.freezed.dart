// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'r_answer.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

RAnswers _$RAnswersFromJson(Map<String, dynamic> json) {
  return _RAnswers.fromJson(json);
}

/// @nodoc
mixin _$RAnswers {
  String? get id => throw _privateConstructorUsedError;
  DateTime? get created => throw _privateConstructorUsedError;
  DateTime? get updated => throw _privateConstructorUsedError;
  String? get collectionId => throw _privateConstructorUsedError;
  String? get collectionName => throw _privateConstructorUsedError;
  String? get answer => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $RAnswersCopyWith<RAnswers> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $RAnswersCopyWith<$Res> {
  factory $RAnswersCopyWith(RAnswers value, $Res Function(RAnswers) then) =
      _$RAnswersCopyWithImpl<$Res, RAnswers>;
  @useResult
  $Res call(
      {String? id,
      DateTime? created,
      DateTime? updated,
      String? collectionId,
      String? collectionName,
      String? answer});
}

/// @nodoc
class _$RAnswersCopyWithImpl<$Res, $Val extends RAnswers>
    implements $RAnswersCopyWith<$Res> {
  _$RAnswersCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? created = freezed,
    Object? updated = freezed,
    Object? collectionId = freezed,
    Object? collectionName = freezed,
    Object? answer = freezed,
  }) {
    return _then(_value.copyWith(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      created: freezed == created
          ? _value.created
          : created // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updated: freezed == updated
          ? _value.updated
          : updated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      collectionId: freezed == collectionId
          ? _value.collectionId
          : collectionId // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionName: freezed == collectionName
          ? _value.collectionName
          : collectionName // ignore: cast_nullable_to_non_nullable
              as String?,
      answer: freezed == answer
          ? _value.answer
          : answer // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$RAnswersImplCopyWith<$Res>
    implements $RAnswersCopyWith<$Res> {
  factory _$$RAnswersImplCopyWith(
          _$RAnswersImpl value, $Res Function(_$RAnswersImpl) then) =
      __$$RAnswersImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? id,
      DateTime? created,
      DateTime? updated,
      String? collectionId,
      String? collectionName,
      String? answer});
}

/// @nodoc
class __$$RAnswersImplCopyWithImpl<$Res>
    extends _$RAnswersCopyWithImpl<$Res, _$RAnswersImpl>
    implements _$$RAnswersImplCopyWith<$Res> {
  __$$RAnswersImplCopyWithImpl(
      _$RAnswersImpl _value, $Res Function(_$RAnswersImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = freezed,
    Object? created = freezed,
    Object? updated = freezed,
    Object? collectionId = freezed,
    Object? collectionName = freezed,
    Object? answer = freezed,
  }) {
    return _then(_$RAnswersImpl(
      id: freezed == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String?,
      created: freezed == created
          ? _value.created
          : created // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      updated: freezed == updated
          ? _value.updated
          : updated // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      collectionId: freezed == collectionId
          ? _value.collectionId
          : collectionId // ignore: cast_nullable_to_non_nullable
              as String?,
      collectionName: freezed == collectionName
          ? _value.collectionName
          : collectionName // ignore: cast_nullable_to_non_nullable
              as String?,
      answer: freezed == answer
          ? _value.answer
          : answer // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$RAnswersImpl implements _RAnswers {
  const _$RAnswersImpl(
      {required this.id,
      required this.created,
      required this.updated,
      required this.collectionId,
      required this.collectionName,
      required this.answer});

  factory _$RAnswersImpl.fromJson(Map<String, dynamic> json) =>
      _$$RAnswersImplFromJson(json);

  @override
  final String? id;
  @override
  final DateTime? created;
  @override
  final DateTime? updated;
  @override
  final String? collectionId;
  @override
  final String? collectionName;
  @override
  final String? answer;

  @override
  String toString() {
    return 'RAnswers(id: $id, created: $created, updated: $updated, collectionId: $collectionId, collectionName: $collectionName, answer: $answer)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$RAnswersImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.created, created) || other.created == created) &&
            (identical(other.updated, updated) || other.updated == updated) &&
            (identical(other.collectionId, collectionId) ||
                other.collectionId == collectionId) &&
            (identical(other.collectionName, collectionName) ||
                other.collectionName == collectionName) &&
            (identical(other.answer, answer) || other.answer == answer));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, id, created, updated, collectionId, collectionName, answer);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$RAnswersImplCopyWith<_$RAnswersImpl> get copyWith =>
      __$$RAnswersImplCopyWithImpl<_$RAnswersImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$RAnswersImplToJson(
      this,
    );
  }
}

abstract class _RAnswers implements RAnswers {
  const factory _RAnswers(
      {required final String? id,
      required final DateTime? created,
      required final DateTime? updated,
      required final String? collectionId,
      required final String? collectionName,
      required final String? answer}) = _$RAnswersImpl;

  factory _RAnswers.fromJson(Map<String, dynamic> json) =
      _$RAnswersImpl.fromJson;

  @override
  String? get id;
  @override
  DateTime? get created;
  @override
  DateTime? get updated;
  @override
  String? get collectionId;
  @override
  String? get collectionName;
  @override
  String? get answer;
  @override
  @JsonKey(ignore: true)
  _$$RAnswersImplCopyWith<_$RAnswersImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
