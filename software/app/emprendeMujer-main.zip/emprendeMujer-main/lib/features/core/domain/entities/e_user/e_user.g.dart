// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'e_user.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$EUserImpl _$$EUserImplFromJson(Map<String, dynamic> json) => _$EUserImpl(
      badges: (json['badges'] as List<dynamic>?)
          ?.map((e) => RBadges.fromJson(e as Map<String, dynamic>))
          .toList(),
      courses: (json['courses'] as List<dynamic>?)
          ?.map((e) => RCourse.fromJson(e as Map<String, dynamic>))
          .toList(),
      completedCourses: (json['completedCourses'] as List<dynamic>?)
          ?.map((e) => RCourse.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$$EUserImplToJson(_$EUserImpl instance) =>
    <String, dynamic>{
      'badges': instance.badges,
      'courses': instance.courses,
      'completedCourses': instance.completedCourses,
    };
