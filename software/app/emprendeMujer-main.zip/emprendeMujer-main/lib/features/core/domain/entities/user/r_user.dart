import 'package:emprende_mujer/features/core/domain/entities/e_user/e_user.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'r_user.freezed.dart';
part 'r_user.g.dart';

@freezed
class RUser with _$RUser {
  const factory RUser({
    required String? id,
    required String? collectionId,
    required String? collectionName,
    required DateTime? created,
    required DateTime? updated,
    required String? avatar,
    required List<String>? badges,
    required List<String>? courses,
    required List<String>? completedCourses,
    required String? email,
    required bool? emailVisibility,
    required String? name,
    required String? username,
    required bool? verified,
    required EUser? expand,
    required String? department,
    required String? documentNumber,
    required String? documentType,
    required String? gender,
    required String? nationality,
    required String? phone,
  }) = _RUser;

  factory RUser.fromJson(Map<String, Object?> json) => _$RUserFromJson(json);
}
