// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'r_video.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$RVideoImpl _$$RVideoImplFromJson(Map<String, dynamic> json) => _$RVideoImpl(
      id: json['id'] as String?,
      created: json['created'] == null
          ? null
          : DateTime.parse(json['created'] as String),
      updated: json['updated'] == null
          ? null
          : DateTime.parse(json['updated'] as String),
      collectionId: json['collectionId'] as String?,
      collectionName: json['collectionName'] as String?,
      description: json['description'] as String?,
      module: json['module'] as int?,
      title: json['title'] as String?,
      url: json['url'] as String?,
      seen: json['seen'] as bool? ?? false,
    );

Map<String, dynamic> _$$RVideoImplToJson(_$RVideoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'created': instance.created?.toIso8601String(),
      'updated': instance.updated?.toIso8601String(),
      'collectionId': instance.collectionId,
      'collectionName': instance.collectionName,
      'description': instance.description,
      'module': instance.module,
      'title': instance.title,
      'url': instance.url,
      'seen': instance.seen,
    };
