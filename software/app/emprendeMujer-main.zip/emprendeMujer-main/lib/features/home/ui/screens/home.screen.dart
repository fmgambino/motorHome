import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/config/index.dart';
import 'package:emprende_mujer/features/authentication/index.dart';
import 'package:emprende_mujer/features/courses/index.dart';
import 'package:emprende_mujer/injection_container.dart';
import 'package:emprende_mujer/l10n/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late TabController tabController;

  late final AuthenticationCubit authenticationCubic;

  @override
  void initState() {
    tabController = TabController(length: 3, vsync: this, initialIndex: 1);
    authenticationCubic = sl.get<AuthenticationCubit>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = context.l10n;
    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              TabBarView(
                controller: tabController,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  /** TAP CURSOS */
                  const CoursesScreen(),
                  /** TAB PERFIL */
                  BlocBuilder<AuthenticationCubit, AuthenticationState>(
                    builder: (context, state) {
                      return SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Column(
                          children: [
                            Container(
                              padding: EdgeInsets.symmetric(vertical: context.dp(1)),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(context.dp(1.6)), bottomRight: Radius.circular(context.dp(1.6))),
                                color: ThemeColors.primary,
                              ),
                              height: context.hp(25),
                              width: double.infinity,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Stack(
                                    children: [
                                      Container(
                                        decoration: const BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: ThemeColors.lettersDisabled,
                                        ),
                                        height: context.dp(12),
                                        child: ClipOval(
                                          child: Image.network(
                                            'https://emprende-mujer.pockethost.io/api/files/${state.auth!.record!.collectionId}/${state.auth!.record!.id}/${state.auth!.record!.avatar}',
                                            fit: BoxFit.cover,
                                            width: context.dp(12),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        bottom: 0,
                                        right: 20,
                                        child: Container(
                                          padding: EdgeInsets.all(context.dp(0.4)),
                                          decoration: BoxDecoration(
                                            color: ThemeColors.tab3,
                                            borderRadius: BorderRadius.circular(context.dp(0.4)),
                                          ),
                                          child: SizedBox(
                                            height: context.dp(1),
                                            child: Image.asset(
                                              editar,
                                              fit: BoxFit.fitHeight,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: context.dp(1),
                                  ),
                                  Text(
                                    state.auth!.record!.name!,
                                    style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(2.5), fontWeight: FontWeight.w500),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: context.dp(2),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: DecoratedBox(
                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(context.dp(1.6)), color: const Color(0xff38527C)),
                                      child: Padding(
                                        padding: EdgeInsets.all(context.dp(2)),
                                        child: Column(
                                          children: [
                                            Text(
                                              state.auth!.record!.courses?.length.toString() ?? '0',
                                              style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(4), fontWeight: FontWeight.w500),
                                            ),
                                            RichText(
                                              textAlign: TextAlign.center,
                                              text: TextSpan(
                                                children: [
                                                  TextSpan(
                                                    text: 'Cursos\n',
                                                    style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.5), fontWeight: FontWeight.w500),
                                                  ),
                                                  TextSpan(
                                                    text: 'inscritos',
                                                    style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.5), fontWeight: FontWeight.w500),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: context.dp(1),
                                  ),
                                  Expanded(
                                    child: DecoratedBox(
                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(context.dp(1.6)), color: const Color(0xff38527C)),
                                      child: Padding(
                                        padding: EdgeInsets.all(context.dp(2)),
                                        child: Column(
                                          children: [
                                            Text(
                                              state.auth!.record!.completedCourses?.length.toString() ?? '0',
                                              style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(4), fontWeight: FontWeight.w500),
                                            ),
                                            RichText(
                                              textAlign: TextAlign.center,
                                              text: TextSpan(
                                                children: [
                                                  TextSpan(
                                                    text: 'Diplomas\n',
                                                    style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.5), fontWeight: FontWeight.w500),
                                                  ),
                                                  TextSpan(
                                                    text: 'obtenidos',
                                                    style: TextStyle(color: ThemeColors.letters, fontSize: context.dp(1.5), fontWeight: FontWeight.w500),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: context.dp(2),
                            ),
                            Container(
                              margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
                              padding: EdgeInsets.all(context.dp(2)),
                              // height: context.hp(20),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(context.dp(0.5)),
                                border: Border.all(color: ThemeColors.lettersDisabled, width: context.dp(0.1)),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Mi emprendimiento',
                                          style: TextStyle(color: ThemeColors.tab3, fontSize: context.dp(2), fontWeight: FontWeight.w500),
                                        ),
                                        SizedBox(
                                          height: context.dp(1),
                                        ),
                                        Text(
                                          'Nombre: Aluminé lámparas 3D',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: context.dp(1.5),
                                          ),
                                        ),
                                        SizedBox(
                                          height: context.dp(1),
                                        ),
                                        Text(
                                          'Rubro: Creatividad y ventas',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: context.dp(1.5),
                                          ),
                                        ),
                                        SizedBox(
                                          height: context.dp(1),
                                        ),
                                        Text(
                                          'Dirección: 25 de Mayo 1000',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: context.dp(1.5),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: context.dp(1.2),
                                    child: Image.asset(
                                      editar,
                                      fit: BoxFit.fitHeight,
                                      color: Colors.black,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: context.dp(2),
                            ),
                            Column(
                              children: [
                                Text('Medallas obtenidas', style: TextStyle(color: Colors.black, fontSize: context.dp(2), fontWeight: FontWeight.w500)),
                                SizedBox(
                                  height: context.dp(1),
                                ),
                                Wrap(
                                  runSpacing: context.dp(0.5),
                                  children: [
                                    Container(
                                      padding: EdgeInsets.all(context.dp(1)),
                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(context.dp(0.8)), color: ThemeColors.primary),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            'Comencé un nuevo curso',
                                            style: TextStyle(color: Colors.white, fontSize: context.dp(1.5), fontWeight: FontWeight.w500),
                                          ),
                                          SizedBox(
                                            width: context.dp(1),
                                          ),
                                          Icon(
                                            Icons.star,
                                            color: Colors.white,
                                            size: context.dp(1.5),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: context.dp(0.5),
                                    ),
                                    Container(
                                      padding: EdgeInsets.all(context.dp(1)),
                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(context.dp(0.8)), color: const Color(0xffE7741F)),
                                      child: Text(
                                        'Soy emprendedora',
                                        style: TextStyle(color: Colors.white, fontSize: context.dp(1.5), fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                    Container(
                                      padding: EdgeInsets.all(context.dp(1)),
                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(context.dp(0.8)), color: const Color(0xff40BBBD)),
                                      child: Text(
                                        'Empecé un nuevo curso',
                                        style: TextStyle(color: Colors.white, fontSize: context.dp(1.5), fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                    SizedBox(
                                      width: context.dp(0.5),
                                    ),
                                    Container(
                                      padding: EdgeInsets.all(context.dp(1)),
                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(context.dp(0.8)), color: ThemeColors.tab3),
                                      child: Text(
                                        '¡Soy nivel 100!',
                                        style: TextStyle(color: Colors.white, fontSize: context.dp(1.5), fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: context.dp(2),
                                ),
                                DecoratedBox(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(context.dp(1)),
                                    border: Border.all(color: ThemeColors.lettersDisabled, width: context.dp(0.1)),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.all(context.dp(1)),
                                    child: Text(
                                      'Comienza o continúa tu curso aquí',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: context.dp(1.5),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: context.dp(2),
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: ElevatedButton(
                                          onPressed: () {
                                            authenticationCubic.logOut();
                                            Navigator.of(context).pushAndRemoveUntil(
                                              navegarMapaFadeIn(context, const SplashScreen()),
                                              (route) => false,
                                            );
                                          },
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: ThemeColors.primary,
                                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(1.5))),
                                          ),
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Text(
                                                'Cerrar sesión',
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: context.dp(1.5),
                                                ),
                                              ),
                                              SizedBox(
                                                width: context.dp(1),
                                              ),
                                              Icon(
                                                Icons.close,
                                                color: Colors.white,
                                                size: context.dp(1.5),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  /** TAP CONSTANCIAS */
                  ColoredBox(
                    color: Colors.white,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      // crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          // flex: 2,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                'Certificados',
                                textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.black, fontSize: context.dp(4), fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ),
                        // const _SinCertificados(),
                        const _ConCertificados(),

                        Expanded(
                          // flex: 1,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ElevatedButton(
                                onPressed: () {},
                                style: ElevatedButton.styleFrom(
                                  fixedSize: Size(context.dp(30), context.dp(5)),
                                  backgroundColor: ThemeColors.primary,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(context.dp(1.5))),
                                ),
                                child: Text(
                                  'Ver cursos',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: context.dp(1.5),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Positioned(left: 0, right: 0, top: 0, child: _Logo(l10n: l10n, tab: tabController)),
            ],
          ),
        ),
        bottomNavigationBar: _MyCustomBottomNavigationBar(
          controller: tabController,
        ),
      ),
    );
  }
}

class _ConCertificados extends StatelessWidget {
  const _ConCertificados();

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 4,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: context.dp(2)),
        child: Column(
          children: [
            Expanded(
              child: ListView.separated(
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.symmetric(vertical: context.dp(1)),
                itemCount: 12,
                separatorBuilder: (BuildContext context, int index) {
                  return SizedBox(height: context.dp(1));
                },
                itemBuilder: (BuildContext context, int index) {
                  final colors = [
                    const Color(0xff38527C),
                    const Color(0xffE7741F),
                    const Color(0xff702163),
                  ];

                  final itemColor = colors[index % colors.length];
                  return DecoratedBox(
                    decoration: BoxDecoration(
                      color: itemColor,
                      borderRadius: BorderRadius.all(Radius.circular(context.dp(1))),
                    ),
                    child: ListTile(
                      title: Text(
                        'Curso: Emprende con éxito 1',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: context.dp(1.6),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        'Descarga el certificado',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: context.dp(1.4),
                        ),
                      ),
                      trailing: SizedBox(
                        height: context.dp(4),
                        child: Icon(
                          Icons.expand_circle_down_rounded,
                          color: Colors.white,
                          size: context.dp(4),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(
              height: context.dp(2),
            ),
            Text(
              '¡Termina todos los cursos y obtén más certificados!',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.black,
                fontSize: context.dp(1.6),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SinCertificados extends StatelessWidget {
  const _SinCertificados();

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 4,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: context.dp(20),
            child: Image.asset(
              certificado,
              fit: BoxFit.contain,
            ),
          ),
          SizedBox(
            height: context.dp(4),
          ),
          Text(
            'Aún no tienes certificados',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.black,
              fontSize: context.dp(2),
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(
            height: context.dp(2),
          ),
          Text(
            '¡Empieza un curso para obtener el primero!',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.black,
              fontSize: context.dp(1.6),
            ),
          ),
        ],
      ),
    );
  }
}

class _MyCustomBottomNavigationBar extends StatefulWidget implements PreferredSizeWidget {
  const _MyCustomBottomNavigationBar({
    required this.controller,
  });

  final TabController controller;

  @override
  State<_MyCustomBottomNavigationBar> createState() => __MyCustomBottomNavigationBarState();

  @override
  Size get preferredSize => throw UnimplementedError();
}

class __MyCustomBottomNavigationBarState extends State<_MyCustomBottomNavigationBar> {
  @override
  Widget build(BuildContext context) {
    return TabBar(
      indicator: BoxDecoration(
        borderRadius: BorderRadius.circular(context.dp(3)),
        color: widget.controller.index == 0
            ? ThemeColors.tab1
            : widget.controller.index == 1
                ? ThemeColors.tab2
                : ThemeColors.tab3,
      ),
      indicatorPadding: EdgeInsets.all(context.dp(1)),
      labelColor: Colors.white,
      unselectedLabelColor: Colors.black,
      controller: widget.controller,
      onTap: (index) {
        setState(() {
          widget.controller.index = index;
        });
      },
      tabs: [
        Tab(
          text: 'CURSOS',
          icon: SizedBox(
            // height: 24,
            child: Image.asset(
              cursos,
              color: widget.controller.index == 0 ? Colors.white : Colors.black,
              fit: BoxFit.contain,
            ),
          ),
        ),
        Tab(
          text: 'PERFIL',
          icon: SizedBox(
            // height: 24,
            child: Image.asset(
              perfil,
              color: widget.controller.index == 1 ? Colors.white : Colors.black,
              fit: BoxFit.contain,
            ),
          ),
        ),
        Tab(
          text: 'CONSTANCIAS',
          icon: SizedBox(
            // height: 24,
            child: Image.asset(
              constancias,
              color: widget.controller.index == 2 ? Colors.white : Colors.black,
              fit: BoxFit.contain,
            ),
          ),
        ),
      ],
    );
  }
}

class _Logo extends StatelessWidget {
  const _Logo({
    required this.l10n,
    required this.tab,
  });

  final AppLocalizations l10n;
  final TabController tab;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: context.dp(1)),
      margin: EdgeInsets.symmetric(horizontal: context.dp(2)),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(context.dp(1.6)), bottomRight: Radius.circular(context.dp(1.6))),
        color: tab.index != 2 ? Colors.white : ThemeColors.primary,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            l10n.by,
            style: TextStyle(color: tab.index != 2 ? Colors.black : Colors.white, fontSize: context.dp(1.6), fontWeight: FontWeight.w400),
          ),
          SizedBox(
            width: context.dp(1),
          ),
          SvgPicture.asset(
            tab.index != 2 ? logoColorPath : logoPath,
            height: context.dp(2.5),
          ),
        ],
      ),
    );
  }
}
