
		// import 'package:emprende_mujer/features/home/domain/index.dart';


		// class HomeRepositoryImpl extends HomeRepository {

		// 	@override
		// 	Future<T> create<T>() async {
		// 	throw UnimplementedError();
		// 	}

		// 	@override
		// 	Future<T> read<T>() async {
		// 	throw UnimplementedError();
		// 	}

		// 	@override
		// 	Future<T> update<T>() async {
		
		// 	throw UnimplementedError();
		// 	}

		// 	@override
		// 	Future<T> delete<T>() async {
		
		// 	throw UnimplementedError();
		// 	}
		  
		// }