import 'package:emprende_mujer/app/app.dart';
import 'package:emprende_mujer/bootstrap.dart';

void main() {
  bootstrap(() => const App());
}
