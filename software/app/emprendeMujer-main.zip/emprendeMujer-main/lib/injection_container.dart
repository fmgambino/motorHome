import 'package:dio/dio.dart';
import 'package:emprende_mujer/common/index.dart';
import 'package:emprende_mujer/features/authentication/index.dart';
import 'package:emprende_mujer/features/core/index.dart';
import 'package:emprende_mujer/features/courses/index.dart';
import 'package:get_it/get_it.dart';
import 'package:pocketbase/pocketbase.dart';

GetIt sl = GetIt.instance;

Future<void> setup() async {
  sl
    ..registerLazySingleton(Dio.new)
    ..registerLazySingleton(DioAdapter.new)
    ..registerLazySingleton(() => PocketBase('https://emprende-mujer.pockethost.io/'))
    ..registerLazySingleton<AuthRemoteDatasource>(() => AuthRemoteDatasourceImpl(pb: sl()))
    ..registerLazySingleton<AuthenticationRepository>(() => AuthenticationRepositoryImpl(remote: sl()))
    ..registerLazySingleton(() => SingInUsecase(sl()))
    ..registerLazySingleton(() => RegisterUsecase(sl()))
    ..registerLazySingleton(() => AuthenticationCubit(singInUsecase: sl(), registerUsecase: sl()))
    ..registerLazySingleton<CoreRemoteDatasource>(() => CoreRemoteDatasourceImpl(pb: sl()))
    ..registerLazySingleton<CoreRepository>(() => CoreRepositoryImpl(dataSource: sl()))
    ..registerLazySingleton(() => CoreBloc(getAllInfographics: sl()))
    ..registerLazySingleton(() => GetAllInfographicsUsecase(sl()))
    ..registerLazySingleton<CoursesRemoteDatasource>(() => CoursesRemoteDatasourceImpl(pb: sl()))
    ..registerLazySingleton<CoursesRepository>(() => CoursesRepositoryImpl(dataSource: sl()))
    ..registerLazySingleton(() => CoursesBloc(getAllCourses: sl()))
    ..registerLazySingleton(() => SelectedCourseBloc(startCourse: sl(), addCourseToStudent: sl(), addCompletedCourseToStudent: sl(), requestCertificate: sl()))
    ..registerLazySingleton(TestBloc.new)
    ..registerLazySingleton(() => GetAllCoursesUsecase(sl()))
    ..registerLazySingleton(() => AddCourseToStudentUsecase(sl()))
    ..registerLazySingleton(() => AddCompletedCourseToStudentUsecase(sl()))
    ..registerLazySingleton(() => RequestCertificateUsecase(sl()))
    ..registerLazySingleton(() => StartCourseUsecase(sl()));
}
